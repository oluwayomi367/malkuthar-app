<?php $__env->startSection('title', 'Administration — Tableau de bord'); ?>
<?php $__env->startSection('eyebrow', 'MALKUTHAR'); ?>
<?php $__env->startSection('heading', 'Tableau de bord'); ?>

<?php $__env->startSection('content'); ?>
<?php $m = fn ($n) => number_format((float) $n, 0, ',', ' '); ?>


<div class="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
    <?php if (isset($component)) { $__componentOriginal81faba2b0dfb90699ac659eea004d68e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal81faba2b0dfb90699ac659eea004d68e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.stat-tile','data' => ['label' => 'Affiliés','value' => $m($stats['affiliates_total']),'emphasis' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.stat-tile'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Affiliés','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($m($stats['affiliates_total'])),'emphasis' => true]); ?>
         <?php $__env->slot('foot', null, []); ?> 
            <span class="text-emerald-300"><?php echo e($m($stats['affiliates_active'])); ?> actifs</span>
            · <?php echo e($m($stats['affiliates_new'])); ?> ce mois
            <?php if($stats['affiliates_suspended']): ?> · <span class="text-rust"><?php echo e($m($stats['affiliates_suspended'])); ?> suspendus</span><?php endif; ?>
         <?php $__env->endSlot(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal81faba2b0dfb90699ac659eea004d68e)): ?>
<?php $attributes = $__attributesOriginal81faba2b0dfb90699ac659eea004d68e; ?>
<?php unset($__attributesOriginal81faba2b0dfb90699ac659eea004d68e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal81faba2b0dfb90699ac659eea004d68e)): ?>
<?php $component = $__componentOriginal81faba2b0dfb90699ac659eea004d68e; ?>
<?php unset($__componentOriginal81faba2b0dfb90699ac659eea004d68e); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginal81faba2b0dfb90699ac659eea004d68e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal81faba2b0dfb90699ac659eea004d68e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.stat-tile','data' => ['label' => 'Chiffre d\'affaires','value' => $m($stats['revenue']),'currency' => 'FCFA']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.stat-tile'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Chiffre d\'affaires','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($m($stats['revenue'])),'currency' => 'FCFA']); ?>
         <?php $__env->slot('foot', null, []); ?> 
            <?php echo e($m($stats['orders_paid'])); ?> commandes payées
            <?php if($stats['cod_to_collect_count']): ?>
                · <a href="<?php echo e(route('admin.orders.index', ['provider' => 'cod', 'payment_status' => 'pending'])); ?>" class="text-amber hover:underline"><?php echo e($m($stats['cod_to_collect_amount'])); ?> à encaisser (COD)</a>
            <?php endif; ?>
         <?php $__env->endSlot(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal81faba2b0dfb90699ac659eea004d68e)): ?>
<?php $attributes = $__attributesOriginal81faba2b0dfb90699ac659eea004d68e; ?>
<?php unset($__attributesOriginal81faba2b0dfb90699ac659eea004d68e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal81faba2b0dfb90699ac659eea004d68e)): ?>
<?php $component = $__componentOriginal81faba2b0dfb90699ac659eea004d68e; ?>
<?php unset($__componentOriginal81faba2b0dfb90699ac659eea004d68e); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginal81faba2b0dfb90699ac659eea004d68e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal81faba2b0dfb90699ac659eea004d68e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.stat-tile','data' => ['label' => 'Commissions générées','value' => $m($stats['commissions_generated']),'currency' => 'FCFA']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.stat-tile'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Commissions générées','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($m($stats['commissions_generated'])),'currency' => 'FCFA']); ?>
         <?php $__env->slot('foot', null, []); ?> 
            <span class="text-amber"><?php echo e($m($stats['commissions_pending'])); ?> en attente</span>
            · <span class="text-emerald-300"><?php echo e($m($stats['commissions_available'])); ?> disponibles</span>
         <?php $__env->endSlot(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal81faba2b0dfb90699ac659eea004d68e)): ?>
<?php $attributes = $__attributesOriginal81faba2b0dfb90699ac659eea004d68e; ?>
<?php unset($__attributesOriginal81faba2b0dfb90699ac659eea004d68e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal81faba2b0dfb90699ac659eea004d68e)): ?>
<?php $component = $__componentOriginal81faba2b0dfb90699ac659eea004d68e; ?>
<?php unset($__componentOriginal81faba2b0dfb90699ac659eea004d68e); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginal81faba2b0dfb90699ac659eea004d68e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal81faba2b0dfb90699ac659eea004d68e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.stat-tile','data' => ['label' => 'Retraits','value' => $m($stats['withdrawals_requested'])]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.stat-tile'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Retraits','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($m($stats['withdrawals_requested']))]); ?>
         <?php $__env->slot('foot', null, []); ?> 
            <span class="text-amber"><?php echo e($m($stats['withdrawals_processing'])); ?> à traiter</span>
            · <?php echo e($m($stats['withdrawals_paid'])); ?> payés
            <?php if($stats['withdrawals_failed']): ?> · <span class="text-rust"><?php echo e($m($stats['withdrawals_failed'])); ?> échoués</span><?php endif; ?>
         <?php $__env->endSlot(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal81faba2b0dfb90699ac659eea004d68e)): ?>
<?php $attributes = $__attributesOriginal81faba2b0dfb90699ac659eea004d68e; ?>
<?php unset($__attributesOriginal81faba2b0dfb90699ac659eea004d68e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal81faba2b0dfb90699ac659eea004d68e)): ?>
<?php $component = $__componentOriginal81faba2b0dfb90699ac659eea004d68e; ?>
<?php unset($__componentOriginal81faba2b0dfb90699ac659eea004d68e); ?>
<?php endif; ?>
</div>

<div class="mt-8 grid gap-8 lg:grid-cols-2">
    
    <section>
        <div class="mb-3 flex items-center justify-between">
            <h2 class="font-display text-lg font-semibold text-ink">Retraits à traiter</h2>
            <a href="<?php echo e(route('admin.withdrawals.index')); ?>" class="text-sm text-ink-2 hover:text-ink">Tout voir →</a>
        </div>
        <?php $__empty_1 = true; $__currentLoopData = $pendingWithdrawals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $w): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="mb-2 flex items-center justify-between rounded-xl border border-black/10 bg-surface px-4 py-3 text-sm">
                <div>
                    <p class="font-mono text-ink"><?php echo e($w->reference); ?></p>
                    <p class="text-xs text-ink-3"><?php echo e($w->user?->affiliate_id); ?> · <?php echo e($w->method); ?></p>
                </div>
                <p class="font-semibold text-ink"><?php echo e($m($w->amount)); ?> <?php echo e($w->currency); ?></p>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p class="rounded-xl border border-dashed border-black/10 bg-surface px-4 py-6 text-center text-sm text-ink-3">Aucun retrait en attente.</p>
        <?php endif; ?>
    </section>

    
    <section>
        <div class="mb-3 flex items-center justify-between">
            <h2 class="font-display text-lg font-semibold text-ink">Derniers affiliés</h2>
            <a href="<?php echo e(route('admin.affiliates.index')); ?>" class="text-sm text-ink-2 hover:text-ink">Tout voir →</a>
        </div>
        <?php $__empty_1 = true; $__currentLoopData = $recentAffiliates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <a href="<?php echo e(route('admin.affiliates.show', $a)); ?>" class="mb-2 flex items-center justify-between rounded-xl border border-black/10 bg-surface px-4 py-3 text-sm transition-colors hover:border-black/20">
                <div>
                    <p class="text-ink"><?php echo e(trim("{$a->first_name} {$a->last_name}")); ?></p>
                    <p class="font-mono text-xs text-ink-3"><?php echo e($a->affiliate_id); ?></p>
                </div>
                <?php if (isset($component)) { $__componentOriginald271113ca69d52f8dbc84ae4f8468e44 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald271113ca69d52f8dbc84ae4f8468e44 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.status-pill','data' => ['status' => $a->status === 'active' ? 'available' : 'failed']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.status-pill'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($a->status === 'active' ? 'available' : 'failed')]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald271113ca69d52f8dbc84ae4f8468e44)): ?>
<?php $attributes = $__attributesOriginald271113ca69d52f8dbc84ae4f8468e44; ?>
<?php unset($__attributesOriginald271113ca69d52f8dbc84ae4f8468e44); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald271113ca69d52f8dbc84ae4f8468e44)): ?>
<?php $component = $__componentOriginald271113ca69d52f8dbc84ae4f8468e44; ?>
<?php unset($__componentOriginald271113ca69d52f8dbc84ae4f8468e44); ?>
<?php endif; ?>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p class="rounded-xl border border-dashed border-black/10 bg-surface px-4 py-6 text-center text-sm text-ink-3">Aucun affilié.</p>
        <?php endif; ?>
    </section>
</div>


<section class="mt-8">
    <div class="mb-3 flex items-center justify-between">
        <h2 class="font-display text-lg font-semibold text-ink">Activité récente</h2>
        <a href="<?php echo e(route('admin.audit-logs.index')); ?>" class="text-sm text-ink-2 hover:text-ink">Journal complet →</a>
    </div>
    <div class="overflow-hidden rounded-2xl border border-black/10">
        <?php $__empty_1 = true; $__currentLoopData = $recentAudit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="flex items-start justify-between gap-4 border-b border-black/[0.06] px-4 py-3 text-sm last:border-0">
                <div class="min-w-0">
                    <p class="text-ink"><?php echo e($log->description); ?></p>
                    <p class="mt-0.5 font-mono text-[11px] text-ink-3"><?php echo e($log->action); ?></p>
                </div>
                <p class="shrink-0 text-xs text-ink-3">
                    <?php echo e(optional($log->admin)->first_name); ?> · <?php echo e($log->created_at?->format('d/m H:i')); ?>

                </p>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p class="px-4 py-6 text-center text-sm text-ink-3">Aucune action enregistrée.</p>
        <?php endif; ?>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\USER\Documents\GitHub\malkuthar-app\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>