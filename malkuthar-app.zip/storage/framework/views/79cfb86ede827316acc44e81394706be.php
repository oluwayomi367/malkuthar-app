<?php $__env->startSection('title', "Administration — Journal d'audit"); ?>
<?php $__env->startSection('eyebrow', 'Traçabilité'); ?>
<?php $__env->startSection('heading', "Journal d'audit"); ?>

<?php $__env->startSection('content'); ?>
<form method="GET" class="mb-6 flex flex-wrap gap-2">
    <select name="action" onchange="this.form.submit()"
            class="h-11 rounded-xl border border-black/10 bg-surface px-3 text-sm text-ink focus:border-accent focus:outline-none">
        <option value="">Toutes les actions</option>
        <?php $__currentLoopData = $actions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($a); ?>" <?php if($action === $a): echo 'selected'; endif; ?>><?php echo e($a); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <noscript><button class="h-11 rounded-xl border border-black/10 px-4 text-sm font-semibold text-ink">Filtrer</button></noscript>
</form>

<?php if($logs->isEmpty()): ?>
    <?php if (isset($component)) { $__componentOriginal3607a477fdef7402bc742abad5df9c51 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3607a477fdef7402bc742abad5df9c51 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.empty-state','data' => ['title' => 'Journal vide','text' => 'Aucune action enregistrée pour ce filtre.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.empty-state'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Journal vide','text' => 'Aucune action enregistrée pour ce filtre.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3607a477fdef7402bc742abad5df9c51)): ?>
<?php $attributes = $__attributesOriginal3607a477fdef7402bc742abad5df9c51; ?>
<?php unset($__attributesOriginal3607a477fdef7402bc742abad5df9c51); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3607a477fdef7402bc742abad5df9c51)): ?>
<?php $component = $__componentOriginal3607a477fdef7402bc742abad5df9c51; ?>
<?php unset($__componentOriginal3607a477fdef7402bc742abad5df9c51); ?>
<?php endif; ?>
<?php else: ?>
    <div class="overflow-hidden rounded-2xl border border-black/10">
        <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="flex flex-wrap items-start justify-between gap-3 border-b border-black/[0.06] px-4 py-3.5 text-sm last:border-0">
                <div class="min-w-0">
                    <p class="text-ink"><?php echo e($log->description); ?></p>
                    <p class="mt-0.5 flex flex-wrap gap-x-3 font-mono text-[11px] text-ink-3">
                        <span><?php echo e($log->action); ?></span>
                        <?php if($log->ip_address): ?><span>IP <?php echo e($log->ip_address); ?></span><?php endif; ?>
                        <?php if($log->subject_type): ?><span><?php echo e(class_basename($log->subject_type)); ?> #<?php echo e(\Illuminate\Support\Str::limit($log->subject_id, 8, '')); ?></span><?php endif; ?>
                    </p>
                </div>
                <p class="shrink-0 text-right text-xs text-ink-3">
                    <?php echo e(optional($log->admin)->first_name); ?> <?php echo e(optional($log->admin)->last_name); ?><br>
                    <?php echo e($log->created_at?->format('d/m/Y H:i')); ?>

                </p>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <?php if (isset($component)) { $__componentOriginal4d04f29578652eb91560cfbf2ab48c57 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4d04f29578652eb91560cfbf2ab48c57 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.pagination','data' => ['paginator' => $logs]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.pagination'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['paginator' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($logs)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4d04f29578652eb91560cfbf2ab48c57)): ?>
<?php $attributes = $__attributesOriginal4d04f29578652eb91560cfbf2ab48c57; ?>
<?php unset($__attributesOriginal4d04f29578652eb91560cfbf2ab48c57); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4d04f29578652eb91560cfbf2ab48c57)): ?>
<?php $component = $__componentOriginal4d04f29578652eb91560cfbf2ab48c57; ?>
<?php unset($__componentOriginal4d04f29578652eb91560cfbf2ab48c57); ?>
<?php endif; ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\USER\Documents\GitHub\malkuthar-app\resources\views/admin/audit-logs/index.blade.php ENDPATH**/ ?>