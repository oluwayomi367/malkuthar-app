<?php echo e($slot); ?>

<?php /**PATH C:\Users\USER\Documents\GitHub\malkuthar-app\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>