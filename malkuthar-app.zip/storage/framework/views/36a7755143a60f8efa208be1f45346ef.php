<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'variant' => 'primary',   // primary | secondary | ghost
    'href' => null,
    'type' => 'button',
    'full' => false,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'variant' => 'primary',   // primary | secondary | ghost
    'href' => null,
    'type' => 'button',
    'full' => false,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $base = 'group relative inline-flex items-center justify-center gap-2 rounded-xl text-sm font-semibold '
        .'transition-[transform,box-shadow,background-color,opacity] duration-200 '
        .'focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent '
        .'disabled:pointer-events-none disabled:opacity-40 h-11 px-5 sm:h-10';

    $variants = [
        'primary' => 'text-white bg-accent shadow-[0_1px_2px_rgba(46,44,40,0.12)] hover:bg-[#77602a] active:bg-[#6a5624]',
        'secondary' => 'text-ink bg-surface border border-line-strong hover:bg-ground-alt hover:border-ink-3',
        'ghost' => 'text-accent px-2 underline decoration-accent/40 underline-offset-4 hover:decoration-accent',
    ];

    $classes = trim($base.' '.($variants[$variant] ?? $variants['primary']).' '.($full ? 'w-full' : ''));
?>

<?php if($href): ?>
    <a href="<?php echo e($href); ?>" <?php echo e($attributes->merge(['class' => $classes])); ?>><?php echo e($slot); ?></a>
<?php else: ?>
    <button type="<?php echo e($type); ?>" <?php echo e($attributes->merge(['class' => $classes])); ?>><?php echo e($slot); ?></button>
<?php endif; ?>
<?php /**PATH C:\Users\USER\Documents\GitHub\malkuthar-app\resources\views/components/ui/button.blade.php ENDPATH**/ ?>