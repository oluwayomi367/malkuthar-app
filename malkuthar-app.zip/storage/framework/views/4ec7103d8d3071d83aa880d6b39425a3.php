<?php $__env->startSection('title', $offer ? 'Modifier — '.$offer->title : 'Nouvelle offre'); ?>
<?php $__env->startSection('sidebar'); ?><?php if (isset($component)) { $__componentOriginal515b40fd5ac497547291c4605ab60c40 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal515b40fd5ac497547291c4605ab60c40 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout.sidebar-app','data' => ['space' => 'vendor']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout.sidebar-app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['space' => 'vendor']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal515b40fd5ac497547291c4605ab60c40)): ?>
<?php $attributes = $__attributesOriginal515b40fd5ac497547291c4605ab60c40; ?>
<?php unset($__attributesOriginal515b40fd5ac497547291c4605ab60c40); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal515b40fd5ac497547291c4605ab60c40)): ?>
<?php $component = $__componentOriginal515b40fd5ac497547291c4605ab60c40; ?>
<?php unset($__componentOriginal515b40fd5ac497547291c4605ab60c40); ?>
<?php endif; ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php
    use Illuminate\Support\Facades\Storage;

    $isNew = $offer === null;
    $type = old('type', $presetType ?? $offer?->type ?? 'physical');
    $typeLabel = ['physical' => 'Produit physique', 'digital' => 'Produit digital', 'service' => 'Service', 'training' => 'Formation'][$type] ?? $type;
    $d = fn ($k, $default = null) => old("detail.$k", data_get($offer?->detail(), $k, $default));
    $cf = fn ($k) => old("custom_fields.$k", data_get($offer?->custom_fields, $k));
    $live = $offer && $offer->first_published_at !== null;

    $existingVariants = ($offer?->relationLoaded('variants') ? $offer->variants : collect())
        ->map(fn ($v) => ['id' => $v->id, 'values' => $v->option_values ?: new stdClass, 'stock' => $v->stock,
            'price' => $v->price_override, 'sku' => $v->sku, 'active' => $v->is_active])->values();
    $existingAxes = collect($offer?->variants ?? [])->flatMap(fn ($v) => array_keys($v->option_values ?? []))->unique()->values();

    // Onglet à ouvrir si des erreurs de validation existent.
    $tabOf = [
        'infos' => ['category_id', 'title', 'summary', 'description'],
        'price' => ['price', 'sale_price', 'detail'],
        'photos' => ['main_image', 'gallery'],
        'variants' => ['variants'],
        'specs' => ['custom_fields'],
        'seo' => ['seo_title', 'seo_description'],
    ];
    $openTab = 'infos';
    foreach ($tabOf as $tab => $keys) {
        foreach ($keys as $k) {
            if ($errors->has($k) || $errors->has($k.'.*') || collect($errors->keys())->contains(fn ($ek) => str_starts_with($ek, $k.'.'))) {
                $openTab = $tab;
                break 2;
            }
        }
    }

    $tabs = [
        'infos' => 'Informations',
        'price' => 'Prix & stock',
        'photos' => 'Photos',
        'variants' => 'Variantes',
        'specs' => 'Caractéristiques',
        'seo' => 'Référencement',
    ];
    if ($type !== 'physical') unset($tabs['variants']);
    if ($schema->isEmpty() && $isNew) { /* garde l'onglet, il se remplit après choix de catégorie */ }
?>

<div class="mx-auto max-w-4xl" x-data="{ tab: '<?php echo e($openTab); ?>' }">

    
    <div class="flex flex-wrap items-start justify-between gap-3">
        <div>
            <p class="text-[11px] font-semibold uppercase tracking-[0.16em] text-accent"><?php echo e($typeLabel); ?></p>
            <h1 class="mt-1 font-display text-2xl font-bold tracking-[-0.01em] text-ink sm:text-3xl"><?php echo e($isNew ? 'Nouvelle offre' : $offer->title); ?></h1>
            <?php if (! ($isNew)): ?>
                <div class="mt-2 flex flex-wrap items-center gap-2 text-sm">
                    <?php if (isset($component)) { $__componentOriginald271113ca69d52f8dbc84ae4f8468e44 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald271113ca69d52f8dbc84ae4f8468e44 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.status-pill','data' => ['status' => $offer->status]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.status-pill'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($offer->status)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald271113ca69d52f8dbc84ae4f8468e44)): ?>
<?php $attributes = $__attributesOriginald271113ca69d52f8dbc84ae4f8468e44; ?>
<?php unset($__attributesOriginald271113ca69d52f8dbc84ae4f8468e44); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald271113ca69d52f8dbc84ae4f8468e44)): ?>
<?php $component = $__componentOriginald271113ca69d52f8dbc84ae4f8468e44; ?>
<?php unset($__componentOriginald271113ca69d52f8dbc84ae4f8468e44); ?>
<?php endif; ?>
                    <?php if($live): ?><span class="text-xs text-ink-3">Vos modifications remplaceront la version en ligne après validation.</span><?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
        <div class="flex flex-wrap gap-2">
            <?php if($offer?->status === 'approved' && $offer->is_online): ?>
                <?php if (isset($component)) { $__componentOriginala8bb031a483a05f647cb99ed3a469847 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8bb031a483a05f647cb99ed3a469847 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.button','data' => ['variant' => 'secondary','href' => route('marketplace.shop.offer', $offer->slug)]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['variant' => 'secondary','href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('marketplace.shop.offer', $offer->slug))]); ?>Voir en ligne <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8bb031a483a05f647cb99ed3a469847)): ?>
<?php $attributes = $__attributesOriginala8bb031a483a05f647cb99ed3a469847; ?>
<?php unset($__attributesOriginala8bb031a483a05f647cb99ed3a469847); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8bb031a483a05f647cb99ed3a469847)): ?>
<?php $component = $__componentOriginala8bb031a483a05f647cb99ed3a469847; ?>
<?php unset($__componentOriginala8bb031a483a05f647cb99ed3a469847); ?>
<?php endif; ?>
            <?php endif; ?>
            <?php if (isset($component)) { $__componentOriginala8bb031a483a05f647cb99ed3a469847 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8bb031a483a05f647cb99ed3a469847 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.button','data' => ['form' => 'offer-form','type' => 'submit','variant' => 'primary']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['form' => 'offer-form','type' => 'submit','variant' => 'primary']); ?><?php echo e($isNew ? 'Créer le brouillon' : 'Enregistrer'); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8bb031a483a05f647cb99ed3a469847)): ?>
<?php $attributes = $__attributesOriginala8bb031a483a05f647cb99ed3a469847; ?>
<?php unset($__attributesOriginala8bb031a483a05f647cb99ed3a469847); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8bb031a483a05f647cb99ed3a469847)): ?>
<?php $component = $__componentOriginala8bb031a483a05f647cb99ed3a469847; ?>
<?php unset($__componentOriginala8bb031a483a05f647cb99ed3a469847); ?>
<?php endif; ?>
        </div>
    </div>

    <?php if($offer?->review_note && in_array($offer->status, ['changes_requested', 'rejected'], true)): ?>
        <?php if (isset($component)) { $__componentOriginal746de018ded8594083eb43be3f1332e1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal746de018ded8594083eb43be3f1332e1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.alert','data' => ['tone' => 'warning','class' => 'mt-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['tone' => 'warning','class' => 'mt-4']); ?>Retour de l'équipe : <?php echo e($offer->review_note); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal746de018ded8594083eb43be3f1332e1)): ?>
<?php $attributes = $__attributesOriginal746de018ded8594083eb43be3f1332e1; ?>
<?php unset($__attributesOriginal746de018ded8594083eb43be3f1332e1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal746de018ded8594083eb43be3f1332e1)): ?>
<?php $component = $__componentOriginal746de018ded8594083eb43be3f1332e1; ?>
<?php unset($__componentOriginal746de018ded8594083eb43be3f1332e1); ?>
<?php endif; ?>
    <?php endif; ?>
    <?php if($errors->any()): ?>
        <?php if (isset($component)) { $__componentOriginal746de018ded8594083eb43be3f1332e1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal746de018ded8594083eb43be3f1332e1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.alert','data' => ['tone' => 'error','class' => 'mt-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['tone' => 'error','class' => 'mt-4']); ?>Certains champs sont à corriger — voir les onglets signalés. <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal746de018ded8594083eb43be3f1332e1)): ?>
<?php $attributes = $__attributesOriginal746de018ded8594083eb43be3f1332e1; ?>
<?php unset($__attributesOriginal746de018ded8594083eb43be3f1332e1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal746de018ded8594083eb43be3f1332e1)): ?>
<?php $component = $__componentOriginal746de018ded8594083eb43be3f1332e1; ?>
<?php unset($__componentOriginal746de018ded8594083eb43be3f1332e1); ?>
<?php endif; ?>
    <?php endif; ?>

    <div class="mt-6 grid gap-6 lg:grid-cols-[190px_1fr]">

        
        <nav class="flex gap-1 overflow-x-auto rounded-2xl border border-line bg-surface p-1.5 lg:sticky lg:top-24 lg:h-max lg:flex-col lg:self-start">
            <?php $__currentLoopData = $tabs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $tabHasError = collect($tabOf[$key])->contains(fn ($k) => $errors->has($k) || collect($errors->keys())->contains(fn ($ek) => str_starts_with($ek, $k.'.'))); ?>
                <button type="button" x-on:click="tab = '<?php echo e($key); ?>'"
                        :class="tab === '<?php echo e($key); ?>' ? 'bg-accent-soft font-semibold text-accent' : 'text-ink-2 hover:bg-ground-alt hover:text-ink'"
                        class="flex shrink-0 items-center justify-between gap-2 rounded-xl px-3 py-2 text-left text-sm">
                    <?php echo e($label); ?>

                    <?php if($tabHasError): ?><span class="h-1.5 w-1.5 rounded-full bg-rust"></span><?php endif; ?>
                </button>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </nav>

        
        <form id="offer-form" method="POST" enctype="multipart/form-data"
              action="<?php echo e($isNew ? route('vendor.offers.store') : route('vendor.offers.update', $offer)); ?>"
              class="min-w-0">
            <?php echo csrf_field(); ?>
            <?php if (! ($isNew)): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>
            <input type="hidden" name="type" value="<?php echo e($type); ?>">

            
            <section x-show="tab === 'infos'" class="space-y-4 rounded-2xl border border-line bg-surface p-5">
                <h2 class="font-display text-base font-semibold text-ink">Informations</h2>
                <label class="block text-sm">
                    <span class="text-ink-2">Catégorie *</span>
                    <select name="category_id" class="mt-1 h-11 w-full rounded-xl border border-line bg-surface px-3 text-sm">
                        <option value="">Choisir…</option>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(! $c->allowsType($type)) continue; ?>
                            <option value="<?php echo e($c->id); ?>" <?php if(old('category_id', $offer?->category_id) === $c->id): echo 'selected'; endif; ?>><?php echo e(str_repeat('— ', $c->depth)); ?><?php echo e($c->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-xs text-rust"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </label>
                <label class="block text-sm">
                    <span class="text-ink-2">Titre *</span>
                    <input name="title" value="<?php echo e(old('title', $offer?->title)); ?>" class="mt-1 h-11 w-full rounded-xl border border-line bg-surface px-3 text-sm">
                    <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-xs text-rust"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </label>
                <label class="block text-sm">
                    <span class="text-ink-2">Accroche</span>
                    <input name="summary" value="<?php echo e(old('summary', $offer?->summary)); ?>" maxlength="255" class="mt-1 h-11 w-full rounded-xl border border-line bg-surface px-3 text-sm">
                </label>
                <label class="block text-sm">
                    <span class="text-ink-2">Description *</span>
                    <textarea name="description" rows="8" class="mt-1 w-full rounded-xl border border-line bg-surface px-3 py-2 text-sm"><?php echo e(old('description', $offer?->description)); ?></textarea>
                    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-xs text-rust"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </label>
            </section>

            
            <section x-show="tab === 'price'" x-cloak class="space-y-4 rounded-2xl border border-line bg-surface p-5">
                <h2 class="font-display text-base font-semibold text-ink">Prix & stock</h2>
                <div class="grid gap-4 sm:grid-cols-2">
                    <label class="block text-sm">
                        <span class="text-ink-2">Prix *</span>
                        <span class="mt-1 flex h-11 items-center overflow-hidden rounded-xl border border-line bg-surface">
                            <span class="border-r border-line bg-ground-alt px-3 text-xs font-semibold text-ink-3"><?php echo e($offer?->currency ?? 'XOF'); ?></span>
                            <input name="price" type="number" step="0.01" min="0" value="<?php echo e(old('price', $offer?->price)); ?>" class="h-full min-w-0 flex-1 bg-transparent px-3 text-sm outline-none">
                        </span>
                        <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-xs text-rust"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </label>
                    <label class="block text-sm">
                        <span class="text-ink-2">Prix promotionnel</span>
                        <span class="mt-1 flex h-11 items-center overflow-hidden rounded-xl border border-line bg-surface">
                            <span class="border-r border-line bg-ground-alt px-3 text-xs font-semibold text-ink-3"><?php echo e($offer?->currency ?? 'XOF'); ?></span>
                            <input name="sale_price" type="number" step="0.01" min="0" value="<?php echo e(old('sale_price', $offer?->sale_price)); ?>" class="h-full min-w-0 flex-1 bg-transparent px-3 text-sm outline-none">
                        </span>
                        <?php $__errorArgs = ['sale_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-xs text-rust"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </label>
                </div>

                <?php if($type === 'physical'): ?>
                    <div class="grid gap-3 rounded-xl border border-line bg-ground-alt/40 p-3 sm:grid-cols-3">
                        <label class="text-sm">SKU<input name="detail[sku]" value="<?php echo e($d('sku')); ?>" class="mt-1 h-9 w-full rounded-lg border border-line bg-surface px-2"></label>
                        <label class="text-sm">Stock (sans variante)<input name="detail[stock]" type="number" min="0" value="<?php echo e($d('stock', 0)); ?>" class="mt-1 h-9 w-full rounded-lg border border-line bg-surface px-2"></label>
                        <label class="text-sm">Poids (g)<input name="detail[weight_grams]" type="number" min="0" value="<?php echo e($d('weight_grams')); ?>" class="mt-1 h-9 w-full rounded-lg border border-line bg-surface px-2"></label>
                        <label class="text-sm">Longueur (mm)<input name="detail[length_mm]" type="number" min="0" value="<?php echo e($d('length_mm')); ?>" class="mt-1 h-9 w-full rounded-lg border border-line bg-surface px-2"></label>
                        <label class="text-sm">Largeur (mm)<input name="detail[width_mm]" type="number" min="0" value="<?php echo e($d('width_mm')); ?>" class="mt-1 h-9 w-full rounded-lg border border-line bg-surface px-2"></label>
                        <label class="text-sm">Hauteur (mm)<input name="detail[height_mm]" type="number" min="0" value="<?php echo e($d('height_mm')); ?>" class="mt-1 h-9 w-full rounded-lg border border-line bg-surface px-2"></label>
                        <label class="text-sm sm:col-span-2">Provenance<input name="detail[origin_region]" value="<?php echo e($d('origin_region')); ?>" class="mt-1 h-9 w-full rounded-lg border border-line bg-surface px-2"></label>
                        <label class="text-sm">Préparation (j)<input name="detail[handling_days]" type="number" min="0" value="<?php echo e($d('handling_days')); ?>" class="mt-1 h-9 w-full rounded-lg border border-line bg-surface px-2"></label>
                    </div>
                <?php elseif($type === 'digital'): ?>
                    <div class="grid gap-3 rounded-xl border border-line bg-ground-alt/40 p-3 sm:grid-cols-2">
                        <label class="text-sm">Livraison
                            <select name="detail[delivery_type]" class="mt-1 h-9 w-full rounded-lg border border-line bg-surface px-2">
                                <?php $__currentLoopData = ['file' => 'Fichier', 'external_link' => 'Lien externe', 'license_keys' => 'Clés de licence']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($k); ?>" <?php if($d('delivery_type', 'file') === $k): echo 'selected'; endif; ?>><?php echo e($l); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </label>
                        <label class="text-sm">URL externe<input name="detail[external_url]" value="<?php echo e($d('external_url')); ?>" class="mt-1 h-9 w-full rounded-lg border border-line bg-surface px-2"></label>
                        <label class="text-sm">Chemin fichier<input name="detail[file_path]" value="<?php echo e($d('file_path')); ?>" placeholder="uploads/…" class="mt-1 h-9 w-full rounded-lg border border-line bg-surface px-2"></label>
                        <label class="text-sm">Version<input name="detail[version_label]" value="<?php echo e($d('version_label')); ?>" class="mt-1 h-9 w-full rounded-lg border border-line bg-surface px-2"></label>
                    </div>
                <?php elseif($type === 'service'): ?>
                    <div class="grid gap-3 rounded-xl border border-line bg-ground-alt/40 p-3 sm:grid-cols-3">
                        <label class="text-sm">Durée (min)<input name="detail[duration_minutes]" type="number" min="5" value="<?php echo e($d('duration_minutes', 60)); ?>" class="mt-1 h-9 w-full rounded-lg border border-line bg-surface px-2"></label>
                        <label class="text-sm">Mode
                            <select name="detail[delivery_mode]" class="mt-1 h-9 w-full rounded-lg border border-line bg-surface px-2">
                                <?php $__currentLoopData = ['online' => 'En ligne', 'onsite' => 'Sur place', 'either' => 'Les deux']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($k); ?>" <?php if($d('delivery_mode', 'online') === $k): echo 'selected'; endif; ?>><?php echo e($l); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </label>
                        <label class="text-sm">Places / créneau<input name="detail[capacity_per_slot]" type="number" min="1" value="<?php echo e($d('capacity_per_slot', 1)); ?>" class="mt-1 h-9 w-full rounded-lg border border-line bg-surface px-2"></label>
                        <label class="text-sm sm:col-span-2">Lieu<input name="detail[location]" value="<?php echo e($d('location')); ?>" class="mt-1 h-9 w-full rounded-lg border border-line bg-surface px-2"></label>
                        <label class="text-sm">Préavis (h)<input name="detail[min_notice_hours]" type="number" min="0" value="<?php echo e($d('min_notice_hours', 24)); ?>" class="mt-1 h-9 w-full rounded-lg border border-line bg-surface px-2"></label>
                    </div>
                <?php elseif($type === 'training'): ?>
                    <div class="grid gap-3 rounded-xl border border-line bg-ground-alt/40 p-3 sm:grid-cols-3">
                        <label class="text-sm">Format
                            <select name="detail[format]" class="mt-1 h-9 w-full rounded-lg border border-line bg-surface px-2">
                                <?php $__currentLoopData = ['self_paced' => 'En autonomie', 'cohort' => 'Cohorte', 'live' => 'Live']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($k); ?>" <?php if($d('format', 'self_paced') === $k): echo 'selected'; endif; ?>><?php echo e($l); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </label>
                        <label class="text-sm">Langue<input name="detail[language]" value="<?php echo e($d('language', 'fr')); ?>" class="mt-1 h-9 w-full rounded-lg border border-line bg-surface px-2"></label>
                        <label class="text-sm">Niveau
                            <select name="detail[level]" class="mt-1 h-9 w-full rounded-lg border border-line bg-surface px-2">
                                <option value="">—</option>
                                <?php $__currentLoopData = ['beginner' => 'Débutant', 'intermediate' => 'Intermédiaire', 'advanced' => 'Avancé']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($k); ?>" <?php if($d('level') === $k): echo 'selected'; endif; ?>><?php echo e($l); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </label>
                        <label class="text-sm">Places<input name="detail[seats]" type="number" min="1" value="<?php echo e($d('seats')); ?>" class="mt-1 h-9 w-full rounded-lg border border-line bg-surface px-2"></label>
                        <label class="text-sm">Accès (jours)<input name="detail[access_days]" type="number" min="1" value="<?php echo e($d('access_days')); ?>" class="mt-1 h-9 w-full rounded-lg border border-line bg-surface px-2"></label>
                    </div>
                <?php endif; ?>
            </section>

            
            <section x-show="tab === 'photos'" x-cloak class="rounded-2xl border border-line bg-surface p-5"
                     x-data="{ main: null, gallery: [], pick(e, t) { t === 'main' ? this.main = e.target.files[0] ? URL.createObjectURL(e.target.files[0]) : null : this.gallery = [...e.target.files].map(f => URL.createObjectURL(f)); } }">
                <h2 class="font-display text-base font-semibold text-ink">Photos</h2>
                <p class="mt-1 text-xs text-ink-3">Image principale nette + jusqu'à 12 photos. JPG, PNG ou WebP, 5 Mo max.</p>
                <div class="mt-4 grid gap-4 sm:grid-cols-[10rem_1fr]">
                    <div>
                        <div class="aspect-square overflow-hidden rounded-xl border border-line bg-ground-alt">
                            <template x-if="main"><img :src="main" alt="" class="h-full w-full object-cover"></template>
                            <template x-if="!main">
                                <?php if($offer?->main_image_path): ?>
                                    <img src="<?php echo e(Storage::url($offer->main_image_path)); ?>" alt="" class="h-full w-full object-cover">
                                <?php else: ?>
                                    <div class="flex h-full items-center justify-center text-line-strong"><svg class="h-8 w-8" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1"><path d="M4 16l4-4 4 4 4-6 4 6M4 5h16v14H4z"/></svg></div>
                                <?php endif; ?>
                            </template>
                        </div>
                        <input type="file" name="main_image" accept="image/*" x-on:change="pick($event,'main')" class="mt-2 block w-full text-xs text-ink-2 file:mr-2 file:rounded-lg file:border-0 file:bg-ground-alt file:px-2 file:py-1.5">
                        <?php if($offer?->main_image_path): ?>
                            <label class="mt-1 flex items-center gap-1.5 text-xs text-ink-3"><input type="checkbox" name="remove_main_image" value="1" class="h-3.5 w-3.5 rounded border-line-strong text-accent">Retirer</label>
                        <?php endif; ?>
                        <?php $__errorArgs = ['main_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-xs text-rust"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div>
                        <?php if(! empty($offer?->gallery)): ?>
                            <div class="grid grid-cols-4 gap-2">
                                <?php $__currentLoopData = $offer->gallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $path): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <label class="relative block">
                                        <img src="<?php echo e(Storage::url($path)); ?>" alt="" class="aspect-square w-full rounded-lg border border-line object-cover">
                                        <span class="absolute right-1 top-1 flex items-center gap-1 rounded bg-ground/90 px-1 text-[10px] text-rust"><input type="checkbox" name="gallery_remove[]" value="<?php echo e($path); ?>" class="h-3 w-3 rounded border-line-strong text-rust">×</span>
                                    </label>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php endif; ?>
                        <input type="file" name="gallery[]" accept="image/*" multiple x-on:change="pick($event,'gallery')" class="mt-2 block w-full text-xs text-ink-2 file:mr-2 file:rounded-lg file:border-0 file:bg-ground-alt file:px-2 file:py-1.5">
                        <div class="mt-2 flex flex-wrap gap-2"><template x-for="(g,i) in gallery" :key="i"><img :src="g" alt="" class="h-14 w-14 rounded-lg border border-line object-cover"></template></div>
                        <?php $__errorArgs = ['gallery.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-xs text-rust"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
            </section>

            
            <?php if($type === 'physical'): ?>
                <section x-show="tab === 'variants'" x-cloak class="rounded-2xl border border-line bg-surface p-5"
                         x-data="offerVariants(<?php echo e(Illuminate\Support\Js::from($existingAxes)); ?>, <?php echo e(Illuminate\Support\Js::from($existingVariants)); ?>)">
                    <div class="flex items-center justify-between">
                        <h2 class="font-display text-base font-semibold text-ink">Variantes</h2>
                        <label class="flex items-center gap-2 text-sm text-ink-2">
                            <input type="checkbox" x-model="enabled" class="h-4 w-4 rounded border-line-strong text-accent">
                            Déclinaisons (couleur, taille…)
                        </label>
                    </div>
                    <template x-if="!enabled"><p class="mt-3 text-sm text-ink-3">Une seule version de ce produit — le stock est celui de l'onglet « Prix & stock ».</p></template>
                    <div x-show="enabled" x-cloak class="mt-4 space-y-4">
                        <div class="flex flex-wrap items-center gap-2">
                            <template x-for="(axis,ai) in axes" :key="ai">
                                <span class="inline-flex items-center gap-1 rounded-lg border border-line bg-ground-alt px-2 py-1 text-xs">
                                    <input x-model="axes[ai]" class="w-20 bg-transparent capitalize outline-none" placeholder="Axe">
                                    <button type="button" x-on:click="axes.splice(ai,1)" class="text-ink-3 hover:text-rust">×</button>
                                </span>
                            </template>
                            <button type="button" x-on:click="axes.push('')" class="rounded-lg border border-dashed border-line-strong px-2 py-1 text-xs text-ink-2">+ axe</button>
                        </div>
                        <div class="overflow-x-auto">
                            <table class="w-full min-w-[38rem] text-sm">
                                <thead class="text-left text-[11px] uppercase text-ink-3">
                                    <tr>
                                        <template x-for="axis in axes" :key="axis"><th class="pb-1 pr-2 capitalize" x-text="axis || 'Option'"></th></template>
                                        <th class="pb-1 pr-2">Stock</th><th class="pb-1 pr-2">Prix</th><th class="pb-1 pr-2">SKU</th><th class="pb-1 pr-2">Actif</th><th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <template x-for="(row,ri) in rows" :key="ri">
                                        <tr class="border-t border-line">
                                            <template x-for="axis in axes" :key="axis">
                                                <td class="py-1 pr-2"><input x-model="row.values[axis]" :name="`variants[${ri}][option_values][${axis}]`" class="h-8 w-24 rounded border border-line bg-surface px-1.5"></td>
                                            </template>
                                            <td class="py-1 pr-2"><input type="number" min="0" x-model="row.stock" :name="`variants[${ri}][stock]`" class="h-8 w-16 rounded border border-line bg-surface px-1.5"></td>
                                            <td class="py-1 pr-2"><input type="number" min="0" step="0.01" x-model="row.price" :name="`variants[${ri}][price_override]`" class="h-8 w-20 rounded border border-line bg-surface px-1.5"></td>
                                            <td class="py-1 pr-2"><input x-model="row.sku" :name="`variants[${ri}][sku]`" class="h-8 w-24 rounded border border-line bg-surface px-1.5"></td>
                                            <td class="py-1 pr-2 text-center">
                                                <input type="checkbox" x-model="row.active" class="h-4 w-4 rounded border-line-strong text-accent">
                                                <input type="hidden" :name="`variants[${ri}][is_active]`" :value="row.active ? 1 : 0">
                                                <input type="hidden" :name="`variants[${ri}][id]`" :value="row.id || ''">
                                            </td>
                                            <td class="py-1"><button type="button" x-on:click="rows.splice(ri,1)" class="text-ink-3 hover:text-rust">Retirer</button></td>
                                        </tr>
                                    </template>
                                </tbody>
                            </table>
                        </div>
                        <button type="button" x-on:click="rows.push({id:null,values:{},stock:0,price:'',sku:'',active:true})" class="rounded-lg border border-dashed border-line-strong px-3 py-1.5 text-xs font-semibold text-ink-2">+ Ajouter une variante</button>
                        <?php $__errorArgs = ['variants'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-xs text-rust"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </section>
            <?php endif; ?>

            
            <section x-show="tab === 'specs'" x-cloak class="rounded-2xl border border-line bg-surface p-5">
                <h2 class="font-display text-base font-semibold text-ink">Caractéristiques</h2>
                <?php if($schema->isEmpty()): ?>
                    <p class="mt-2 text-sm text-ink-3">Cette catégorie n'a pas de caractéristique particulière.</p>
                <?php else: ?>
                    <div class="mt-4 grid gap-4 sm:grid-cols-2">
                        <?php $__currentLoopData = $schema; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <label class="block text-sm">
                                <span class="text-ink-2"><?php echo e($field->label); ?><?php if($field->is_required): ?> *<?php endif; ?></span>
                                <?php if(in_array($field->type, ['text', 'url', 'date'], true)): ?>
                                    <input name="custom_fields[<?php echo e($field->key); ?>]" value="<?php echo e($cf($field->key)); ?>" class="mt-1 h-9 w-full rounded-lg border border-line bg-surface px-2 text-sm">
                                <?php elseif($field->type === 'number'): ?>
                                    <input type="number" step="any" name="custom_fields[<?php echo e($field->key); ?>]" value="<?php echo e($cf($field->key)); ?>" class="mt-1 h-9 w-full rounded-lg border border-line bg-surface px-2 text-sm">
                                <?php elseif($field->type === 'textarea'): ?>
                                    <textarea name="custom_fields[<?php echo e($field->key); ?>]" rows="2" class="mt-1 w-full rounded-lg border border-line bg-surface px-2 py-1.5 text-sm"><?php echo e($cf($field->key)); ?></textarea>
                                <?php elseif($field->type === 'boolean'): ?>
                                    <select name="custom_fields[<?php echo e($field->key); ?>]" class="mt-1 h-9 w-full rounded-lg border border-line bg-surface px-2 text-sm">
                                        <option value="">—</option><option value="1" <?php if($cf($field->key) == '1'): echo 'selected'; endif; ?>>Oui</option><option value="0" <?php if($cf($field->key) === '0'): echo 'selected'; endif; ?>>Non</option>
                                    </select>
                                <?php elseif($field->type === 'select'): ?>
                                    <select name="custom_fields[<?php echo e($field->key); ?>]" class="mt-1 h-9 w-full rounded-lg border border-line bg-surface px-2 text-sm">
                                        <option value="">—</option>
                                        <?php $__currentLoopData = $field->options ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($opt['value']); ?>" <?php if($cf($field->key) === $opt['value']): echo 'selected'; endif; ?>><?php echo e($opt['label']); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                <?php elseif($field->type === 'multiselect'): ?>
                                    <select name="custom_fields[<?php echo e($field->key); ?>][]" multiple size="3" class="mt-1 w-full rounded-lg border border-line bg-surface px-2 py-1 text-sm">
                                        <?php $__currentLoopData = $field->options ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($opt['value']); ?>" <?php if(in_array($opt['value'], (array) $cf($field->key), true)): echo 'selected'; endif; ?>><?php echo e($opt['label']); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                <?php endif; ?>
                                <?php if($field->help_text): ?><span class="text-[11px] text-ink-3"><?php echo e($field->help_text); ?></span><?php endif; ?>
                                <?php $__errorArgs = ["custom_fields.{$field->key}"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-xs text-rust"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </label>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>
            </section>

            
            <section x-show="tab === 'seo'" x-cloak class="space-y-4 rounded-2xl border border-line bg-surface p-5">
                <h2 class="font-display text-base font-semibold text-ink">Référencement</h2>
                <label class="block text-sm"><span class="text-ink-2">Titre SEO</span>
                    <input name="seo_title" value="<?php echo e(old('seo_title', $offer?->seo_title)); ?>" maxlength="160" class="mt-1 h-11 w-full rounded-xl border border-line bg-surface px-3 text-sm"></label>
                <label class="block text-sm"><span class="text-ink-2">Description SEO</span>
                    <textarea name="seo_description" rows="3" maxlength="255" class="mt-1 w-full rounded-xl border border-line bg-surface px-3 py-2 text-sm"><?php echo e(old('seo_description', $offer?->seo_description)); ?></textarea></label>
            </section>

            <div class="mt-4">
                <?php if (isset($component)) { $__componentOriginala8bb031a483a05f647cb99ed3a469847 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8bb031a483a05f647cb99ed3a469847 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.button','data' => ['type' => 'submit','variant' => 'primary']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'submit','variant' => 'primary']); ?><?php echo e($isNew ? 'Créer le brouillon' : 'Enregistrer'); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8bb031a483a05f647cb99ed3a469847)): ?>
<?php $attributes = $__attributesOriginala8bb031a483a05f647cb99ed3a469847; ?>
<?php unset($__attributesOriginala8bb031a483a05f647cb99ed3a469847); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8bb031a483a05f647cb99ed3a469847)): ?>
<?php $component = $__componentOriginala8bb031a483a05f647cb99ed3a469847; ?>
<?php unset($__componentOriginala8bb031a483a05f647cb99ed3a469847); ?>
<?php endif; ?>
            </div>
        </form>
    </div>

    
    <?php if (! ($isNew)): ?>
        <div class="mt-5 flex flex-wrap gap-2 border-t border-line pt-4">
            <?php if($offer->canBeSubmitted() || ($live && $offer->revisions()->where('state', 'pending')->exists())): ?>
                <form method="POST" action="<?php echo e(route('vendor.offers.submit', $offer)); ?>"><?php echo csrf_field(); ?>
                    <button class="h-10 rounded-xl border border-accent bg-accent/10 px-4 text-sm font-semibold text-accent">Soumettre à validation</button>
                </form>
            <?php endif; ?>
            <?php if($offer->status === 'pending_review'): ?>
                <form method="POST" action="<?php echo e(route('vendor.offers.withdraw', $offer)); ?>"><?php echo csrf_field(); ?>
                    <button class="h-10 rounded-xl border border-line px-4 text-sm font-semibold text-ink-2">Retirer la soumission</button>
                </form>
            <?php endif; ?>
            <?php if($offer->status === 'approved'): ?>
                <form method="POST" action="<?php echo e(route($offer->is_online ? 'vendor.offers.unpublish' : 'vendor.offers.publish', $offer)); ?>"><?php echo csrf_field(); ?>
                    <button class="h-10 rounded-xl border border-line px-4 text-sm font-semibold text-ink-2"><?php echo e($offer->is_online ? 'Retirer de la vente' : 'Remettre en vente'); ?></button>
                </form>
            <?php endif; ?>
            <?php if (! ($offer->status === 'pending_review')): ?>
                <form method="POST" action="<?php echo e(route('vendor.offers.destroy', $offer)); ?>" onsubmit="return confirm('Supprimer cette offre ?')"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                    <button class="h-10 rounded-xl border border-rust/40 px-4 text-sm font-semibold text-rust">Supprimer</button>
                </form>
            <?php endif; ?>
        </div>
    <?php endif; ?>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
    document.addEventListener('alpine:init', () => {
        Alpine.data('offerVariants', (axes, rows) => ({
            enabled: rows.length > 0,
            axes: axes.length ? axes : ['Couleur', 'Taille'],
            rows: rows.map(r => ({ id: r.id, values: r.values || {}, stock: r.stock ?? 0, price: r.price ?? '', sku: r.sku ?? '', active: r.active ?? true })),
        }));
    });
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\USER\Documents\GitHub\malkuthar-app\resources\views/vendor/offers/form.blade.php ENDPATH**/ ?>