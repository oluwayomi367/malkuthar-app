<?php $__env->startSection('title', 'Administration — Catégories Marketplace'); ?>
<?php $__env->startSection('eyebrow', 'Marketplace'); ?>
<?php $__env->startSection('heading', 'Catalogue — catégories'); ?>

<?php $__env->startSection('content'); ?>
<?php
    $types = ['physical' => 'Physique', 'digital' => 'Digital', 'service' => 'Service', 'training' => 'Formation'];
    $fieldTypes = [
        'text' => 'Texte', 'textarea' => 'Texte long', 'number' => 'Nombre', 'boolean' => 'Oui/Non',
        'select' => 'Liste (choix unique)', 'multiselect' => 'Liste (choix multiples)',
        'date' => 'Date', 'url' => 'Lien', 'file' => 'Fichier',
    ];
    $e = $editing;
    $ruleset = $e?->ruleset ?? ['require_approval' => true];
    $pct = fn ($r) => $r === null ? '' : rtrim(rtrim(number_format($r * 100, 2, '.', ''), '0'), '.');
?>

<div class="grid gap-6 lg:grid-cols-[1fr_1.3fr]">

    
    <div>
        <div class="rounded-2xl border border-black/10 bg-surface p-4">
            <div class="flex items-center justify-between">
                <h2 class="font-display text-base font-semibold text-ink">Arbre (<?php echo e($categories->count()); ?>)</h2>
                <a href="<?php echo e(route('admin.marketplace.categories.index')); ?>" class="text-xs font-semibold text-accent hover:underline">+ Nouvelle racine</a>
            </div>

            <?php if($tree === []): ?>
                <p class="mt-3 text-sm text-ink-3">Aucune catégorie. Créez-en une avec le formulaire.</p>
            <?php else: ?>
                <ul class="mt-3 space-y-0.5 text-sm">
                    <?php $__currentLoopData = $tree; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $cat = $row['category']; ?>
                        <li>
                            <a href="<?php echo e(route('admin.marketplace.categories.index', ['edit' => $cat->id])); ?>"
                               class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                                   'flex items-center justify-between rounded-lg px-2 py-1.5',
                                   'bg-accent/10 font-semibold text-accent' => $e && $e->id === $cat->id,
                                   'text-ink-2 hover:bg-black/[0.04] hover:text-ink' => ! ($e && $e->id === $cat->id),
                               ]); ?>"
                               style="padding-left: <?php echo e(0.5 + $row['depth'] * 1.1); ?>rem">
                                <span>
                                    <?php echo e($cat->name); ?>

                                    <?php if (! ($cat->is_active)): ?><span class="ml-1 text-[10px] uppercase text-rust">masquée</span><?php endif; ?>
                                </span>
                                <span class="text-[11px] text-ink-3"><?php echo e($cat->fields_count); ?> ch.</span>
                            </a>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php endif; ?>
        </div>
    </div>

    
    <div class="space-y-6">
        <form method="POST"
              action="<?php echo e($e ? route('admin.marketplace.categories.update', $e) : route('admin.marketplace.categories.store')); ?>"
              class="rounded-2xl border border-black/10 bg-surface p-5">
            <?php echo csrf_field(); ?>
            <?php if($e): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>

            <div class="flex items-center justify-between">
                <h2 class="font-display text-base font-semibold text-ink"><?php echo e($e ? 'Modifier' : 'Nouvelle catégorie'); ?></h2>
                <?php if($e): ?>
                    <button form="delete-cat-<?php echo e($e->id); ?>" class="text-xs font-semibold text-rust hover:underline">Supprimer</button>
                <?php endif; ?>
            </div>

            <div class="mt-4 grid gap-4">
                <div class="grid gap-4 sm:grid-cols-2">
                    <label class="text-sm">
                        <span class="text-ink-2">Nom *</span>
                        <input name="name" required value="<?php echo e(old('name', $e?->name)); ?>"
                               class="mt-1 h-10 w-full rounded-xl border border-black/10 bg-surface px-3 text-sm">
                    </label>
                    <label class="text-sm">
                        <span class="text-ink-2">Parent</span>
                        <select name="parent_id" class="mt-1 h-10 w-full rounded-xl border border-black/10 bg-surface px-3 text-sm">
                            <option value="">— racine —</option>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($e && $c->id === $e->id) continue; ?>
                                <option value="<?php echo e($c->id); ?>" <?php if(old('parent_id', $e?->parent_id) === $c->id): echo 'selected'; endif; ?>>
                                    <?php echo e(str_repeat('— ', $c->depth)); ?><?php echo e($c->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </label>
                </div>

                <label class="text-sm">
                    <span class="text-ink-2">Description</span>
                    <textarea name="description" rows="2"
                              class="mt-1 w-full rounded-xl border border-black/10 bg-surface px-3 py-2 text-sm"><?php echo e(old('description', $e?->description)); ?></textarea>
                </label>

                <fieldset>
                    <legend class="text-sm text-ink-2">Types d'offres admis *</legend>
                    <div class="mt-1 flex flex-wrap gap-3">
                        <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $lbl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <label class="inline-flex items-center gap-1.5 text-sm">
                                <input type="checkbox" name="applicable_offer_types[]" value="<?php echo e($key); ?>"
                                       <?php if(in_array($key, old('applicable_offer_types', $e?->applicable_offer_types ?? ['physical','digital','service','training']), true)): echo 'checked'; endif; ?>
                                       class="h-4 w-4 rounded border-line-strong text-accent focus:ring-accent/30">
                                <?php echo e($lbl); ?>

                            </label>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <?php $__errorArgs = ['applicable_offer_types'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="mt-1 text-xs text-rust"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </fieldset>

                <div class="grid gap-4 sm:grid-cols-3">
                    <label class="text-sm">
                        <span class="text-ink-2">Commission (%)</span>
                        <input name="commission_rate_percent" type="number" step="0.01" min="0" max="90"
                               value="<?php echo e(old('commission_rate_percent', $pct($e?->commission_rate))); ?>"
                               placeholder="défaut"
                               class="mt-1 h-10 w-full rounded-xl border border-black/10 bg-surface px-3 text-sm">
                    </label>
                    <label class="text-sm">
                        <span class="text-ink-2">Position</span>
                        <input name="position" type="number" min="0" value="<?php echo e(old('position', $e?->position ?? 0)); ?>"
                               class="mt-1 h-10 w-full rounded-xl border border-black/10 bg-surface px-3 text-sm">
                    </label>
                    <label class="mt-6 inline-flex items-center gap-2 text-sm">
                        <input type="checkbox" name="is_active" value="1" <?php if(old('is_active', $e?->is_active ?? true)): echo 'checked'; endif; ?>
                               class="h-4 w-4 rounded border-line-strong text-accent focus:ring-accent/30">
                        Active
                    </label>
                </div>

                <fieldset class="rounded-xl border border-black/[0.06] bg-ground-alt/50 p-3">
                    <legend class="px-1 text-xs font-semibold uppercase tracking-wide text-ink-3">Règles</legend>
                    <div class="grid gap-3 sm:grid-cols-2">
                        <label class="inline-flex items-center gap-2 text-sm">
                            <input type="checkbox" name="ruleset[require_approval]" value="1"
                                   <?php if(old('ruleset.require_approval', $ruleset['require_approval'] ?? true)): echo 'checked'; endif; ?>
                                   class="h-4 w-4 rounded border-line-strong text-accent focus:ring-accent/30">
                            Validation admin obligatoire
                        </label>
                        <label class="inline-flex items-center gap-2 text-sm">
                            <input type="checkbox" name="ruleset[requires_shipping]" value="1"
                                   <?php if(old('ruleset.requires_shipping', $ruleset['requires_shipping'] ?? false)): echo 'checked'; endif; ?>
                                   class="h-4 w-4 rounded border-line-strong text-accent focus:ring-accent/30">
                            Livraison requise
                        </label>
                        <label class="inline-flex items-center gap-2 text-sm">
                            <input type="checkbox" name="ruleset[allow_variants]" value="1"
                                   <?php if(old('ruleset.allow_variants', $ruleset['allow_variants'] ?? false)): echo 'checked'; endif; ?>
                                   class="h-4 w-4 rounded border-line-strong text-accent focus:ring-accent/30">
                            Variantes autorisées
                        </label>
                        <div class="grid grid-cols-3 gap-2">
                            <input name="ruleset[min_price]" type="number" step="0.01" min="0" placeholder="Prix min"
                                   value="<?php echo e(old('ruleset.min_price', $ruleset['min_price'] ?? '')); ?>"
                                   class="h-9 rounded-lg border border-black/10 bg-surface px-2 text-xs">
                            <input name="ruleset[max_price]" type="number" step="0.01" min="0" placeholder="Prix max"
                                   value="<?php echo e(old('ruleset.max_price', $ruleset['max_price'] ?? '')); ?>"
                                   class="h-9 rounded-lg border border-black/10 bg-surface px-2 text-xs">
                            <input name="ruleset[max_images]" type="number" min="1" max="20" placeholder="Img max"
                                   value="<?php echo e(old('ruleset.max_images', $ruleset['max_images'] ?? '')); ?>"
                                   class="h-9 rounded-lg border border-black/10 bg-surface px-2 text-xs">
                        </div>
                    </div>
                </fieldset>

                <div>
                    <?php if (isset($component)) { $__componentOriginala8bb031a483a05f647cb99ed3a469847 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8bb031a483a05f647cb99ed3a469847 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.button','data' => ['type' => 'submit','variant' => 'primary']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'submit','variant' => 'primary']); ?><?php echo e($e ? 'Enregistrer' : 'Créer la catégorie'); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8bb031a483a05f647cb99ed3a469847)): ?>
<?php $attributes = $__attributesOriginala8bb031a483a05f647cb99ed3a469847; ?>
<?php unset($__attributesOriginala8bb031a483a05f647cb99ed3a469847); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8bb031a483a05f647cb99ed3a469847)): ?>
<?php $component = $__componentOriginala8bb031a483a05f647cb99ed3a469847; ?>
<?php unset($__componentOriginala8bb031a483a05f647cb99ed3a469847); ?>
<?php endif; ?>
                </div>
            </div>
        </form>

        <?php if($e): ?>
            <form method="POST" action="<?php echo e(route('admin.marketplace.categories.destroy', $e)); ?>" id="delete-cat-<?php echo e($e->id); ?>"
                  onsubmit="return confirm('Supprimer cette catégorie ?')">
                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
            </form>

            
            <div class="rounded-2xl border border-black/10 bg-surface p-5" x-data="{ type: 'text' }">
                <h2 class="font-display text-base font-semibold text-ink">Champs personnalisés — <?php echo e($e->name); ?></h2>
                <p class="mt-1 text-xs text-ink-3">Les offres de cette catégorie héritent aussi des champs de ses catégories parentes.</p>

                <?php if($e->fields->isNotEmpty()): ?>
                    <table class="mt-3 w-full text-sm">
                        <tbody class="divide-y divide-black/[0.06]">
                            <?php $__currentLoopData = $e->fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="py-2">
                                        <span class="font-mono text-xs text-ink-3"><?php echo e($f->key); ?></span>
                                        <span class="ml-2 text-ink"><?php echo e($f->label); ?></span>
                                    </td>
                                    <td class="py-2 text-ink-2"><?php echo e($fieldTypes[$f->type] ?? $f->type); ?></td>
                                    <td class="py-2 text-xs text-ink-3">
                                        <?php if($f->is_required): ?> requis <?php endif; ?>
                                        <?php if($f->is_filterable): ?> · facette <?php endif; ?>
                                        <?php if($f->is_variant_axis): ?> · variante <?php endif; ?>
                                    </td>
                                    <td class="py-2 text-right">
                                        <form method="POST" action="<?php echo e(route('admin.marketplace.categories.fields.destroy', [$e, $f])); ?>"
                                              onsubmit="return confirm('Supprimer ce champ ?')">
                                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                            <button class="text-xs text-rust hover:underline">Supprimer</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                <?php endif; ?>

                <form method="POST" action="<?php echo e(route('admin.marketplace.categories.fields.store', $e)); ?>" class="mt-4 grid gap-3 border-t border-black/[0.06] pt-4">
                    <?php echo csrf_field(); ?>
                    <div class="grid gap-3 sm:grid-cols-2">
                        <label class="text-sm">
                            <span class="text-ink-2">Libellé *</span>
                            <input name="label" required class="mt-1 h-10 w-full rounded-xl border border-black/10 bg-surface px-3 text-sm">
                        </label>
                        <label class="text-sm">
                            <span class="text-ink-2">Type</span>
                            <select name="type" x-model="type" class="mt-1 h-10 w-full rounded-xl border border-black/10 bg-surface px-3 text-sm">
                                <?php $__currentLoopData = $fieldTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $lbl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($k); ?>"><?php echo e($lbl); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </label>
                    </div>

                    <label class="text-sm">
                        <span class="text-ink-2">Clé machine (facultatif — déduite du libellé)</span>
                        <input name="key" placeholder="ex. matiere" class="mt-1 h-10 w-full rounded-xl border border-black/10 bg-surface px-3 font-mono text-xs">
                    </label>

                    <label class="text-sm" x-show="type === 'select' || type === 'multiselect'" x-cloak>
                        <span class="text-ink-2">Options (une par ligne)</span>
                        <textarea name="options_text" rows="3" class="mt-1 w-full rounded-xl border border-black/10 bg-surface px-3 py-2 text-sm"></textarea>
                    </label>

                    <div class="flex flex-wrap gap-4 text-sm">
                        <label class="inline-flex items-center gap-1.5"><input type="checkbox" name="is_required" value="1" class="h-4 w-4 rounded border-line-strong text-accent">Requis</label>
                        <label class="inline-flex items-center gap-1.5"><input type="checkbox" name="is_filterable" value="1" class="h-4 w-4 rounded border-line-strong text-accent">Facette de recherche</label>
                        <label class="inline-flex items-center gap-1.5" x-show="type === 'select'" x-cloak><input type="checkbox" name="is_variant_axis" value="1" class="h-4 w-4 rounded border-line-strong text-accent">Axe de variante</label>
                    </div>

                    <div>
                        <?php if (isset($component)) { $__componentOriginala8bb031a483a05f647cb99ed3a469847 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8bb031a483a05f647cb99ed3a469847 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.button','data' => ['type' => 'submit','variant' => 'secondary']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'submit','variant' => 'secondary']); ?>Ajouter le champ <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8bb031a483a05f647cb99ed3a469847)): ?>
<?php $attributes = $__attributesOriginala8bb031a483a05f647cb99ed3a469847; ?>
<?php unset($__attributesOriginala8bb031a483a05f647cb99ed3a469847); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8bb031a483a05f647cb99ed3a469847)): ?>
<?php $component = $__componentOriginala8bb031a483a05f647cb99ed3a469847; ?>
<?php unset($__componentOriginala8bb031a483a05f647cb99ed3a469847); ?>
<?php endif; ?>
                    </div>
                </form>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\USER\Documents\GitHub\malkuthar-app\resources\views/admin/marketplace/categories/index.blade.php ENDPATH**/ ?>