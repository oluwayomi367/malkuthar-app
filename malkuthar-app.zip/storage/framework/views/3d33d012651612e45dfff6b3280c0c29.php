<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'title' => 'Rien à afficher',
    'text' => null,
    'icon' => null,   // nom court : box | search | cart | image | wallet | inbox | star
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'title' => 'Rien à afficher',
    'text' => null,
    'icon' => null,   // nom court : box | search | cart | image | wallet | inbox | star
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $paths = [
        'box' => 'M3 7l9-4 9 4-9 4-9-4zM3 7v10l9 4 9-4V7M12 11v10',
        'search' => 'M11 4a7 7 0 1 0 0 14 7 7 0 0 0 0-14zM21 21l-4.3-4.3',
        'cart' => 'M3 4h2l1.6 9.2A1.5 1.5 0 0 0 8 14.4h8.8a1.5 1.5 0 0 0 1.47-1.2L19.5 7H6M8.5 19.5a1 1 0 1 0 0 .01M16.5 19.5a1 1 0 1 0 0 .01',
        'image' => 'M4 5h16v14H4zM4 15l4-4 4 4 4-6 4 6',
        'wallet' => 'M3 7h15a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h11M17 12h.01',
        'inbox' => 'M4 13h4l1 3h6l1-3h4M4 13l2-8h12l2 8v6H4z',
        'star' => 'M12 3l2.9 5.9 6.5.9-4.7 4.6 1.1 6.5L12 18.8 6.2 21.9l1.1-6.5L2.6 9.8l6.5-.9z',
    ];
    $d = $paths[is_string($icon) ? $icon : ''] ?? $paths['box'];
?>

<div <?php echo e($attributes->merge(['class' => 'rounded-2xl border border-dashed border-line-strong bg-surface px-6 py-14 text-center'])); ?>>
    <div class="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-ground-alt text-ink-3">
        <svg class="h-6 w-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
            <path d="<?php echo e($d); ?>" />
        </svg>
    </div>
    <p class="mt-4 font-display text-base font-semibold text-ink"><?php echo e($title); ?></p>
    <?php if($text): ?>
        <p class="mx-auto mt-1.5 max-w-sm text-sm text-ink-2"><?php echo e($text); ?></p>
    <?php endif; ?>
    <?php if(isset($cta)): ?>
        <div class="mt-5 flex flex-wrap justify-center gap-2"><?php echo e($cta); ?></div>
    <?php endif; ?>
    <?php echo e($slot); ?>

</div>
<?php /**PATH C:\Users\USER\Documents\GitHub\malkuthar-app\resources\views/components/ui/empty-state.blade.php ENDPATH**/ ?>