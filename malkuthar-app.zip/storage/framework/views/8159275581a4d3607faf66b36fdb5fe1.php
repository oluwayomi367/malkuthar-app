<?php $__env->startSection('title', 'Finaliser la commande — Place de marché MALKUTHAR'); ?>

<?php $__env->startSection('content'); ?>
<?php $money = fn ($n) => number_format((float) $n, 0, ',', ' '); ?>

<div class="mx-auto max-w-5xl px-4 py-10 sm:px-6 sm:py-14">
    {!!-- Header & Steps --!}
    <div class="flex flex-wrap items-center justify-between gap-4 border-b border-line/80 pb-6">
        <div>
            <span class="text-[11px] font-semibold uppercase tracking-wider text-accent">Place de marché</span>
            <h1 class="mt-1 font-display text-2xl font-bold tracking-tight text-ink sm:text-3xl">Finaliser ma commande</h1>
        </div>
        <div class="flex items-center gap-2 text-xs font-medium text-ink-3">
            <a href="<?php echo e(route('marketplace.cart')); ?>" class="inline-flex items-center gap-1.5 text-accent hover:underline">
                <span class="inline-flex h-6 w-6 items-center justify-center rounded-full bg-accent-soft text-accent font-bold">✓</span>
                <span>Panier</span>
            </a>
            <span class="text-line-strong">→</span>
            <span class="inline-flex h-6 w-6 items-center justify-center rounded-full bg-accent text-white font-bold">2</span>
            <span class="font-semibold text-ink">Commande</span>
        </div>
    </div>

    <div class="mt-8 grid gap-8 lg:grid-cols-[1.4fr_1fr] lg:items-start">
        {!!-- Left: Form --!}
        <form method="POST" action="<?php echo e(route('marketplace.checkout.store')); ?>" class="space-y-6">
            <?php echo csrf_field(); ?>

            {!!-- Step 1: Contact --!}
            <div class="rounded-3xl border border-line/90 bg-surface p-6 shadow-[0_4px_20px_-8px_rgba(46,44,40,0.05)]">
                <div class="flex items-center gap-2.5 border-b border-line/70 pb-4">
                    <span class="flex h-7 w-7 items-center justify-center rounded-full bg-accent-soft text-accent font-bold text-xs">1</span>
                    <h2 class="font-display text-base font-bold text-ink">Vos coordonnées</h2>
                </div>
                <div class="mt-5 grid gap-4 sm:grid-cols-2">
                    <?php if (isset($component)) { $__componentOriginald816e58425c8bb369623a9433739178c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald816e58425c8bb369623a9433739178c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.field','data' => ['name' => 'email','label' => 'Adresse email','type' => 'email','required' => true,'value' => old('email', auth()->user()?->email),'placeholder' => 'nom@exemple.com']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'email','label' => 'Adresse email','type' => 'email','required' => true,'value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('email', auth()->user()?->email)),'placeholder' => 'nom@exemple.com']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald816e58425c8bb369623a9433739178c)): ?>
<?php $attributes = $__attributesOriginald816e58425c8bb369623a9433739178c; ?>
<?php unset($__attributesOriginald816e58425c8bb369623a9433739178c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald816e58425c8bb369623a9433739178c)): ?>
<?php $component = $__componentOriginald816e58425c8bb369623a9433739178c; ?>
<?php unset($__componentOriginald816e58425c8bb369623a9433739178c); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginald816e58425c8bb369623a9433739178c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald816e58425c8bb369623a9433739178c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.field','data' => ['name' => 'phone','label' => 'Numéro de téléphone','required' => true,'value' => old('phone', auth()->user()?->phone),'placeholder' => 'Ex. : +237 6XX XX XX XX']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'phone','label' => 'Numéro de téléphone','required' => true,'value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('phone', auth()->user()?->phone)),'placeholder' => 'Ex. : +237 6XX XX XX XX']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald816e58425c8bb369623a9433739178c)): ?>
<?php $attributes = $__attributesOriginald816e58425c8bb369623a9433739178c; ?>
<?php unset($__attributesOriginald816e58425c8bb369623a9433739178c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald816e58425c8bb369623a9433739178c)): ?>
<?php $component = $__componentOriginald816e58425c8bb369623a9433739178c; ?>
<?php unset($__componentOriginald816e58425c8bb369623a9433739178c); ?>
<?php endif; ?>
                </div>
            </div>

            {!!-- Step 2: Shipping / Delivery Address --!}
            <div class="rounded-3xl border border-line/90 bg-surface p-6 shadow-[0_4px_20px_-8px_rgba(46,44,40,0.05)]">
                <div class="flex items-center gap-2.5 border-b border-line/70 pb-4">
                    <span class="flex h-7 w-7 items-center justify-center rounded-full bg-accent-soft text-accent font-bold text-xs">2</span>
                    <div>
                        <h2 class="font-display text-base font-bold text-ink">Adresse de livraison</h2>
                        <p class="text-xs text-ink-3">Nécessaire pour les commandes de produits physiques</p>
                    </div>
                </div>
                <div class="mt-5 space-y-4">
                    <?php if (isset($component)) { $__componentOriginald816e58425c8bb369623a9433739178c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald816e58425c8bb369623a9433739178c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.field','data' => ['name' => 'address_line','label' => 'Adresse ou repère précis','value' => old('address_line'),'placeholder' => 'Quartier, rue, numéro de porte ou repère…']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'address_line','label' => 'Adresse ou repère précis','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('address_line')),'placeholder' => 'Quartier, rue, numéro de porte ou repère…']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald816e58425c8bb369623a9433739178c)): ?>
<?php $attributes = $__attributesOriginald816e58425c8bb369623a9433739178c; ?>
<?php unset($__attributesOriginald816e58425c8bb369623a9433739178c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald816e58425c8bb369623a9433739178c)): ?>
<?php $component = $__componentOriginald816e58425c8bb369623a9433739178c; ?>
<?php unset($__componentOriginald816e58425c8bb369623a9433739178c); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginald816e58425c8bb369623a9433739178c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald816e58425c8bb369623a9433739178c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.field','data' => ['name' => 'city','label' => 'Ville & Région','value' => old('city'),'placeholder' => 'Ex. : Douala, Yaoundé, Bafoussam…']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'city','label' => 'Ville & Région','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('city')),'placeholder' => 'Ex. : Douala, Yaoundé, Bafoussam…']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald816e58425c8bb369623a9433739178c)): ?>
<?php $attributes = $__attributesOriginald816e58425c8bb369623a9433739178c; ?>
<?php unset($__attributesOriginald816e58425c8bb369623a9433739178c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald816e58425c8bb369623a9433739178c)): ?>
<?php $component = $__componentOriginald816e58425c8bb369623a9433739178c; ?>
<?php unset($__componentOriginald816e58425c8bb369623a9433739178c); ?>
<?php endif; ?>
                </div>
            </div>

            {!!-- Step 3: Payment Method --!}
            <div class="rounded-3xl border border-line/90 bg-surface p-6 shadow-[0_4px_20px_-8px_rgba(46,44,40,0.05)]">
                <div class="flex items-center gap-2.5 border-b border-line/70 pb-4">
                    <span class="flex h-7 w-7 items-center justify-center rounded-full bg-accent-soft text-accent font-bold text-xs">3</span>
                    <h2 class="font-display text-base font-bold text-ink">Mode de règlement</h2>
                </div>

                <div class="mt-5">
                    <label class="flex cursor-pointer items-start gap-3.5 rounded-2xl border-2 border-accent bg-accent-soft/30 p-4 transition-all">
                        <input type="radio" name="payment_method" value="cod" checked
                               class="mt-1 h-4 w-4 border-line text-accent focus:ring-accent">
                        <div class="min-w-0 flex-1">
                            <div class="flex items-center justify-between">
                                <span class="text-sm font-bold text-ink">Paiement à la livraison ou sur place</span>
                                <span class="rounded-full bg-accent px-2 py-0.5 text-[10px] font-bold text-white uppercase">Recommandé</span>
                            </div>
                            <p class="mt-1 text-xs text-ink-2 leading-relaxed">
                                Réglez votre commande directement auprès du livreur ou du praticien lors de la remise ou de la prestation.
                            </p>
                        </div>
                    </label>

                    <div class="mt-3 flex items-center gap-2 rounded-xl bg-ground-alt/60 p-3 text-xs text-ink-2">
                        <svg class="h-4 w-4 shrink-0 text-accent" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
                        </svg>
                        <span>Règlement direct garanti : vérifiez vos articles ou votre séance avant le paiement auprès du vendeur ou livreur.</span>
                    </div>
                </div>
            </div>

            <div>
                <?php if (isset($component)) { $__componentOriginala8bb031a483a05f647cb99ed3a469847 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8bb031a483a05f647cb99ed3a469847 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.button','data' => ['type' => 'submit','variant' => 'primary','full' => true,'class' => 'h-13 text-xs font-semibold uppercase tracking-wider']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'submit','variant' => 'primary','full' => true,'class' => 'h-13 text-xs font-semibold uppercase tracking-wider']); ?>
                    <svg class="mr-2 h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M5 13l4 4L19 7" />
                    </svg>
                    Confirmer et valider ma commande
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8bb031a483a05f647cb99ed3a469847)): ?>
<?php $attributes = $__attributesOriginala8bb031a483a05f647cb99ed3a469847; ?>
<?php unset($__attributesOriginala8bb031a483a05f647cb99ed3a469847); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8bb031a483a05f647cb99ed3a469847)): ?>
<?php $component = $__componentOriginala8bb031a483a05f647cb99ed3a469847; ?>
<?php unset($__componentOriginala8bb031a483a05f647cb99ed3a469847); ?>
<?php endif; ?>
            </div>
        </form>

        {!!-- Right: Order Recap --!}
        <aside class="space-y-4 lg:sticky lg:top-24">
            <div class="rounded-3xl border border-line/90 bg-surface p-6 shadow-[0_8px_30px_-12px_rgba(46,44,40,0.08)]">
                <div class="flex items-center justify-between border-b border-line/70 pb-4">
                    <h2 class="font-display text-base font-bold text-ink">Articles commandés</h2>
                    <a href="<?php echo e(route('marketplace.cart')); ?>" class="text-xs font-semibold text-accent hover:underline">Modifier</a>
                </div>

                <div class="mt-4 space-y-4 divide-y divide-line/60">
                    <?php $__currentLoopData = $byVendor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendorName => $vendorLines): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="pt-3 first:pt-0">
                            <p class="text-[11px] font-bold uppercase tracking-wider text-accent"><?php echo e($vendorName); ?></p>
                            <div class="mt-2 space-y-2.5">
                                <?php $__currentLoopData = $vendorLines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="flex items-center justify-between gap-3 text-xs">
                                        <div class="min-w-0 flex-1">
                                            <span class="font-medium text-ink line-clamp-1"><?php echo e($line['offer']->title); ?></span>
                                            <span class="text-ink-3"><?php echo e($line['quantity']); ?> × <?php echo e($money($line['unit_price'])); ?> <?php echo e($line['offer']->currency); ?></span>
                                            <?php if($line['variant']): ?>
                                                <span class="block text-[10px] text-ink-3">(<?php echo e($line['variant']->optionsLabel()); ?>)</span>
                                            <?php endif; ?>
                                        </div>
                                        <span class="font-display font-bold text-ink shrink-0"><?php echo e($money($line['line_total'])); ?> FCFA</span>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <div class="mt-5 border-t border-line/80 pt-4 space-y-2">
                    <div class="flex justify-between text-xs text-ink-2">
                        <span>Sous-total</span>
                        <span class="font-medium text-ink"><?php echo e($money($subtotal)); ?> FCFA</span>
                    </div>
                    <div class="flex justify-between text-xs text-ink-3">
                        <span>Livraison</span>
                        <span>À régler à la remise</span>
                    </div>
                    <div class="flex items-baseline justify-between border-t border-line/60 pt-3">
                        <span class="font-display text-base font-bold text-ink">Total à régler</span>
                        <div class="text-right">
                            <span class="font-display text-2xl font-bold tracking-tight text-ink">
                                <?php echo e($money($subtotal)); ?>

                            </span>
                            <span class="text-xs font-semibold text-accent ml-1">FCFA</span>
                        </div>
                    </div>
                </div>
            </div>

            <div class="rounded-2xl border border-line/80 bg-ground-alt/40 p-4 text-xs text-ink-2">
                <div class="flex items-center gap-2 text-ink font-semibold">
                    <svg class="h-4 w-4 text-accent" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <rect x="3" y="11" width="18" height="11" rx="2" ry="2" />
                        <path d="M7 11V7a5 5 0 0110 0v4" />
                    </svg>
                    Sécurité & Engagement
                </div>
                <p class="mt-1.5 text-ink-3 leading-relaxed">
                    Vos données sont confidentielles. Chaque commande génère des sous-commandes directes auprès de chaque créateur pour un suivi rigoureux.
                </p>
            </div>
        </aside>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.storefront', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\USER\Documents\GitHub\malkuthar-app\resources\views/storefront/marketplace/checkout.blade.php ENDPATH**/ ?>