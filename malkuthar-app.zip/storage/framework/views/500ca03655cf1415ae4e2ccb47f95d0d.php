<?php $__env->startSection('title', 'Ma lignée'); ?>
<?php $__env->startSection('sidebar'); ?><?php if (isset($component)) { $__componentOriginal515b40fd5ac497547291c4605ab60c40 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal515b40fd5ac497547291c4605ab60c40 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout.sidebar-app','data' => ['space' => 'affiliate']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout.sidebar-app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['space' => 'affiliate']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal515b40fd5ac497547291c4605ab60c40)): ?>
<?php $attributes = $__attributesOriginal515b40fd5ac497547291c4605ab60c40; ?>
<?php unset($__attributesOriginal515b40fd5ac497547291c4605ab60c40); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal515b40fd5ac497547291c4605ab60c40)): ?>
<?php $component = $__componentOriginal515b40fd5ac497547291c4605ab60c40; ?>
<?php unset($__componentOriginal515b40fd5ac497547291c4605ab60c40); ?>
<?php endif; ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php
    $money = fn ($n) => number_format((float) $n, 0, ',', ' ');
    $levelAccent = [1 => 'text-accent', 2 => 'text-emerald-300', 3 => 'text-amber'];
    $levelRing = [1 => 'border-accent/30', 2 => 'border-emerald-300/25', 3 => 'border-amber/25'];
?>

<p class="text-[11px] font-semibold uppercase tracking-[0.16em] text-accent">Espace affilié</p>
<h1 class="mt-1 font-display text-2xl font-bold tracking-[-0.01em] text-ink sm:text-3xl">Ma lignée</h1>
<p class="mt-1 text-sm text-ink-2">Vos trois niveaux de filleuls : effectifs, ventes réalisées et chiffre d'affaires généré.</p>

<div class="mt-8 space-y-3">
    <?php $__currentLoopData = $levels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="rounded-2xl border bg-surface p-5 <?php echo e($levelRing[$level['level']] ?? 'border-black/10'); ?>">
            <div class="flex items-center justify-between">
                <p class="font-display text-base font-semibold text-ink">Niveau <?php echo e($level['level']); ?></p>
                <span class="rounded-full border border-black/10 bg-black/[0.04] px-2.5 py-0.5 text-xs font-semibold <?php echo e($levelAccent[$level['level']] ?? 'text-ink-2'); ?>"><?php echo e($level['rate']); ?> %</span>
            </div>
            <div class="mt-4 grid grid-cols-2 gap-3 text-sm sm:grid-cols-4">
                <div><p class="text-ink-3">Filleuls</p><p class="mt-0.5 font-display text-lg font-semibold text-ink"><?php echo e($level['members']); ?></p></div>
                <div><p class="text-ink-3">Actifs</p><p class="mt-0.5 font-display text-lg font-semibold text-ink"><?php echo e($level['active']); ?></p></div>
                <div><p class="text-ink-3">Ventes réalisées</p><p class="mt-0.5 font-display text-lg font-semibold text-ink"><?php echo e($level['sales']); ?></p></div>
                <div><p class="text-ink-3">CA généré</p><p class="mt-0.5 font-display text-lg font-semibold text-ink"><?php echo e($money($level['revenue'])); ?></p></div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<p class="mt-4 text-xs text-ink-3">Les données personnelles des membres de votre réseau ne sont pas affichées, uniquement des agrégats (§46).</p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\USER\Documents\GitHub\malkuthar-app\resources\views/affiliate/lineage.blade.php ENDPATH**/ ?>