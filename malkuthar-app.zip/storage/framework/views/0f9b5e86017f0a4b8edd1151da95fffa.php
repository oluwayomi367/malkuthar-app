<?php $__env->startSection('title', 'Devenir affilié'); ?>

<?php $__env->startSection('content'); ?>
<div class="mx-auto max-w-lg">
    <p class="text-[11px] font-semibold uppercase tracking-[0.16em] text-accent">Programme d'affiliation</p>
    <h1 class="mt-1 font-display text-2xl font-bold tracking-[-0.01em] text-ink sm:text-3xl">Devenez affilié MALKUTHAR</h1>
    <p class="mt-2 text-sm text-ink-2">Recommandez les produits digitaux MALKUTHAR et gagnez sur trois niveaux. Aucun second compte : votre espace client devient aussi votre espace affilié.</p>

    <div class="mt-6 space-y-2">
        <div class="flex items-center justify-between rounded-xl border border-accent/25 bg-accent/[0.06] px-4 py-3 text-sm">
            <span class="text-ink">Niveau 1 — ventes directes</span><span class="font-display font-semibold text-accent">15 %</span>
        </div>
        <div class="flex items-center justify-between rounded-xl border border-black/10 bg-surface px-4 py-3 text-sm">
            <span class="text-ink">Niveau 2 — ventes de vos filleuls</span><span class="font-display font-semibold text-emerald-300">10 %</span>
        </div>
        <div class="flex items-center justify-between rounded-xl border border-black/10 bg-surface px-4 py-3 text-sm">
            <span class="text-ink">Niveau 3 — niveau suivant</span><span class="font-display font-semibold text-amber">5 %</span>
        </div>
    </div>

    <p class="mt-3 text-xs text-ink-3">Les produits physiques et les services ne génèrent aucune commission (§4).</p>

    <form method="POST" action="<?php echo e(route('affiliate.activate')); ?>" class="mt-6">
        <?php echo csrf_field(); ?>
        <?php if (isset($component)) { $__componentOriginala8bb031a483a05f647cb99ed3a469847 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8bb031a483a05f647cb99ed3a469847 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.button','data' => ['type' => 'submit','variant' => 'primary','full' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'submit','variant' => 'primary','full' => true]); ?>Activer mon espace affilié <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8bb031a483a05f647cb99ed3a469847)): ?>
<?php $attributes = $__attributesOriginala8bb031a483a05f647cb99ed3a469847; ?>
<?php unset($__attributesOriginala8bb031a483a05f647cb99ed3a469847); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8bb031a483a05f647cb99ed3a469847)): ?>
<?php $component = $__componentOriginala8bb031a483a05f647cb99ed3a469847; ?>
<?php unset($__componentOriginala8bb031a483a05f647cb99ed3a469847); ?>
<?php endif; ?>
    </form>

    <p class="mt-3 text-center text-xs text-ink-3">
        En activant, vous acceptez les
        <a href="<?php echo e(route('affiliate.program-terms')); ?>" class="text-accent hover:underline">conditions du programme</a>.
    </p>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\USER\Documents\GitHub\malkuthar-app\resources\views/affiliate/join.blade.php ENDPATH**/ ?>