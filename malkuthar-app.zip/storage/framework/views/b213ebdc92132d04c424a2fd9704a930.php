<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['order']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['order']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $steps = ['Payée', 'En préparation', 'Expédiée', 'En livraison', 'Livrée'];
    $index = ['paid' => 0, 'preparing' => 1, 'shipped' => 2, 'in_delivery' => 3, 'delivered' => 4][$order->shipping_status] ?? 0;
?>

<div <?php echo e($attributes); ?>>
    <div class="flex items-center">
        <?php $__currentLoopData = $steps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="flex flex-1 items-center <?php if($i === count($steps) - 1): ?> flex-none <?php endif; ?>">
                <span class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                    'flex h-6 w-6 shrink-0 items-center justify-center rounded-full border text-[11px] font-semibold',
                    'border-accent bg-accent text-white' => $i <= $index,
                    'border-black/15 text-ink-3' => $i > $index,
                ]); ?>">
                    <?php if($i < $index): ?>
                        <svg class="h-3 w-3" viewBox="0 0 12 12" fill="none" stroke="currentColor" stroke-width="2"><path d="M2.5 6.5l2.5 2.5 4.5-5" stroke-linecap="round" stroke-linejoin="round"/></svg>
                    <?php else: ?>
                        <?php echo e($i + 1); ?>

                    <?php endif; ?>
                </span>
                <?php if($i < count($steps) - 1): ?>
                    <span class="<?php echo \Illuminate\Support\Arr::toCssClasses(['h-px flex-1', 'bg-accent' => $i < $index, 'bg-black/[0.06]' => $i >= $index]); ?>"></span>
                <?php endif; ?>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="mt-2 flex justify-between text-[10.5px] text-ink-3">
        <?php $__currentLoopData = $steps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <span class="<?php echo \Illuminate\Support\Arr::toCssClasses(['w-12 text-center', 'text-ink' => $i === $index]); ?>" <?php if($i === 0): ?> class="w-12 text-left" <?php elseif($i === count($steps) - 1): ?> class="w-12 text-right" <?php endif; ?>><?php echo e($label); ?></span>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <?php if($order->tracking_number || $order->shipping_carrier): ?>
        <p class="mt-3 text-xs text-ink-2">
            <?php echo e($order->shipping_carrier); ?>

            <?php if($order->tracking_number): ?> · Suivi <span class="font-mono text-ink"><?php echo e($order->tracking_number); ?></span><?php endif; ?>
        </p>
    <?php endif; ?>
</div>
<?php /**PATH C:\Users\USER\Documents\GitHub\malkuthar-app\resources\views/components/account/order-tracker.blade.php ENDPATH**/ ?>