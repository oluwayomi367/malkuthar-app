<?php $__env->startSection('title', 'Administration — '.$vendor->display_name); ?>
<?php $__env->startSection('eyebrow', 'Marketplace · Vendeur'); ?>
<?php $__env->startSection('heading', $vendor->display_name); ?>

<?php $__env->startSection('content'); ?>
<?php $pct = fn ($r) => $r === null ? '—' : rtrim(rtrim(number_format($r * 100, 2), '0'), '.').' %'; ?>

<div class="grid gap-6 lg:grid-cols-[1.6fr_1fr]">
    <div class="space-y-6">
        
        <section class="rounded-2xl border border-black/10 bg-surface p-5">
            <div class="flex items-center justify-between">
                <h2 class="font-display text-base font-semibold text-ink">Profil</h2>
                <?php if (isset($component)) { $__componentOriginald271113ca69d52f8dbc84ae4f8468e44 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald271113ca69d52f8dbc84ae4f8468e44 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.status-pill','data' => ['status' => $vendor->status]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.status-pill'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($vendor->status)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald271113ca69d52f8dbc84ae4f8468e44)): ?>
<?php $attributes = $__attributesOriginald271113ca69d52f8dbc84ae4f8468e44; ?>
<?php unset($__attributesOriginald271113ca69d52f8dbc84ae4f8468e44); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald271113ca69d52f8dbc84ae4f8468e44)): ?>
<?php $component = $__componentOriginald271113ca69d52f8dbc84ae4f8468e44; ?>
<?php unset($__componentOriginald271113ca69d52f8dbc84ae4f8468e44); ?>
<?php endif; ?>
            </div>
            <dl class="mt-3 grid gap-x-6 gap-y-2 text-sm sm:grid-cols-2">
                <div><dt class="text-ink-3">Compte</dt><dd class="text-ink"><?php echo e(trim("{$vendor->user?->first_name} {$vendor->user?->last_name}")); ?> — <?php echo e($vendor->user?->email); ?></dd></div>
                <div><dt class="text-ink-3">Raison sociale</dt><dd class="text-ink"><?php echo e($vendor->legal_name ?: '—'); ?></dd></div>
                <div><dt class="text-ink-3">Région / ville</dt><dd class="text-ink"><?php echo e($vendor->region ?: '—'); ?><?php if($vendor->city): ?> · <?php echo e($vendor->city); ?><?php endif; ?></dd></div>
                <div><dt class="text-ink-3">Contact</dt><dd class="text-ink"><?php echo e($vendor->contact_email ?: '—'); ?> · <?php echo e($vendor->phone ?: '—'); ?></dd></div>
                <div><dt class="text-ink-3">Devise de règlement</dt><dd class="text-ink"><?php echo e($vendor->payout_currency); ?></dd></div>
                <div><dt class="text-ink-3">Validé par</dt><dd class="text-ink"><?php echo e($vendor->approver ? trim("{$vendor->approver->first_name} {$vendor->approver->last_name}") : '—'); ?> <?php echo e(optional($vendor->approved_at)->format('d/m/Y')); ?></dd></div>
            </dl>
            <?php if($vendor->bio): ?>
                <p class="mt-3 border-t border-black/[0.06] pt-3 text-sm text-ink-2"><?php echo e($vendor->bio); ?></p>
            <?php endif; ?>
            <?php if($vendor->suspension_reason): ?>
                <p class="mt-3 text-sm text-rust">Motif : <?php echo e($vendor->suspension_reason); ?></p>
            <?php endif; ?>
        </section>

        
        <section class="rounded-2xl border border-black/10 bg-surface p-5">
            <h2 class="font-display text-base font-semibold text-ink">Justificatifs (KYC)</h2>
            <?php if($vendor->documents->isEmpty()): ?>
                <p class="mt-2 text-sm text-ink-3">Aucune pièce déposée.</p>
            <?php else: ?>
                <ul class="mt-3 divide-y divide-black/[0.06] text-sm">
                    <?php $__currentLoopData = $vendor->documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="flex items-center justify-between py-2">
                            <span class="text-ink"><?php echo e($doc->type); ?> — <?php echo e($doc->original_name ?: 'pièce'); ?></span>
                            <?php if (isset($component)) { $__componentOriginald271113ca69d52f8dbc84ae4f8468e44 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald271113ca69d52f8dbc84ae4f8468e44 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.status-pill','data' => ['status' => $doc->status]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.status-pill'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($doc->status)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald271113ca69d52f8dbc84ae4f8468e44)): ?>
<?php $attributes = $__attributesOriginald271113ca69d52f8dbc84ae4f8468e44; ?>
<?php unset($__attributesOriginald271113ca69d52f8dbc84ae4f8468e44); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald271113ca69d52f8dbc84ae4f8468e44)): ?>
<?php $component = $__componentOriginald271113ca69d52f8dbc84ae4f8468e44; ?>
<?php unset($__componentOriginald271113ca69d52f8dbc84ae4f8468e44); ?>
<?php endif; ?>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php endif; ?>
        </section>
    </div>

    
    <div class="space-y-4">
        <section class="rounded-2xl border border-black/10 bg-surface p-5">
            <h2 class="font-display text-base font-semibold text-ink">Compte</h2>
            <div class="mt-3 flex flex-col gap-2">
                <?php if($vendor->status === 'pending'): ?>
                    <form method="POST" action="<?php echo e(route('admin.marketplace.vendors.approve', $vendor)); ?>"><?php echo csrf_field(); ?>
                        <button class="h-10 w-full rounded-xl border border-brand-green/40 bg-brand-green/10 text-sm font-semibold text-brand-green hover:bg-brand-green/20">Approuver le compte</button>
                    </form>
                    <form method="POST" action="<?php echo e(route('admin.marketplace.vendors.reject', $vendor)); ?>" class="space-y-2"><?php echo csrf_field(); ?>
                        <input name="reason" required placeholder="Motif de refus" class="h-10 w-full rounded-xl border border-black/10 bg-surface px-3 text-sm">
                        <button class="h-10 w-full rounded-xl border border-rust/40 bg-rust/10 text-sm font-semibold text-rust hover:bg-rust/20">Refuser</button>
                    </form>
                <?php elseif($vendor->status === 'active'): ?>
                    <form method="POST" action="<?php echo e(route('admin.marketplace.vendors.suspend', $vendor)); ?>" class="space-y-2"><?php echo csrf_field(); ?>
                        <input name="reason" required placeholder="Motif de suspension" class="h-10 w-full rounded-xl border border-black/10 bg-surface px-3 text-sm">
                        <button class="h-10 w-full rounded-xl border border-rust/40 bg-rust/10 text-sm font-semibold text-rust hover:bg-rust/20">Suspendre</button>
                    </form>
                <?php elseif(in_array($vendor->status, ['suspended', 'closed'], true)): ?>
                    <form method="POST" action="<?php echo e(route('admin.marketplace.vendors.reactivate', $vendor)); ?>"><?php echo csrf_field(); ?>
                        <button class="h-10 w-full rounded-xl border border-brand-green/40 bg-brand-green/10 text-sm font-semibold text-brand-green hover:bg-brand-green/20">Réactiver</button>
                    </form>
                <?php endif; ?>
            </div>
        </section>

        <section class="rounded-2xl border border-black/10 bg-surface p-5">
            <h2 class="font-display text-base font-semibold text-ink">Commission</h2>
            <p class="mt-1 text-xs text-ink-3">Taux spécifique au vendeur. Vide = barème catégorie / plateforme. Actuel : <?php echo e($pct($vendor->commission_rate_override)); ?>.</p>
            <form method="POST" action="<?php echo e(route('admin.marketplace.vendors.commission', $vendor)); ?>" class="mt-3 flex gap-2">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <input name="commission_rate_percent" type="number" step="0.01" min="0" max="90"
                       value="<?php echo e($vendor->commission_rate_override !== null ? number_format($vendor->commission_rate_override * 100, 2, '.', '') : ''); ?>"
                       placeholder="%" class="h-10 w-24 rounded-xl border border-black/10 bg-surface px-3 text-sm">
                <button class="h-10 rounded-xl border border-black/10 bg-ground-alt px-4 text-sm font-semibold text-ink">Enregistrer</button>
            </form>
        </section>
    </div>
</div>

<p class="mt-6 text-sm"><a href="<?php echo e(route('admin.marketplace.vendors.index')); ?>" class="text-accent hover:underline">← Tous les vendeurs</a></p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\USER\Documents\GitHub\malkuthar-app\resources\views/admin/marketplace/vendors/show.blade.php ENDPATH**/ ?>