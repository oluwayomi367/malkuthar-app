<?php $__env->startSection('title', 'Fiche — ' . $product->name); ?>
<?php $__env->startSection('eyebrow', 'Catalogue'); ?>
<?php $__env->startSection('heading', $product->name); ?>

<?php $__env->startSection('actions'); ?>
    <?php if (isset($component)) { $__componentOriginala8bb031a483a05f647cb99ed3a469847 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8bb031a483a05f647cb99ed3a469847 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.button','data' => ['href' => route('admin.products.index'),'variant' => 'secondary']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('admin.products.index')),'variant' => 'secondary']); ?>← Retour <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8bb031a483a05f647cb99ed3a469847)): ?>
<?php $attributes = $__attributesOriginala8bb031a483a05f647cb99ed3a469847; ?>
<?php unset($__attributesOriginala8bb031a483a05f647cb99ed3a469847); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8bb031a483a05f647cb99ed3a469847)): ?>
<?php $component = $__componentOriginala8bb031a483a05f647cb99ed3a469847; ?>
<?php unset($__componentOriginala8bb031a483a05f647cb99ed3a469847); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginala8bb031a483a05f647cb99ed3a469847 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8bb031a483a05f647cb99ed3a469847 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.button','data' => ['href' => route('admin.products.edit', $product),'variant' => 'primary']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('admin.products.edit', $product)),'variant' => 'primary']); ?>Modifier <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8bb031a483a05f647cb99ed3a469847)): ?>
<?php $attributes = $__attributesOriginala8bb031a483a05f647cb99ed3a469847; ?>
<?php unset($__attributesOriginala8bb031a483a05f647cb99ed3a469847); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8bb031a483a05f647cb99ed3a469847)): ?>
<?php $component = $__componentOriginala8bb031a483a05f647cb99ed3a469847; ?>
<?php unset($__componentOriginala8bb031a483a05f647cb99ed3a469847); ?>
<?php endif; ?>
    <form method="POST" action="<?php echo e(route('admin.products.delete', $product)); ?>"
          onsubmit="return confirm('Supprimer définitivement « <?php echo e($product->name); ?> » ?')">
        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
        <button class="inline-flex h-11 items-center rounded-xl border border-rust/40 px-4 text-sm font-semibold text-rust transition-colors hover:bg-rust/10 sm:h-10">Supprimer</button>
    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php
    $m = fn ($n) => number_format((float) $n, 0, ',', ' ');
    $typeLabels = ['digital' => 'Digital', 'physical' => 'Physique', 'service' => 'Service'];
    $statusMeta = [
        'published' => ['Publié', 'accent'],
        'draft' => ['Brouillon', 'muted'],
        'archived' => ['Archivé', 'rust'],
    ];
    [$sLabel, $sTone] = $statusMeta[$product->status] ?? [$product->status, 'muted'];
    $images = collect([$product->main_image])->merge((array) ($product->gallery ?? []))->filter()->unique()->values();
    $moveLabels = [
        'reserved' => 'Réservé', 'released' => 'Libéré', 'sold' => 'Vendu',
        'returned' => 'Retour', 'restocked' => 'Réappro.', 'adjustment' => 'Ajustement',
    ];
    $moveSign = ['reserved' => '−', 'sold' => '', 'released' => '+', 'returned' => '+', 'restocked' => '+', 'adjustment' => '±'];
?>

<div class="mb-6 flex flex-wrap items-center gap-2">
    <?php if (isset($component)) { $__componentOriginalab7baa01105b3dfe1e0cf1dfc58879b4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalab7baa01105b3dfe1e0cf1dfc58879b4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.badge','data' => ['tone' => 'muted']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['tone' => 'muted']); ?><?php echo e($typeLabels[$product->type] ?? $product->type); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalab7baa01105b3dfe1e0cf1dfc58879b4)): ?>
<?php $attributes = $__attributesOriginalab7baa01105b3dfe1e0cf1dfc58879b4; ?>
<?php unset($__attributesOriginalab7baa01105b3dfe1e0cf1dfc58879b4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalab7baa01105b3dfe1e0cf1dfc58879b4)): ?>
<?php $component = $__componentOriginalab7baa01105b3dfe1e0cf1dfc58879b4; ?>
<?php unset($__componentOriginalab7baa01105b3dfe1e0cf1dfc58879b4); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginalab7baa01105b3dfe1e0cf1dfc58879b4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalab7baa01105b3dfe1e0cf1dfc58879b4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.badge','data' => ['tone' => $sTone]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['tone' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sTone)]); ?><?php echo e($sLabel); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalab7baa01105b3dfe1e0cf1dfc58879b4)): ?>
<?php $attributes = $__attributesOriginalab7baa01105b3dfe1e0cf1dfc58879b4; ?>
<?php unset($__attributesOriginalab7baa01105b3dfe1e0cf1dfc58879b4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalab7baa01105b3dfe1e0cf1dfc58879b4)): ?>
<?php $component = $__componentOriginalab7baa01105b3dfe1e0cf1dfc58879b4; ?>
<?php unset($__componentOriginalab7baa01105b3dfe1e0cf1dfc58879b4); ?>
<?php endif; ?>
    <?php if($product->is_affiliable): ?><?php if (isset($component)) { $__componentOriginalab7baa01105b3dfe1e0cf1dfc58879b4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalab7baa01105b3dfe1e0cf1dfc58879b4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.badge','data' => ['tone' => 'accent']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['tone' => 'accent']); ?>Affiliable · commissions 15/10/5 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalab7baa01105b3dfe1e0cf1dfc58879b4)): ?>
<?php $attributes = $__attributesOriginalab7baa01105b3dfe1e0cf1dfc58879b4; ?>
<?php unset($__attributesOriginalab7baa01105b3dfe1e0cf1dfc58879b4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalab7baa01105b3dfe1e0cf1dfc58879b4)): ?>
<?php $component = $__componentOriginalab7baa01105b3dfe1e0cf1dfc58879b4; ?>
<?php unset($__componentOriginalab7baa01105b3dfe1e0cf1dfc58879b4); ?>
<?php endif; ?><?php endif; ?>
    <?php if (! ($product->is_available)): ?><?php if (isset($component)) { $__componentOriginalab7baa01105b3dfe1e0cf1dfc58879b4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalab7baa01105b3dfe1e0cf1dfc58879b4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.badge','data' => ['tone' => 'rust']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['tone' => 'rust']); ?>Indisponible à la vente <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalab7baa01105b3dfe1e0cf1dfc58879b4)): ?>
<?php $attributes = $__attributesOriginalab7baa01105b3dfe1e0cf1dfc58879b4; ?>
<?php unset($__attributesOriginalab7baa01105b3dfe1e0cf1dfc58879b4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalab7baa01105b3dfe1e0cf1dfc58879b4)): ?>
<?php $component = $__componentOriginalab7baa01105b3dfe1e0cf1dfc58879b4; ?>
<?php unset($__componentOriginalab7baa01105b3dfe1e0cf1dfc58879b4); ?>
<?php endif; ?><?php endif; ?>
    <?php if($product->status === 'published'): ?>
        <a href="<?php echo e(route('catalog.show', $product->slug)); ?>" target="_blank" rel="noopener" class="ml-auto text-sm text-accent hover:underline">Voir en boutique ↗</a>
    <?php endif; ?>
</div>

<div class="grid gap-8 lg:grid-cols-[300px_1fr] lg:gap-10">
    
    <div>
        <div class="overflow-hidden rounded-2xl border border-black/10 bg-ground/60">
            <?php if($images->isNotEmpty()): ?>
                <img src="<?php echo e($images->first()); ?>" alt="<?php echo e($product->name); ?>" class="aspect-square w-full object-cover">
            <?php else: ?>
                <div class="flex aspect-square w-full items-center justify-center text-ink-3">
                    <svg class="h-10 w-10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.1"><rect x="3" y="4" width="18" height="16" rx="2"/><path d="M3 15l5-5 4 4 3-3 6 6"/><circle cx="9" cy="9" r="1.5"/></svg>
                </div>
            <?php endif; ?>
        </div>
        <?php if($images->count() > 1): ?>
            <div class="mt-3 flex flex-wrap gap-2">
                <?php $__currentLoopData = $images->slice(1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <img src="<?php echo e($img); ?>" alt="" class="h-16 w-16 rounded-lg border border-black/10 object-cover">
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
        <?php if($product->presentation_video): ?>
            <a href="<?php echo e($product->presentation_video); ?>" target="_blank" rel="noopener" class="mt-3 inline-flex text-sm text-accent hover:underline">▶ Vidéo de présentation</a>
        <?php endif; ?>
    </div>

    
    <div class="space-y-6">
        <?php if($product->description): ?>
            <p class="whitespace-pre-line text-sm leading-relaxed text-ink-2"><?php echo e($product->description); ?></p>
        <?php endif; ?>

        <dl class="grid grid-cols-2 gap-x-6 gap-y-4 rounded-2xl border border-black/10 bg-surface p-5 text-sm sm:grid-cols-3">
            <div>
                <dt class="text-[11px] uppercase tracking-wide text-ink-3">Prix</dt>
                <dd class="mt-0.5 font-display text-lg font-semibold text-ink"><?php echo e($m($product->price)); ?> <?php echo e($product->currency); ?></dd>
            </div>
            <?php if($product->promotional_price): ?>
                <div>
                    <dt class="text-[11px] uppercase tracking-wide text-ink-3">Prix promo</dt>
                    <dd class="mt-0.5 font-display text-lg font-semibold text-accent"><?php echo e($m($product->promotional_price)); ?> <?php echo e($product->currency); ?></dd>
                </div>
            <?php endif; ?>
            <div>
                <dt class="text-[11px] uppercase tracking-wide text-ink-3">Slug</dt>
                <dd class="mt-0.5 font-mono text-ink-2"><?php echo e($product->slug); ?></dd>
            </div>
            <?php if($product->category): ?>
                <div><dt class="text-[11px] uppercase tracking-wide text-ink-3">Catégorie</dt><dd class="mt-0.5 text-ink"><?php echo e($product->category); ?><?php if($product->sub_category): ?> / <?php echo e($product->sub_category); ?><?php endif; ?></dd></div>
            <?php endif; ?>

            <?php if($product->type === 'digital'): ?>
                <div class="col-span-2 sm:col-span-3"><dt class="text-[11px] uppercase tracking-wide text-ink-3">Fichier livré</dt><dd class="mt-0.5 break-all font-mono text-ink-2"><?php echo e($product->file_path ?: '—'); ?></dd></div>
            <?php elseif($product->type === 'physical'): ?>
                <div><dt class="text-[11px] uppercase tracking-wide text-ink-3">SKU</dt><dd class="mt-0.5 font-mono text-ink"><?php echo e($product->sku ?: '—'); ?></dd></div>
                <div><dt class="text-[11px] uppercase tracking-wide text-ink-3">Poids</dt><dd class="mt-0.5 text-ink"><?php echo e($product->weight ? $product->weight.' kg' : '—'); ?></dd></div>
            <?php elseif($product->type === 'service'): ?>
                <div><dt class="text-[11px] uppercase tracking-wide text-ink-3">Durée</dt><dd class="mt-0.5 text-ink"><?php echo e($product->duration_minutes ? $product->duration_minutes.' min' : '—'); ?></dd></div>
                <div><dt class="text-[11px] uppercase tracking-wide text-ink-3">Mode</dt><dd class="mt-0.5 text-ink"><?php echo e($product->delivery_mode ?: '—'); ?></dd></div>
                <div><dt class="text-[11px] uppercase tracking-wide text-ink-3">Lieu</dt><dd class="mt-0.5 text-ink"><?php echo e($product->location ?: '—'); ?></dd></div>
            <?php endif; ?>

            <div><dt class="text-[11px] uppercase tracking-wide text-ink-3">Créé le</dt><dd class="mt-0.5 text-ink-2"><?php echo e($product->created_at?->format('d/m/Y')); ?></dd></div>
            <div><dt class="text-[11px] uppercase tracking-wide text-ink-3">Modifié le</dt><dd class="mt-0.5 text-ink-2"><?php echo e($product->updated_at?->format('d/m/Y')); ?></dd></div>
        </dl>

        
        <div class="rounded-2xl border border-black/10 bg-surface p-5">
            <p class="text-[11px] font-semibold uppercase tracking-[0.12em] text-ink-3">Ventes &amp; commissions</p>

            <div class="mt-3 grid grid-cols-2 gap-3 text-center sm:grid-cols-4">
                <div class="rounded-xl border border-black/10 py-3">
                    <p class="font-display text-2xl font-bold text-ink"><?php echo e($sales['units_sold']); ?></p>
                    <p class="text-[11px] uppercase tracking-wide text-ink-3">Unités vendues</p>
                </div>
                <div class="rounded-xl border border-black/10 py-3">
                    <p class="font-display text-2xl font-bold text-ink"><?php echo e($sales['orders_count']); ?></p>
                    <p class="text-[11px] uppercase tracking-wide text-ink-3">Commandes</p>
                </div>
                <div class="rounded-xl border border-black/10 py-3">
                    <p class="font-display text-2xl font-bold text-ink"><?php echo e($m($sales['revenue'])); ?></p>
                    <p class="text-[11px] uppercase tracking-wide text-ink-3">CA (<?php echo e($sales['currency']); ?>)</p>
                </div>
                <div class="rounded-xl border border-black/10 py-3">
                    <p class="font-display text-2xl font-bold <?php echo e($sales['pending_revenue'] > 0 ? 'text-amber' : 'text-ink-3'); ?>"><?php echo e($m($sales['pending_revenue'])); ?></p>
                    <p class="text-[11px] uppercase tracking-wide text-ink-3">En attente COD</p>
                </div>
            </div>

            <?php if(! $sales['applicable']): ?>
                <p class="mt-4 rounded-xl border border-black/10 bg-ground/50 p-3 text-sm text-ink-3">
                    Produit non affiliable : aucune commission d'affiliation n'est calculée sur ses ventes (§4/§5).
                </p>
            <?php else: ?>
                <div class="mt-4 overflow-x-auto">
                    <table class="w-full min-w-[380px] text-left text-sm">
                        <thead class="text-[10.5px] uppercase tracking-[0.08em] text-ink-3">
                            <tr>
                                <th class="py-2 pr-3 font-semibold">Commissions générées</th>
                                <th class="px-2 py-2 text-right font-semibold">Montant (<?php echo e($sales['currency']); ?>)</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-black/[0.05]">
                            <?php $__currentLoopData = $sales['commission_by_level']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $level => $amount): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="py-2 pr-3 text-ink-2">Niveau <?php echo e($level); ?></td>
                                    <td class="px-2 py-2 text-right text-ink"><?php echo e($m($amount)); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php if($sales['commission_reversed'] > 0): ?>
                                <tr>
                                    <td class="py-2 pr-3 text-rust">Reprises (remboursements)</td>
                                    <td class="px-2 py-2 text-right text-rust">−<?php echo e($m($sales['commission_reversed'])); ?></td>
                                </tr>
                            <?php endif; ?>
                            <tr class="font-semibold">
                                <td class="py-2 pr-3 text-ink">Net distribué</td>
                                <td class="px-2 py-2 text-right text-ink"><?php echo e($m($sales['commission_net'])); ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>

                <?php if(! empty($sales['commission_by_status'])): ?>
                    <div class="mt-3 flex flex-wrap items-center gap-x-4 gap-y-2 text-xs text-ink-2">
                        <?php $__currentLoopData = $sales['commission_by_status']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $st => $amount): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span class="inline-flex items-center gap-1.5">
                                <?php if (isset($component)) { $__componentOriginald271113ca69d52f8dbc84ae4f8468e44 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald271113ca69d52f8dbc84ae4f8468e44 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.status-pill','data' => ['status' => $st]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.status-pill'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($st)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald271113ca69d52f8dbc84ae4f8468e44)): ?>
<?php $attributes = $__attributesOriginald271113ca69d52f8dbc84ae4f8468e44; ?>
<?php unset($__attributesOriginald271113ca69d52f8dbc84ae4f8468e44); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald271113ca69d52f8dbc84ae4f8468e44)): ?>
<?php $component = $__componentOriginald271113ca69d52f8dbc84ae4f8468e44; ?>
<?php unset($__componentOriginald271113ca69d52f8dbc84ae4f8468e44); ?>
<?php endif; ?>
                                <span><?php echo e($m($amount)); ?> <?php echo e($sales['currency']); ?></span>
                            </span>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>

        
        <?php if($product->type === 'physical'): ?>
            <div class="rounded-2xl border border-black/10 bg-surface p-5">
                <div class="flex items-center justify-between">
                    <p class="text-[11px] font-semibold uppercase tracking-[0.12em] text-ink-3">Stock</p>
                    <a href="<?php echo e(route('admin.products.edit', $product)); ?>#stock" class="text-xs text-accent hover:underline">Ajuster</a>
                </div>
                <?php
                    $hasVariants = $product->relationLoaded('variants') && $product->variants->isNotEmpty();
                    $sumAvail = $hasVariants ? $product->variants->sum('stock_available') : (int) $product->stock_available;
                    $sumRes = $hasVariants ? $product->variants->sum('stock_reserved') : (int) $product->stock_reserved;
                    $sumSold = $hasVariants ? $product->variants->sum('stock_sold') : (int) $product->stock_sold;
                ?>
                <div class="mt-3 grid grid-cols-3 gap-3 text-center">
                    <div class="rounded-xl border border-black/10 bg-surface py-3">
                        <p class="font-display text-2xl font-bold <?php echo e($sumAvail <= 5 ? 'text-rust' : 'text-ink'); ?>"><?php echo e($sumAvail); ?></p>
                        <p class="text-[11px] uppercase tracking-wide text-ink-3">Disponible</p>
                    </div>
                    <div class="rounded-xl border border-black/10 bg-surface py-3">
                        <p class="font-display text-2xl font-bold text-ink-2"><?php echo e($sumRes); ?></p>
                        <p class="text-[11px] uppercase tracking-wide text-ink-3">Réservé</p>
                    </div>
                    <div class="rounded-xl border border-black/10 bg-surface py-3">
                        <p class="font-display text-2xl font-bold text-ink-2"><?php echo e($sumSold); ?></p>
                        <p class="text-[11px] uppercase tracking-wide text-ink-3">Vendu</p>
                    </div>
                </div>

                <?php if($hasVariants): ?>
                    <div class="mt-4 overflow-x-auto">
                        <table class="w-full min-w-[440px] text-left text-sm">
                            <thead class="text-[10.5px] uppercase tracking-[0.08em] text-ink-3">
                                <tr><th class="py-2 pr-3 font-semibold">Variante</th><th class="px-2 py-2 font-semibold">SKU</th><th class="px-2 py-2 text-center font-semibold">Dispo</th><th class="px-2 py-2 text-center font-semibold">Rés.</th><th class="pl-2 py-2 text-center font-semibold">Vendu</th><th class="pl-2 py-2 text-right font-semibold">Prix</th></tr>
                            </thead>
                            <tbody class="divide-y divide-black/[0.05]">
                                <?php $__currentLoopData = $product->variants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="<?php echo \Illuminate\Support\Arr::toCssClasses(['text-ink-3' => ! $v->is_active]); ?>">
                                        <td class="py-2 pr-3 text-ink"><?php echo e($v->name); ?><?php if (! ($v->is_active)): ?> <span class="text-xs text-ink-3">(inactive)</span><?php endif; ?></td>
                                        <td class="px-2 py-2 font-mono text-xs text-ink-3"><?php echo e($v->sku ?: '—'); ?></td>
                                        <td class="px-2 py-2 text-center <?php echo e((int) $v->stock_available <= 3 ? 'text-rust' : ''); ?>"><?php echo e((int) $v->stock_available); ?></td>
                                        <td class="px-2 py-2 text-center text-ink-2"><?php echo e((int) $v->stock_reserved); ?></td>
                                        <td class="pl-2 py-2 text-center text-ink-2"><?php echo e((int) $v->stock_sold); ?></td>
                                        <td class="pl-2 py-2 text-right text-ink-2"><?php echo e($v->price !== null ? number_format((float) $v->price, 0, ',', ' ').' '.$product->currency : '—'); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>

                <?php if($movements->isNotEmpty()): ?>
                    <ul class="mt-4 space-y-2 text-sm">
                        <?php $__currentLoopData = $movements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="flex items-baseline justify-between gap-3 border-b border-black/[0.05] pb-2 last:border-0 last:pb-0">
                                <span>
                                    <span class="text-ink"><?php echo e($moveLabels[$mv->type] ?? $mv->type); ?></span>
                                    <span class="text-ink-3"> <?php echo e($moveSign[$mv->type] ?? ''); ?><?php echo e($mv->quantity); ?></span>
                                    <?php if($mv->reason): ?><span class="text-ink-3"> · <?php echo e($mv->reason); ?></span><?php endif; ?>
                                    <?php if($mv->admin): ?><span class="text-ink-3"> · <?php echo e($mv->admin->first_name); ?> <?php echo e($mv->admin->last_name); ?></span><?php endif; ?>
                                </span>
                                <span class="shrink-0 text-xs text-ink-3"><?php echo e($mv->created_at->format('d/m/y H:i')); ?></span>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\USER\Documents\GitHub\malkuthar-app\resources\views/admin/products/show.blade.php ENDPATH**/ ?>