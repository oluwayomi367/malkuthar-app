<?php $__env->startSection('title', 'Administration — Modération des offres'); ?>
<?php $__env->startSection('eyebrow', 'Marketplace'); ?>
<?php $__env->startSection('heading', 'Modération des offres'); ?>

<?php $__env->startSection('content'); ?>
<?php $money = fn ($n) => number_format((float) $n, 0, ',', ' '); ?>

<nav class="mb-5 flex flex-wrap gap-2 text-sm">
    <?php $__currentLoopData = ['pending_review' => 'À valider', 'changes_requested' => 'À corriger', 'approved' => 'Approuvées', 'rejected' => 'Refusées', 'suspended' => 'Suspendues', 'all' => 'Toutes']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $lbl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(route('admin.marketplace.offers.index', ['status' => $k])); ?>"
           class="<?php echo \Illuminate\Support\Arr::toCssClasses([
               'rounded-full border px-3 py-1.5',
               'border-accent bg-accent/10 font-semibold text-accent' => $status === $k,
               'border-black/10 text-ink-2 hover:text-ink' => $status !== $k,
           ]); ?>">
            <?php echo e($lbl); ?><?php if(isset($counts[$k])): ?> <span class="text-ink-3">(<?php echo e($counts[$k]); ?>)</span><?php endif; ?>
        </a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</nav>

<?php if($offers->isEmpty()): ?>
    <?php if (isset($component)) { $__componentOriginal3607a477fdef7402bc742abad5df9c51 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3607a477fdef7402bc742abad5df9c51 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.empty-state','data' => ['title' => 'Rien à afficher','text' => 'Aucune offre pour ce filtre.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.empty-state'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Rien à afficher','text' => 'Aucune offre pour ce filtre.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3607a477fdef7402bc742abad5df9c51)): ?>
<?php $attributes = $__attributesOriginal3607a477fdef7402bc742abad5df9c51; ?>
<?php unset($__attributesOriginal3607a477fdef7402bc742abad5df9c51); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3607a477fdef7402bc742abad5df9c51)): ?>
<?php $component = $__componentOriginal3607a477fdef7402bc742abad5df9c51; ?>
<?php unset($__componentOriginal3607a477fdef7402bc742abad5df9c51); ?>
<?php endif; ?>
<?php else: ?>
    <div class="space-y-3">
        <?php $__currentLoopData = $offers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="rounded-2xl border border-black/10 bg-surface p-4">
                <div class="flex flex-wrap items-start justify-between gap-3">
                    <div>
                        <a href="<?php echo e(route('admin.marketplace.offers.show', $offer)); ?>" class="font-semibold text-ink hover:text-accent"><?php echo e($offer->title); ?></a>
                        <p class="mt-0.5 text-xs text-ink-3">
                            <?php echo e($offer->vendor?->display_name); ?> · <?php echo e($offer->category?->name); ?> · <?php echo e(ucfirst($offer->type)); ?>

                            · <?php echo e($money($offer->effectivePrice())); ?> <?php echo e($offer->currency); ?>

                            <?php if($offer->submitted_at): ?> · soumis <?php echo e($offer->submitted_at->diffForHumans()); ?><?php endif; ?>
                        </p>
                    </div>
                    <?php if (isset($component)) { $__componentOriginald271113ca69d52f8dbc84ae4f8468e44 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald271113ca69d52f8dbc84ae4f8468e44 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.status-pill','data' => ['status' => $offer->status]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.status-pill'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($offer->status)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald271113ca69d52f8dbc84ae4f8468e44)): ?>
<?php $attributes = $__attributesOriginald271113ca69d52f8dbc84ae4f8468e44; ?>
<?php unset($__attributesOriginald271113ca69d52f8dbc84ae4f8468e44); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald271113ca69d52f8dbc84ae4f8468e44)): ?>
<?php $component = $__componentOriginald271113ca69d52f8dbc84ae4f8468e44; ?>
<?php unset($__componentOriginald271113ca69d52f8dbc84ae4f8468e44); ?>
<?php endif; ?>
                </div>

                <?php if($offer->status === 'pending_review'): ?>
                    <div class="mt-3 flex flex-wrap items-start gap-2 border-t border-black/[0.06] pt-3">
                        <form method="POST" action="<?php echo e(route('admin.marketplace.offers.approve', $offer)); ?>"><?php echo csrf_field(); ?>
                            <button class="h-9 rounded-lg border border-brand-green/40 bg-brand-green/10 px-3 text-xs font-semibold text-brand-green hover:bg-brand-green/20">Approuver</button>
                        </form>
                        <form method="POST" action="<?php echo e(route('admin.marketplace.offers.request-changes', $offer)); ?>" class="flex gap-1"><?php echo csrf_field(); ?>
                            <input name="note" required placeholder="Corrections demandées" class="h-9 w-52 rounded-lg border border-black/10 bg-surface px-2 text-xs">
                            <button class="h-9 rounded-lg border border-amber/40 bg-amber/10 px-3 text-xs font-semibold text-amber">Demander</button>
                        </form>
                        <form method="POST" action="<?php echo e(route('admin.marketplace.offers.reject', $offer)); ?>" class="flex gap-1"><?php echo csrf_field(); ?>
                            <input name="reason" required placeholder="Motif de refus" class="h-9 w-52 rounded-lg border border-black/10 bg-surface px-2 text-xs">
                            <button class="h-9 rounded-lg border border-rust/40 bg-rust/10 px-3 text-xs font-semibold text-rust">Refuser</button>
                        </form>
                        <a href="<?php echo e(route('admin.marketplace.offers.show', $offer)); ?>" class="h-9 rounded-lg border border-black/10 px-3 text-xs font-semibold leading-9 text-ink-2">Détail</a>
                    </div>
                <?php endif; ?>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php if (isset($component)) { $__componentOriginal4d04f29578652eb91560cfbf2ab48c57 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4d04f29578652eb91560cfbf2ab48c57 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.pagination','data' => ['paginator' => $offers,'class' => 'mt-6']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.pagination'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['paginator' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($offers),'class' => 'mt-6']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4d04f29578652eb91560cfbf2ab48c57)): ?>
<?php $attributes = $__attributesOriginal4d04f29578652eb91560cfbf2ab48c57; ?>
<?php unset($__attributesOriginal4d04f29578652eb91560cfbf2ab48c57); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4d04f29578652eb91560cfbf2ab48c57)): ?>
<?php $component = $__componentOriginal4d04f29578652eb91560cfbf2ab48c57; ?>
<?php unset($__componentOriginal4d04f29578652eb91560cfbf2ab48c57); ?>
<?php endif; ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\USER\Documents\GitHub\malkuthar-app\resources\views/admin/marketplace/offers/index.blade.php ENDPATH**/ ?>