<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'tone' => 'info',   // info | success | warning | error
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'tone' => 'info',   // info | success | warning | error
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $tones = [
        'info'    => 'border-line bg-ground-alt text-ink-2',
        'success' => 'border-brand-green/30 bg-brand-green/[0.08] text-brand-green',
        'warning' => 'border-amber/40 bg-amber/[0.10] text-amber',
        'error'   => 'border-rust/30 bg-rust/[0.08] text-rust',
    ];
?>

<div <?php echo e($attributes->merge([
    'class' => 'rounded-xl border px-4 py-3 text-sm backdrop-blur '.($tones[$tone] ?? $tones['info']),
    'role' => 'status',
])); ?>><?php echo e($slot); ?></div>
<?php /**PATH C:\Users\USER\Documents\GitHub\malkuthar-app\resources\views/components/ui/alert.blade.php ENDPATH**/ ?>