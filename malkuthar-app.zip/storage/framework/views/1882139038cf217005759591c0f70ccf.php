<?php $__env->startSection('title', 'Administration — Versements vendeurs'); ?>
<?php $__env->startSection('eyebrow', 'Marketplace'); ?>
<?php $__env->startSection('heading', 'Versements vendeurs'); ?>

<?php $__env->startSection('content'); ?>
<?php $money = fn ($n) => number_format((float) $n, 0, ',', ' '); ?>

<div class="mb-6 grid gap-3 sm:grid-cols-3">
    <?php if (isset($component)) { $__componentOriginal81faba2b0dfb90699ac659eea004d68e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal81faba2b0dfb90699ac659eea004d68e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.stat-tile','data' => ['label' => 'Commission plateforme (payé)','value' => $money($summary['commission_earned'])]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.stat-tile'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Commission plateforme (payé)','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($money($summary['commission_earned']))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal81faba2b0dfb90699ac659eea004d68e)): ?>
<?php $attributes = $__attributesOriginal81faba2b0dfb90699ac659eea004d68e; ?>
<?php unset($__attributesOriginal81faba2b0dfb90699ac659eea004d68e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal81faba2b0dfb90699ac659eea004d68e)): ?>
<?php $component = $__componentOriginal81faba2b0dfb90699ac659eea004d68e; ?>
<?php unset($__componentOriginal81faba2b0dfb90699ac659eea004d68e); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal81faba2b0dfb90699ac659eea004d68e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal81faba2b0dfb90699ac659eea004d68e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.stat-tile','data' => ['label' => 'Dû aux vendeurs (en validation)','value' => $money($summary['vendor_pending'])]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.stat-tile'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Dû aux vendeurs (en validation)','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($money($summary['vendor_pending']))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal81faba2b0dfb90699ac659eea004d68e)): ?>
<?php $attributes = $__attributesOriginal81faba2b0dfb90699ac659eea004d68e; ?>
<?php unset($__attributesOriginal81faba2b0dfb90699ac659eea004d68e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal81faba2b0dfb90699ac659eea004d68e)): ?>
<?php $component = $__componentOriginal81faba2b0dfb90699ac659eea004d68e; ?>
<?php unset($__componentOriginal81faba2b0dfb90699ac659eea004d68e); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal81faba2b0dfb90699ac659eea004d68e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal81faba2b0dfb90699ac659eea004d68e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.stat-tile','data' => ['label' => 'Versé aux vendeurs','value' => $money($summary['vendor_paid'])]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.stat-tile'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Versé aux vendeurs','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($money($summary['vendor_paid']))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal81faba2b0dfb90699ac659eea004d68e)): ?>
<?php $attributes = $__attributesOriginal81faba2b0dfb90699ac659eea004d68e; ?>
<?php unset($__attributesOriginal81faba2b0dfb90699ac659eea004d68e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal81faba2b0dfb90699ac659eea004d68e)): ?>
<?php $component = $__componentOriginal81faba2b0dfb90699ac659eea004d68e; ?>
<?php unset($__componentOriginal81faba2b0dfb90699ac659eea004d68e); ?>
<?php endif; ?>
</div>

<nav class="mb-5 flex flex-wrap gap-2 text-sm">
    <?php $__currentLoopData = ['requested' => 'À traiter', 'approved' => 'Approuvés', 'paid' => 'Payés', 'failed' => 'Échoués', 'all' => 'Tous']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $lbl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(route('admin.marketplace.payouts.index', ['status' => $k])); ?>"
           class="<?php echo \Illuminate\Support\Arr::toCssClasses(['rounded-full border px-3 py-1.5',
               'border-accent bg-accent/10 font-semibold text-accent' => $status === $k,
               'border-black/10 text-ink-2 hover:text-ink' => $status !== $k]); ?>"><?php echo e($lbl); ?></a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</nav>

<?php if($payouts->isEmpty()): ?>
    <?php if (isset($component)) { $__componentOriginal3607a477fdef7402bc742abad5df9c51 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3607a477fdef7402bc742abad5df9c51 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.empty-state','data' => ['title' => 'Aucun versement','text' => 'Aucune demande pour ce filtre.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.empty-state'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Aucun versement','text' => 'Aucune demande pour ce filtre.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3607a477fdef7402bc742abad5df9c51)): ?>
<?php $attributes = $__attributesOriginal3607a477fdef7402bc742abad5df9c51; ?>
<?php unset($__attributesOriginal3607a477fdef7402bc742abad5df9c51); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3607a477fdef7402bc742abad5df9c51)): ?>
<?php $component = $__componentOriginal3607a477fdef7402bc742abad5df9c51; ?>
<?php unset($__componentOriginal3607a477fdef7402bc742abad5df9c51); ?>
<?php endif; ?>
<?php else: ?>
    <div class="space-y-3">
        <?php $__currentLoopData = $payouts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="rounded-2xl border border-black/10 bg-surface p-4">
                <div class="flex flex-wrap items-start justify-between gap-3">
                    <div>
                        <p class="font-mono text-sm text-ink"><?php echo e($p->reference); ?></p>
                        <p class="mt-0.5 text-xs text-ink-3">
                            <?php echo e($p->vendor?->display_name); ?> · <?php echo e($p->method); ?>

                            <?php if($p->account): ?> · <?php echo e($p->account->label); ?><?php endif; ?>
                            · <?php echo e($p->created_at->format('d/m/Y H:i')); ?>

                        </p>
                    </div>
                    <div class="flex items-center gap-3">
                        <span class="font-semibold text-ink"><?php echo e($money($p->net_amount)); ?> <?php echo e($p->currency); ?></span>
                        <?php if (isset($component)) { $__componentOriginald271113ca69d52f8dbc84ae4f8468e44 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald271113ca69d52f8dbc84ae4f8468e44 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.status-pill','data' => ['status' => $p->status]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.status-pill'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($p->status)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald271113ca69d52f8dbc84ae4f8468e44)): ?>
<?php $attributes = $__attributesOriginald271113ca69d52f8dbc84ae4f8468e44; ?>
<?php unset($__attributesOriginald271113ca69d52f8dbc84ae4f8468e44); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald271113ca69d52f8dbc84ae4f8468e44)): ?>
<?php $component = $__componentOriginald271113ca69d52f8dbc84ae4f8468e44; ?>
<?php unset($__componentOriginald271113ca69d52f8dbc84ae4f8468e44); ?>
<?php endif; ?>
                    </div>
                </div>
                <?php if(in_array($p->status, ['requested', 'approved'], true)): ?>
                    <div class="mt-3 flex flex-wrap gap-2 border-t border-black/[0.06] pt-3">
                        <?php if($p->status === 'requested'): ?>
                            <form method="POST" action="<?php echo e(route('admin.marketplace.payouts.approve', $p)); ?>"><?php echo csrf_field(); ?>
                                <button class="h-9 rounded-lg border border-black/10 bg-ground-alt px-3 text-xs font-semibold text-ink">Approuver</button>
                            </form>
                        <?php endif; ?>
                        <form method="POST" action="<?php echo e(route('admin.marketplace.payouts.mark-paid', $p)); ?>" class="flex gap-1"><?php echo csrf_field(); ?>
                            <input name="provider_reference" placeholder="Réf. prestataire (fac.)" class="h-9 w-44 rounded-lg border border-black/10 bg-surface px-2 text-xs">
                            <button class="h-9 rounded-lg border border-brand-green/40 bg-brand-green/10 px-3 text-xs font-semibold text-brand-green">Marquer payé</button>
                        </form>
                        <form method="POST" action="<?php echo e(route('admin.marketplace.payouts.mark-failed', $p)); ?>" class="flex gap-1"><?php echo csrf_field(); ?>
                            <input name="reason" required placeholder="Motif d'échec" class="h-9 w-44 rounded-lg border border-black/10 bg-surface px-2 text-xs">
                            <button class="h-9 rounded-lg border border-rust/40 bg-rust/10 px-3 text-xs font-semibold text-rust">Échoué</button>
                        </form>
                    </div>
                <?php elseif($p->failure_reason): ?>
                    <p class="mt-2 text-xs text-rust">Échec : <?php echo e($p->failure_reason); ?></p>
                <?php endif; ?>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php if (isset($component)) { $__componentOriginal4d04f29578652eb91560cfbf2ab48c57 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4d04f29578652eb91560cfbf2ab48c57 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.pagination','data' => ['paginator' => $payouts,'class' => 'mt-6']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.pagination'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['paginator' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($payouts),'class' => 'mt-6']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4d04f29578652eb91560cfbf2ab48c57)): ?>
<?php $attributes = $__attributesOriginal4d04f29578652eb91560cfbf2ab48c57; ?>
<?php unset($__attributesOriginal4d04f29578652eb91560cfbf2ab48c57); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4d04f29578652eb91560cfbf2ab48c57)): ?>
<?php $component = $__componentOriginal4d04f29578652eb91560cfbf2ab48c57; ?>
<?php unset($__componentOriginal4d04f29578652eb91560cfbf2ab48c57); ?>
<?php endif; ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\USER\Documents\GitHub\malkuthar-app\resources\views/admin/marketplace/payouts/index.blade.php ENDPATH**/ ?>