<?php $__env->startSection('title', 'Mes versements'); ?>
<?php $__env->startSection('sidebar'); ?><?php if (isset($component)) { $__componentOriginal515b40fd5ac497547291c4605ab60c40 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal515b40fd5ac497547291c4605ab60c40 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout.sidebar-app','data' => ['space' => 'vendor']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout.sidebar-app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['space' => 'vendor']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal515b40fd5ac497547291c4605ab60c40)): ?>
<?php $attributes = $__attributesOriginal515b40fd5ac497547291c4605ab60c40; ?>
<?php unset($__attributesOriginal515b40fd5ac497547291c4605ab60c40); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal515b40fd5ac497547291c4605ab60c40)): ?>
<?php $component = $__componentOriginal515b40fd5ac497547291c4605ab60c40; ?>
<?php unset($__componentOriginal515b40fd5ac497547291c4605ab60c40); ?>
<?php endif; ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php $money = fn ($n) => number_format((float) $n, 0, ',', ' '); ?>

<p class="text-[11px] font-semibold uppercase tracking-[0.16em] text-accent">Espace vendeur</p>
<h1 class="mt-1 font-display text-2xl font-bold tracking-[-0.01em] text-ink sm:text-3xl">Mes versements</h1>

<div class="mt-5 grid gap-6 lg:grid-cols-[1fr_1fr]">
    
    <section class="rounded-2xl border border-line bg-surface p-5">
        <p class="text-sm text-ink-2">Solde disponible</p>
        <p class="font-display text-2xl font-bold text-ink"><?php echo e($money($balance->available_amount)); ?> <?php echo e($balance->currency); ?></p>

        <?php if($accounts->isEmpty()): ?>
            <p class="mt-3 text-sm text-rust">Ajoutez un moyen de versement pour pouvoir demander un retrait.</p>
        <?php else: ?>
            <form method="POST" action="<?php echo e(route('vendor.payouts.store')); ?>" class="mt-4 grid gap-3">
                <?php echo csrf_field(); ?>
                <label class="text-sm">
                    <span class="text-ink-2">Montant (vide = tout le solde)</span>
                    <input name="amount" type="number" step="0.01" min="0" placeholder="<?php echo e($money($balance->available_amount)); ?>"
                           class="mt-1 h-10 w-full rounded-xl border border-line bg-surface px-3 text-sm">
                    <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-xs text-rust"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </label>
                <label class="text-sm">
                    <span class="text-ink-2">Vers</span>
                    <select name="payout_account_id" class="mt-1 h-10 w-full rounded-xl border border-line bg-surface px-3 text-sm">
                        <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $acc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($acc->id); ?>" <?php if($acc->is_default): echo 'selected'; endif; ?>><?php echo e($acc->label); ?> (<?php echo e($acc->method); ?>)</option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['account'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-xs text-rust"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </label>
                <div><?php if (isset($component)) { $__componentOriginala8bb031a483a05f647cb99ed3a469847 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8bb031a483a05f647cb99ed3a469847 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.button','data' => ['type' => 'submit','variant' => 'primary']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'submit','variant' => 'primary']); ?>Demander le versement <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8bb031a483a05f647cb99ed3a469847)): ?>
<?php $attributes = $__attributesOriginala8bb031a483a05f647cb99ed3a469847; ?>
<?php unset($__attributesOriginala8bb031a483a05f647cb99ed3a469847); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8bb031a483a05f647cb99ed3a469847)): ?>
<?php $component = $__componentOriginala8bb031a483a05f647cb99ed3a469847; ?>
<?php unset($__componentOriginala8bb031a483a05f647cb99ed3a469847); ?>
<?php endif; ?></div>
            </form>
        <?php endif; ?>
    </section>

    
    <section class="rounded-2xl border border-line bg-surface p-5">
        <h2 class="font-display text-base font-semibold text-ink">Moyens de versement</h2>
        <ul class="mt-3 space-y-2 text-sm">
            <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $acc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="flex items-center justify-between rounded-lg border border-line px-3 py-2">
                    <span><?php echo e($acc->label); ?> <span class="text-ink-3">· <?php echo e($acc->method); ?></span><?php if($acc->is_default): ?> <span class="text-xs text-accent">(défaut)</span><?php endif; ?></span>
                    <span class="flex gap-2">
                        <?php if (! ($acc->is_default)): ?>
                            <form method="POST" action="<?php echo e(route('vendor.payouts.accounts.default', $acc)); ?>"><?php echo csrf_field(); ?>
                                <button class="text-xs text-accent hover:underline">Par défaut</button>
                            </form>
                        <?php endif; ?>
                        <form method="POST" action="<?php echo e(route('vendor.payouts.accounts.destroy', $acc)); ?>" onsubmit="return confirm('Supprimer ?')"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button class="text-xs text-rust hover:underline">Supprimer</button>
                        </form>
                    </span>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <form method="POST" action="<?php echo e(route('vendor.payouts.accounts.store')); ?>" class="mt-4 grid gap-2 border-t border-line pt-4">
            <?php echo csrf_field(); ?>
            <div class="grid grid-cols-2 gap-2">
                <select name="method" class="h-9 rounded-lg border border-line bg-surface px-2 text-sm">
                    <option value="mobile_money">Mobile Money</option>
                    <option value="bank_transfer">Virement bancaire</option>
                </select>
                <input name="label" required placeholder="Libellé (ex. MTN)" class="h-9 rounded-lg border border-line bg-surface px-2 text-sm">
            </div>
            <input name="number" required placeholder="Numéro / IBAN" class="h-9 rounded-lg border border-line bg-surface px-2 text-sm">
            <div><?php if (isset($component)) { $__componentOriginala8bb031a483a05f647cb99ed3a469847 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8bb031a483a05f647cb99ed3a469847 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.button','data' => ['type' => 'submit','variant' => 'secondary']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'submit','variant' => 'secondary']); ?>Ajouter <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8bb031a483a05f647cb99ed3a469847)): ?>
<?php $attributes = $__attributesOriginala8bb031a483a05f647cb99ed3a469847; ?>
<?php unset($__attributesOriginala8bb031a483a05f647cb99ed3a469847); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8bb031a483a05f647cb99ed3a469847)): ?>
<?php $component = $__componentOriginala8bb031a483a05f647cb99ed3a469847; ?>
<?php unset($__componentOriginala8bb031a483a05f647cb99ed3a469847); ?>
<?php endif; ?></div>
        </form>
    </section>
</div>

<h2 class="mt-8 font-display text-base font-semibold text-ink">Historique</h2>
<?php if($payouts->isEmpty()): ?>
    <p class="mt-2 text-sm text-ink-3">Aucune demande de versement.</p>
<?php else: ?>
    <div class="mt-3 space-y-2">
        <?php $__currentLoopData = $payouts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="flex items-center justify-between rounded-xl border border-line bg-surface px-4 py-3 text-sm">
                <span class="font-mono text-ink"><?php echo e($p->reference); ?> <span class="text-ink-3">· <?php echo e($p->created_at->format('d/m/Y')); ?></span></span>
                <span class="flex items-center gap-3">
                    <span class="font-semibold text-ink"><?php echo e($money($p->net_amount)); ?> <?php echo e($p->currency); ?></span>
                    <?php if (isset($component)) { $__componentOriginald271113ca69d52f8dbc84ae4f8468e44 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald271113ca69d52f8dbc84ae4f8468e44 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.status-pill','data' => ['status' => $p->status]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.status-pill'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($p->status)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald271113ca69d52f8dbc84ae4f8468e44)): ?>
<?php $attributes = $__attributesOriginald271113ca69d52f8dbc84ae4f8468e44; ?>
<?php unset($__attributesOriginald271113ca69d52f8dbc84ae4f8468e44); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald271113ca69d52f8dbc84ae4f8468e44)): ?>
<?php $component = $__componentOriginald271113ca69d52f8dbc84ae4f8468e44; ?>
<?php unset($__componentOriginald271113ca69d52f8dbc84ae4f8468e44); ?>
<?php endif; ?>
                </span>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php if (isset($component)) { $__componentOriginal4d04f29578652eb91560cfbf2ab48c57 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4d04f29578652eb91560cfbf2ab48c57 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.pagination','data' => ['paginator' => $payouts,'class' => 'mt-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.pagination'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['paginator' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($payouts),'class' => 'mt-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4d04f29578652eb91560cfbf2ab48c57)): ?>
<?php $attributes = $__attributesOriginal4d04f29578652eb91560cfbf2ab48c57; ?>
<?php unset($__attributesOriginal4d04f29578652eb91560cfbf2ab48c57); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4d04f29578652eb91560cfbf2ab48c57)): ?>
<?php $component = $__componentOriginal4d04f29578652eb91560cfbf2ab48c57; ?>
<?php unset($__componentOriginal4d04f29578652eb91560cfbf2ab48c57); ?>
<?php endif; ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\USER\Documents\GitHub\malkuthar-app\resources\views/vendor/payouts/index.blade.php ENDPATH**/ ?>