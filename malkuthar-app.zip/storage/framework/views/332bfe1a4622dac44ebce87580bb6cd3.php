<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'name',
    'label' => null,
    'type' => 'text',
    'value' => null,
    'hint' => null,
    'required' => false,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'name',
    'label' => null,
    'type' => 'text',
    'value' => null,
    'hint' => null,
    'required' => false,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $id = $attributes->get('id', $name);
    $hasError = isset($errors) && $errors->has($name);
?>

<div class="group flex flex-col gap-1.5">
    <?php if($label): ?>
        <div class="flex items-center justify-between">
            <label for="<?php echo e($id); ?>" class="text-[12.5px] font-semibold tracking-wide text-ink-2 transition-colors group-focus-within:text-accent">
                <?php echo e($label); ?><?php if($required): ?><span class="ml-1 text-accent font-bold" title="Requis">*</span><?php endif; ?>
            </label>
            <?php if($hint): ?>
                <span class="text-[11px] text-ink-3"><?php echo e($hint); ?></span>
            <?php endif; ?>
        </div>
    <?php endif; ?>

    <div class="relative flex items-center">
        <input
            id="<?php echo e($id); ?>"
            name="<?php echo e($name); ?>"
            type="<?php echo e($type); ?>"
            <?php if($required): ?> required <?php endif; ?>
            value="<?php echo e(old($name, $value)); ?>"
            <?php echo e($attributes->except('id')->merge([
                'class' => 'h-11 w-full rounded-xl border bg-surface px-3.5 text-[14.5px] text-ink placeholder:text-ink-3/70 '
                    .'shadow-[0_1px_2px_rgba(46,44,40,0.03),inset_0_1px_1px_rgba(255,255,255,0.85)] '
                    .'transition-all duration-200 focus:outline-none focus:ring-4 '
                    .($hasError
                        ? 'border-rust/70 bg-rust/[0.015] focus:border-rust focus:ring-rust/15'
                        : 'border-line/90 hover:border-line-strong focus:border-accent focus:bg-surface focus:ring-accent/15 focus:shadow-[0_0_0_1px_var(--color-accent),0_2px_8px_rgba(138,109,44,0.08)]'),
            ])); ?>

        >
    </div>

    <?php if($hasError): ?>
        <p class="flex items-center gap-1 text-[11.5px] font-medium text-rust">
            <svg class="h-3.5 w-3.5 shrink-0" viewBox="0 0 16 16" fill="currentColor">
                <path fill-rule="evenodd" d="M8 15A7 7 0 1 0 8 1a7 7 0 0 0 0 14zm-.75-4.25a.75.75 0 1 1 1.5 0 .75.75 0 0 1-1.5 0zM8 4a.75.75 0 0 1 .75.75v4a.75.75 0 0 1-1.5 0v-4A.75.75 0 0 1 8 4z" clip-rule="evenodd" />
            </svg>
            <span><?php echo e($errors->first($name)); ?></span>
        </p>
    <?php endif; ?>
</div>
<?php /**PATH C:\Users\USER\Documents\GitHub\malkuthar-app\resources\views/components/ui/field.blade.php ENDPATH**/ ?>