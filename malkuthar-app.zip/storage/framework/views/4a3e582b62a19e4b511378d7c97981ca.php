<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'tone' => 'ink',   // ink | gold | rust | muted | accent
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'tone' => 'ink',   // ink | gold | rust | muted | accent
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $tones = [
        'ink' => 'border-black/15 bg-black/[0.04] text-ink',
        'accent' => 'border-accent/30 bg-accent/10 text-accent',
        'gold' => 'border-gold/40 bg-gold/10 text-gold',
        'rust' => 'border-rust/30 bg-rust/10 text-rust',
        'muted' => 'border-black/10 text-ink-3',
    ];
?>

<span <?php echo e($attributes->merge([
    'class' => 'inline-flex items-center gap-1 rounded-full border px-2 py-0.5 '
        .'text-[10.5px] font-semibold uppercase tracking-[0.07em] backdrop-blur '
        .($tones[$tone] ?? $tones['ink']),
])); ?>><?php echo e($slot); ?></span>
<?php /**PATH C:\Users\USER\Documents\GitHub\malkuthar-app\resources\views/components/ui/badge.blade.php ENDPATH**/ ?>