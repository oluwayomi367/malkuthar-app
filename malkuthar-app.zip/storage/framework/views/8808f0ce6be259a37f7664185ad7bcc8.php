<?php $__env->startSection('title', 'Mes téléchargements'); ?>
<?php $__env->startSection('sidebar'); ?><?php if (isset($component)) { $__componentOriginal515b40fd5ac497547291c4605ab60c40 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal515b40fd5ac497547291c4605ab60c40 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout.sidebar-app','data' => ['space' => 'account']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout.sidebar-app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['space' => 'account']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal515b40fd5ac497547291c4605ab60c40)): ?>
<?php $attributes = $__attributesOriginal515b40fd5ac497547291c4605ab60c40; ?>
<?php unset($__attributesOriginal515b40fd5ac497547291c4605ab60c40); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal515b40fd5ac497547291c4605ab60c40)): ?>
<?php $component = $__componentOriginal515b40fd5ac497547291c4605ab60c40; ?>
<?php unset($__componentOriginal515b40fd5ac497547291c4605ab60c40); ?>
<?php endif; ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<h1 class="font-display text-2xl font-bold tracking-[-0.01em] text-ink sm:text-3xl">Mes téléchargements</h1>
<p class="mt-1 text-sm text-ink-2">Vos produits digitaux. Chaque lien reste valable 7 jours ; régénérez-le en rechargeant cette page.</p>

<div class="mt-8 space-y-2">
    <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-black/10 bg-surface px-4 py-4">
            <div class="min-w-0">
                <p class="truncate text-[15px] font-medium text-ink"><?php echo e($item->product_name); ?></p>
                <p class="mt-0.5 text-xs text-ink-3">
                    Commande <span class="font-mono"><?php echo e($item->order?->order_number); ?></span>
                    · <?php echo e($item->order?->created_at?->format('d/m/Y')); ?>

                    <?php if($item->max_downloads > 0): ?>
                        · <span class="<?php if((int) $item->download_count >= $item->max_downloads): ?> text-rust <?php endif; ?>"><?php echo e((int) $item->download_count); ?>/<?php echo e($item->max_downloads); ?> téléchargements</span>
                    <?php endif; ?>
                </p>
            </div>
            <?php if($item->max_downloads > 0 && (int) $item->download_count >= $item->max_downloads): ?>
                <span class="inline-flex h-9 items-center rounded-lg border border-black/10 px-3.5 text-sm text-ink-3">Quota atteint</span>
            <?php else: ?>
                <a href="<?php echo e($item->download_url); ?>" class="inline-flex h-9 items-center gap-2 rounded-lg bg-accent px-3.5 text-sm font-semibold text-white shadow-[0_8px_24px_-8px] shadow-black/10">
                    <svg class="h-4 w-4" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M8 2v8m0 0L5 7m3 3l3-3M3 13h10" stroke-linecap="round" stroke-linejoin="round"/></svg>
                    Télécharger
                </a>
            <?php endif; ?>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <?php if (isset($component)) { $__componentOriginal3607a477fdef7402bc742abad5df9c51 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3607a477fdef7402bc742abad5df9c51 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.empty-state','data' => ['title' => 'Aucun produit digital','text' => 'Vos ebooks, formations et fichiers achetés apparaîtront ici.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.empty-state'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Aucun produit digital','text' => 'Vos ebooks, formations et fichiers achetés apparaîtront ici.']); ?>
             <?php $__env->slot('cta', null, []); ?> 
                <?php if (isset($component)) { $__componentOriginala8bb031a483a05f647cb99ed3a469847 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8bb031a483a05f647cb99ed3a469847 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.button','data' => ['href' => route('catalog.index', ['type' => 'digital']),'variant' => 'primary']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('catalog.index', ['type' => 'digital'])),'variant' => 'primary']); ?>Explorer la boutique <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8bb031a483a05f647cb99ed3a469847)): ?>
<?php $attributes = $__attributesOriginala8bb031a483a05f647cb99ed3a469847; ?>
<?php unset($__attributesOriginala8bb031a483a05f647cb99ed3a469847); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8bb031a483a05f647cb99ed3a469847)): ?>
<?php $component = $__componentOriginala8bb031a483a05f647cb99ed3a469847; ?>
<?php unset($__componentOriginala8bb031a483a05f647cb99ed3a469847); ?>
<?php endif; ?>
             <?php $__env->endSlot(); ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3607a477fdef7402bc742abad5df9c51)): ?>
<?php $attributes = $__attributesOriginal3607a477fdef7402bc742abad5df9c51; ?>
<?php unset($__attributesOriginal3607a477fdef7402bc742abad5df9c51); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3607a477fdef7402bc742abad5df9c51)): ?>
<?php $component = $__componentOriginal3607a477fdef7402bc742abad5df9c51; ?>
<?php unset($__componentOriginal3607a477fdef7402bc742abad5df9c51); ?>
<?php endif; ?>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\USER\Documents\GitHub\malkuthar-app\resources\views/account/downloads.blade.php ENDPATH**/ ?>