<?php $gtm = config('malkuthar.tracking.gtm_container_id'); ?>
<?php if($gtm): ?>
    <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=<?php echo e($gtm); ?>"
        height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<?php endif; ?>
<?php /**PATH C:\Users\USER\Documents\GitHub\malkuthar-app\resources\views/partials/tracking-body.blade.php ENDPATH**/ ?>