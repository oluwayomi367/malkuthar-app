<?php $__env->startSection('title', 'Commande ' . $order->order_number); ?>
<?php $__env->startSection('eyebrow', 'Ventes'); ?>
<?php $__env->startSection('heading', 'Commande ' . $order->order_number); ?>

<?php $__env->startSection('actions'); ?>
    <?php if (isset($component)) { $__componentOriginala8bb031a483a05f647cb99ed3a469847 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8bb031a483a05f647cb99ed3a469847 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.button','data' => ['href' => route('admin.orders.index'),'variant' => 'secondary']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('admin.orders.index')),'variant' => 'secondary']); ?>← Retour <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8bb031a483a05f647cb99ed3a469847)): ?>
<?php $attributes = $__attributesOriginala8bb031a483a05f647cb99ed3a469847; ?>
<?php unset($__attributesOriginala8bb031a483a05f647cb99ed3a469847); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8bb031a483a05f647cb99ed3a469847)): ?>
<?php $component = $__componentOriginala8bb031a483a05f647cb99ed3a469847; ?>
<?php unset($__componentOriginala8bb031a483a05f647cb99ed3a469847); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php
    $m = fn ($n) => number_format((float) $n, 0, ',', ' ');
    $providerLabels = ['fedapay' => 'FedaPay', 'cinetpay' => 'CinetPay', 'cod' => 'Paiement à la livraison'];
    $typeLabels = ['digital' => 'Digital', 'physical' => 'Physique', 'service' => 'Service'];
    $statusMeta = [
        'pending' => ['En attente', 'muted'], 'processing' => ['En cours', 'accent'],
        'completed' => ['Terminée', 'accent'], 'cancelled' => ['Annulée', 'rust'], 'refunded' => ['Remboursée', 'rust'],
    ];
    [$sLabel, $sTone] = $statusMeta[$order->status] ?? [$order->status, 'muted'];
    $fulfilmentLabels = ['preparing' => 'En préparation', 'shipped' => 'Expédiée', 'in_delivery' => 'En livraison', 'delivered' => 'Livrée'];
    $isCodPending = $order->isCashOnDelivery() && $order->payment_status === 'pending' && $order->status !== 'cancelled';
?>

<div class="mb-6 flex flex-wrap items-center gap-2">
    <?php if (isset($component)) { $__componentOriginalab7baa01105b3dfe1e0cf1dfc58879b4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalab7baa01105b3dfe1e0cf1dfc58879b4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.badge','data' => ['tone' => $sTone]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['tone' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sTone)]); ?><?php echo e($sLabel); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalab7baa01105b3dfe1e0cf1dfc58879b4)): ?>
<?php $attributes = $__attributesOriginalab7baa01105b3dfe1e0cf1dfc58879b4; ?>
<?php unset($__attributesOriginalab7baa01105b3dfe1e0cf1dfc58879b4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalab7baa01105b3dfe1e0cf1dfc58879b4)): ?>
<?php $component = $__componentOriginalab7baa01105b3dfe1e0cf1dfc58879b4; ?>
<?php unset($__componentOriginalab7baa01105b3dfe1e0cf1dfc58879b4); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginald271113ca69d52f8dbc84ae4f8468e44 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald271113ca69d52f8dbc84ae4f8468e44 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.status-pill','data' => ['status' => $order->payment_status]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.status-pill'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($order->payment_status)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald271113ca69d52f8dbc84ae4f8468e44)): ?>
<?php $attributes = $__attributesOriginald271113ca69d52f8dbc84ae4f8468e44; ?>
<?php unset($__attributesOriginald271113ca69d52f8dbc84ae4f8468e44); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald271113ca69d52f8dbc84ae4f8468e44)): ?>
<?php $component = $__componentOriginald271113ca69d52f8dbc84ae4f8468e44; ?>
<?php unset($__componentOriginald271113ca69d52f8dbc84ae4f8468e44); ?>
<?php endif; ?>
    <span class="text-sm text-ink-3"><?php echo e($providerLabels[$order->payment_provider] ?? ($order->payment_provider ?: '—')); ?></span>
    <span class="ml-auto text-sm text-ink-3">Passée le <?php echo e($order->created_at?->format('d/m/Y à H:i')); ?></span>
</div>

<div class="grid gap-8 lg:grid-cols-[1fr_320px] lg:gap-10">
    
    <div class="space-y-6">
        
        <div class="overflow-x-auto rounded-2xl border border-black/10">
            <table class="w-full min-w-[520px] text-left text-sm">
                <thead class="bg-surface text-[10.5px] uppercase tracking-[0.09em] text-ink-3">
                    <tr>
                        <th class="px-4 py-3 font-semibold">Article</th>
                        <th class="px-4 py-3 font-semibold">Type</th>
                        <th class="px-4 py-3 text-center font-semibold">Qté</th>
                        <th class="px-4 py-3 text-right font-semibold">Total</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-black/[0.06]">
                    <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="px-4 py-3">
                                <?php if($item->product): ?>
                                    <a href="<?php echo e(route('admin.products.show', $item->product)); ?>" class="font-medium text-ink hover:text-accent"><?php echo e($item->product_name); ?></a>
                                <?php else: ?>
                                    <span class="font-medium text-ink"><?php echo e($item->product_name); ?></span>
                                <?php endif; ?>
                                <?php if($item->variant_sku): ?><span class="block text-xs text-ink-3"><?php echo e($item->variant_sku); ?></span><?php endif; ?>
                                <?php if($item->reservation_datetime): ?><span class="block text-xs text-ink-3">RDV <?php echo e($item->reservation_datetime->format('d/m/Y H:i')); ?></span><?php endif; ?>
                            </td>
                            <td class="px-4 py-3">
                                <?php if (isset($component)) { $__componentOriginalab7baa01105b3dfe1e0cf1dfc58879b4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalab7baa01105b3dfe1e0cf1dfc58879b4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.badge','data' => ['tone' => 'muted']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['tone' => 'muted']); ?><?php echo e($typeLabels[$item->product_type] ?? $item->product_type); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalab7baa01105b3dfe1e0cf1dfc58879b4)): ?>
<?php $attributes = $__attributesOriginalab7baa01105b3dfe1e0cf1dfc58879b4; ?>
<?php unset($__attributesOriginalab7baa01105b3dfe1e0cf1dfc58879b4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalab7baa01105b3dfe1e0cf1dfc58879b4)): ?>
<?php $component = $__componentOriginalab7baa01105b3dfe1e0cf1dfc58879b4; ?>
<?php unset($__componentOriginalab7baa01105b3dfe1e0cf1dfc58879b4); ?>
<?php endif; ?>
                                <?php if($item->is_affiliable_snapshot): ?><?php if (isset($component)) { $__componentOriginalab7baa01105b3dfe1e0cf1dfc58879b4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalab7baa01105b3dfe1e0cf1dfc58879b4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.badge','data' => ['tone' => 'accent','class' => 'ml-1']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['tone' => 'accent','class' => 'ml-1']); ?>Affiliable <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalab7baa01105b3dfe1e0cf1dfc58879b4)): ?>
<?php $attributes = $__attributesOriginalab7baa01105b3dfe1e0cf1dfc58879b4; ?>
<?php unset($__attributesOriginalab7baa01105b3dfe1e0cf1dfc58879b4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalab7baa01105b3dfe1e0cf1dfc58879b4)): ?>
<?php $component = $__componentOriginalab7baa01105b3dfe1e0cf1dfc58879b4; ?>
<?php unset($__componentOriginalab7baa01105b3dfe1e0cf1dfc58879b4); ?>
<?php endif; ?><?php endif; ?>
                            </td>
                            <td class="px-4 py-3 text-center text-ink-2"><?php echo e($item->quantity); ?></td>
                            <td class="px-4 py-3 text-right text-ink"><?php echo e($m($item->total_price)); ?> <?php echo e($item->currency); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <tfoot class="border-t border-black/10 text-sm">
                    <tr><td colspan="3" class="px-4 py-1.5 text-right text-ink-3">Sous-total</td><td class="px-4 py-1.5 text-right text-ink-2"><?php echo e($m($order->subtotal)); ?> <?php echo e($order->currency); ?></td></tr>
                    <?php if((float) $order->discount_total > 0): ?>
                        <tr><td colspan="3" class="px-4 py-1.5 text-right text-ink-3">Remise<?php echo e($order->coupon_code ? ' ('.$order->coupon_code.')' : ''); ?></td><td class="px-4 py-1.5 text-right text-ink-2">−<?php echo e($m($order->discount_total)); ?></td></tr>
                    <?php endif; ?>
                    <?php if((float) $order->shipping_fee > 0): ?>
                        <tr><td colspan="3" class="px-4 py-1.5 text-right text-ink-3">Livraison</td><td class="px-4 py-1.5 text-right text-ink-2"><?php echo e($m($order->shipping_fee)); ?></td></tr>
                    <?php endif; ?>
                    <tr class="font-semibold"><td colspan="3" class="px-4 py-2 text-right text-ink">Total</td><td class="px-4 py-2 text-right text-ink"><?php echo e($m($order->total_amount)); ?> <?php echo e($order->currency); ?></td></tr>
                </tfoot>
            </table>
        </div>

        
        <div class="rounded-2xl border border-black/10 bg-surface p-5">
            <p class="text-[11px] font-semibold uppercase tracking-[0.12em] text-ink-3">Commissions d'affiliation</p>
            <?php if($order->referringAffiliate): ?>
                <p class="mt-2 text-sm text-ink-2">
                    Vente référée par
                    <a href="<?php echo e(route('admin.affiliates.show', $order->referringAffiliate)); ?>" class="text-accent hover:underline"><?php echo e(trim("{$order->referringAffiliate->first_name} {$order->referringAffiliate->last_name}")); ?></a>
                    <span class="text-ink-3">(<?php echo e($order->referringAffiliate->affiliate_id); ?>)</span>
                </p>
            <?php else: ?>
                <p class="mt-2 text-sm text-ink-3">Aucun affilié référent sur cette commande.</p>
            <?php endif; ?>

            <?php if($commissions->isNotEmpty()): ?>
                <ul class="mt-3 space-y-2 text-sm">
                    <?php $__currentLoopData = $commissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="flex items-baseline justify-between gap-3 border-b border-black/[0.05] pb-2 last:border-0 last:pb-0">
                            <span class="text-ink-2">
                                Niveau <?php echo e($c->level); ?> — <?php echo e($c->user?->first_name); ?> <?php echo e($c->user?->last_name); ?>

                                <?php if($c->source_type === 'commission_reversal'): ?><span class="text-rust"> · reprise</span><?php endif; ?>
                            </span>
                            <span class="flex items-center gap-2 shrink-0">
                                <span class="<?php echo e($c->source_type === 'commission_reversal' ? 'text-rust' : 'text-ink'); ?>"><?php echo e($c->source_type === 'commission_reversal' ? '−' : ''); ?><?php echo e($m($c->amount)); ?> <?php echo e($c->currency); ?></span>
                                <?php if (isset($component)) { $__componentOriginald271113ca69d52f8dbc84ae4f8468e44 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald271113ca69d52f8dbc84ae4f8468e44 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.status-pill','data' => ['status' => $c->status]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.status-pill'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($c->status)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald271113ca69d52f8dbc84ae4f8468e44)): ?>
<?php $attributes = $__attributesOriginald271113ca69d52f8dbc84ae4f8468e44; ?>
<?php unset($__attributesOriginald271113ca69d52f8dbc84ae4f8468e44); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald271113ca69d52f8dbc84ae4f8468e44)): ?>
<?php $component = $__componentOriginald271113ca69d52f8dbc84ae4f8468e44; ?>
<?php unset($__componentOriginald271113ca69d52f8dbc84ae4f8468e44); ?>
<?php endif; ?>
                            </span>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php elseif($order->payment_status === 'paid'): ?>
                <p class="mt-3 text-sm text-ink-3">Aucune commission (aucune ligne digitale affiliable, ou pas d'affilié référent).</p>
            <?php else: ?>
                <p class="mt-3 text-sm text-ink-3">Les commissions seront calculées une fois le paiement confirmé.</p>
            <?php endif; ?>
        </div>

        
        <div class="grid gap-4 sm:grid-cols-2">
            <div class="rounded-2xl border border-black/10 bg-surface p-5 text-sm">
                <p class="text-[11px] font-semibold uppercase tracking-[0.12em] text-ink-3">Client</p>
                <?php if($order->user): ?>
                    <p class="mt-2 text-ink"><?php echo e(trim("{$order->user->first_name} {$order->user->last_name}") ?: '—'); ?></p>
                    <p class="text-ink-3"><?php echo e($order->user->email); ?></p>
                    <?php if($order->user->phone): ?><p class="text-ink-3"><?php echo e($order->user->phone); ?></p><?php endif; ?>
                <?php else: ?>
                    <p class="mt-2 text-ink-3">Commande invité</p>
                <?php endif; ?>
            </div>
            <div class="rounded-2xl border border-black/10 bg-surface p-5 text-sm">
                <p class="text-[11px] font-semibold uppercase tracking-[0.12em] text-ink-3">Livraison</p>
                <?php if($order->shipping_address): ?>
                    <?php $a = $order->shipping_address; ?>
                    <p class="mt-2 text-ink"><?php echo e(data_get($a, 'first_name')); ?> <?php echo e(data_get($a, 'last_name')); ?></p>
                    <p class="text-ink-3"><?php echo e(data_get($a, 'address')); ?></p>
                    <p class="text-ink-3"><?php echo e(data_get($a, 'neighborhood')); ?> <?php echo e(data_get($a, 'city')); ?> <?php echo e(data_get($a, 'country')); ?></p>
                    <p class="text-ink-3"><?php echo e(data_get($a, 'phone')); ?></p>
                <?php else: ?>
                    <p class="mt-2 text-ink-3">Pas d'adresse (commande sans article physique).</p>
                <?php endif; ?>
                <?php if($order->shipping_status): ?>
                    <p class="mt-2"><?php if (isset($component)) { $__componentOriginalab7baa01105b3dfe1e0cf1dfc58879b4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalab7baa01105b3dfe1e0cf1dfc58879b4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.badge','data' => ['tone' => 'accent']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['tone' => 'accent']); ?><?php echo e($fulfilmentLabels[$order->shipping_status] ?? $order->shipping_status); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalab7baa01105b3dfe1e0cf1dfc58879b4)): ?>
<?php $attributes = $__attributesOriginalab7baa01105b3dfe1e0cf1dfc58879b4; ?>
<?php unset($__attributesOriginalab7baa01105b3dfe1e0cf1dfc58879b4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalab7baa01105b3dfe1e0cf1dfc58879b4)): ?>
<?php $component = $__componentOriginalab7baa01105b3dfe1e0cf1dfc58879b4; ?>
<?php unset($__componentOriginalab7baa01105b3dfe1e0cf1dfc58879b4); ?>
<?php endif; ?></p>
                <?php endif; ?>
                <?php if($order->tracking_number): ?><p class="mt-1 text-ink-3">Suivi : <?php echo e($order->shipping_carrier); ?> <?php echo e($order->tracking_number); ?></p><?php endif; ?>
            </div>
        </div>

        <?php if($order->notes): ?>
            <div class="rounded-2xl border border-black/10 bg-surface p-5 text-sm">
                <p class="text-[11px] font-semibold uppercase tracking-[0.12em] text-ink-3">Notes</p>
                <p class="mt-2 whitespace-pre-line text-ink-2"><?php echo e($order->notes); ?></p>
            </div>
        <?php endif; ?>
    </div>

    
    <div class="space-y-4">
        <div class="rounded-2xl border border-black/10 bg-surface p-5 text-sm">
            <p class="text-[11px] font-semibold uppercase tracking-[0.12em] text-ink-3">Paiement</p>
            <dl class="mt-2 space-y-1.5">
                <div class="flex justify-between"><dt class="text-ink-3">Mode</dt><dd class="text-ink"><?php echo e($providerLabels[$order->payment_provider] ?? ($order->payment_provider ?: '—')); ?></dd></div>
                <div class="flex justify-between"><dt class="text-ink-3">Méthode</dt><dd class="text-ink"><?php echo e($order->payment_method ?: '—'); ?></dd></div>
                <div class="flex justify-between"><dt class="text-ink-3">Référence</dt><dd class="font-mono text-xs text-ink"><?php echo e($order->payment_reference ?: '—'); ?></dd></div>
                <?php if($order->cod_collected_at): ?>
                    <div class="flex justify-between"><dt class="text-ink-3">Encaissé le</dt><dd class="text-ink"><?php echo e($order->cod_collected_at->format('d/m/Y H:i')); ?></dd></div>
                    <?php if($order->codCollector): ?>
                        <div class="flex justify-between"><dt class="text-ink-3">Par</dt><dd class="text-ink"><?php echo e($order->codCollector->first_name); ?> <?php echo e($order->codCollector->last_name); ?></dd></div>
                    <?php endif; ?>
                <?php endif; ?>
            </dl>
        </div>

        
        <?php if($isCodPending): ?>
            <form method="POST" action="<?php echo e(route('admin.orders.collect-cod', $order)); ?>"
                  onsubmit="return confirm('Confirmer l\'encaissement de <?php echo e($m($order->total_amount)); ?> <?php echo e($order->currency); ?> ? Les commissions et la livraison seront déclenchées.')"
                  class="rounded-2xl border border-brand-green/30 bg-brand-green/[0.06] p-5">
                <?php echo csrf_field(); ?>
                <p class="text-[11px] font-semibold uppercase tracking-[0.12em] text-brand-green">Paiement à la livraison</p>
                <p class="mt-1 text-sm text-ink-2">Déclarez l'encaissement une fois l'argent reçu du client.</p>
                <button class="mt-3 h-10 w-full rounded-xl bg-brand-green text-sm font-semibold text-white hover:opacity-90">Encaisser <?php echo e($m($order->total_amount)); ?> <?php echo e($order->currency); ?></button>
            </form>
        <?php endif; ?>

        
        <?php if($order->payment_status === 'paid' && $order->has_physical_items): ?>
            <form method="POST" action="<?php echo e(route('admin.orders.fulfilment', $order)); ?>" class="rounded-2xl border border-black/10 bg-surface p-5">
                <?php echo csrf_field(); ?>
                <p class="text-[11px] font-semibold uppercase tracking-[0.12em] text-ink-3">Suivi de livraison</p>
                <div class="mt-3 space-y-2">
                    <?php if (isset($component)) { $__componentOriginal231e2c645bf8af0c5c05a5dc5a94c862 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal231e2c645bf8af0c5c05a5dc5a94c862 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.select','data' => ['name' => 'shipping_status','selected' => $order->shipping_status,'options' => ['preparing' => 'En préparation', 'shipped' => 'Expédiée', 'in_delivery' => 'En livraison', 'delivered' => 'Livrée'],'required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'shipping_status','selected' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($order->shipping_status),'options' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(['preparing' => 'En préparation', 'shipped' => 'Expédiée', 'in_delivery' => 'En livraison', 'delivered' => 'Livrée']),'required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal231e2c645bf8af0c5c05a5dc5a94c862)): ?>
<?php $attributes = $__attributesOriginal231e2c645bf8af0c5c05a5dc5a94c862; ?>
<?php unset($__attributesOriginal231e2c645bf8af0c5c05a5dc5a94c862); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal231e2c645bf8af0c5c05a5dc5a94c862)): ?>
<?php $component = $__componentOriginal231e2c645bf8af0c5c05a5dc5a94c862; ?>
<?php unset($__componentOriginal231e2c645bf8af0c5c05a5dc5a94c862); ?>
<?php endif; ?>
                    <input name="shipping_carrier" value="<?php echo e($order->shipping_carrier); ?>" placeholder="Transporteur"
                           class="h-10 w-full rounded-xl border border-black/10 bg-surface px-3 text-sm text-ink placeholder:text-ink-3">
                    <input name="tracking_number" value="<?php echo e($order->tracking_number); ?>" placeholder="N° de suivi"
                           class="h-10 w-full rounded-xl border border-black/10 bg-surface px-3 text-sm text-ink placeholder:text-ink-3">
                    <button class="h-10 w-full rounded-xl border border-black/15 bg-ground/60 text-sm font-semibold text-ink hover:bg-ground">Mettre à jour</button>
                </div>
            </form>
        <?php endif; ?>

        
        <?php if($order->payment_status === 'paid'): ?>
            <form method="POST" action="<?php echo e(route('admin.orders.refund', $order)); ?>"
                  onsubmit="return confirm('Rembourser cette commande ? Les commissions liées seront reprises et le stock réapprovisionné.')"
                  class="rounded-2xl border border-rust/30 bg-rust/[0.05] p-5">
                <?php echo csrf_field(); ?>
                <p class="text-[11px] font-semibold uppercase tracking-[0.12em] text-rust">Rembourser</p>
                <input name="reason" placeholder="Motif (facultatif)"
                       class="mt-3 h-10 w-full rounded-xl border border-black/10 bg-surface px-3 text-sm text-ink placeholder:text-ink-3">
                <button class="mt-2 h-10 w-full rounded-xl border border-rust/40 bg-rust/10 text-sm font-semibold text-rust hover:bg-rust/20">Rembourser la commande</button>
            </form>
        
        <?php elseif($order->status !== 'cancelled'): ?>
            <form method="POST" action="<?php echo e(route('admin.orders.cancel', $order)); ?>"
                  onsubmit="return confirm('Annuler cette commande ? Le stock réservé et les créneaux seront libérés.')"
                  class="rounded-2xl border border-rust/30 bg-rust/[0.05] p-5">
                <?php echo csrf_field(); ?>
                <p class="text-[11px] font-semibold uppercase tracking-[0.12em] text-rust">Annuler</p>
                <input name="reason" placeholder="Motif (facultatif)"
                       class="mt-3 h-10 w-full rounded-xl border border-black/10 bg-surface px-3 text-sm text-ink placeholder:text-ink-3">
                <button class="mt-2 h-10 w-full rounded-xl border border-rust/40 bg-rust/10 text-sm font-semibold text-rust hover:bg-rust/20">Annuler la commande</button>
            </form>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\USER\Documents\GitHub\malkuthar-app\resources\views/admin/orders/show.blade.php ENDPATH**/ ?>