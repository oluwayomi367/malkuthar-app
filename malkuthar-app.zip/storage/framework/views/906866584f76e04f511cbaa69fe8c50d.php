<?php $__env->startSection('title', 'Commande ' . $order->order_number); ?>
<?php $__env->startSection('sidebar'); ?><?php if (isset($component)) { $__componentOriginal515b40fd5ac497547291c4605ab60c40 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal515b40fd5ac497547291c4605ab60c40 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout.sidebar-app','data' => ['space' => 'account']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout.sidebar-app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['space' => 'account']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal515b40fd5ac497547291c4605ab60c40)): ?>
<?php $attributes = $__attributesOriginal515b40fd5ac497547291c4605ab60c40; ?>
<?php unset($__attributesOriginal515b40fd5ac497547291c4605ab60c40); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal515b40fd5ac497547291c4605ab60c40)): ?>
<?php $component = $__componentOriginal515b40fd5ac497547291c4605ab60c40; ?>
<?php unset($__componentOriginal515b40fd5ac497547291c4605ab60c40); ?>
<?php endif; ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php $m = fn ($n) => number_format((float) $n, 0, ',', ' '); ?>

<a href="<?php echo e(route('account.orders')); ?>" class="inline-flex items-center gap-1.5 text-sm text-ink-2 hover:text-ink">← Mes commandes</a>

<div class="mt-3 flex flex-wrap items-center justify-between gap-3">
    <h1 class="font-display text-2xl font-bold tracking-[-0.01em] text-ink">
        Commande <span class="font-mono text-xl text-ink-2"><?php echo e($order->order_number); ?></span>
    </h1>
    <?php if (isset($component)) { $__componentOriginald271113ca69d52f8dbc84ae4f8468e44 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald271113ca69d52f8dbc84ae4f8468e44 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.status-pill','data' => ['status' => $order->payment_status]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.status-pill'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($order->payment_status)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald271113ca69d52f8dbc84ae4f8468e44)): ?>
<?php $attributes = $__attributesOriginald271113ca69d52f8dbc84ae4f8468e44; ?>
<?php unset($__attributesOriginald271113ca69d52f8dbc84ae4f8468e44); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald271113ca69d52f8dbc84ae4f8468e44)): ?>
<?php $component = $__componentOriginald271113ca69d52f8dbc84ae4f8468e44; ?>
<?php unset($__componentOriginald271113ca69d52f8dbc84ae4f8468e44); ?>
<?php endif; ?>
</div>
<p class="mt-1 text-sm text-ink-3">Passée le <?php echo e($order->created_at->translatedFormat('d F Y à H:i')); ?></p>


<?php if($order->has_physical_items && $order->payment_status === 'paid'): ?>
    <div class="mt-8 rounded-2xl border border-black/10 bg-surface p-5">
        <h2 class="mb-4 font-display text-sm font-semibold uppercase tracking-wide text-ink-2">Suivi de livraison</h2>
        <?php if (isset($component)) { $__componentOriginal8b917f2043320d8343006330cf0e72f1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8b917f2043320d8343006330cf0e72f1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.account.order-tracker','data' => ['order' => $order]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('account.order-tracker'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['order' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($order)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8b917f2043320d8343006330cf0e72f1)): ?>
<?php $attributes = $__attributesOriginal8b917f2043320d8343006330cf0e72f1; ?>
<?php unset($__attributesOriginal8b917f2043320d8343006330cf0e72f1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8b917f2043320d8343006330cf0e72f1)): ?>
<?php $component = $__componentOriginal8b917f2043320d8343006330cf0e72f1; ?>
<?php unset($__componentOriginal8b917f2043320d8343006330cf0e72f1); ?>
<?php endif; ?>
    </div>
<?php endif; ?>


<div class="mt-8 overflow-hidden rounded-2xl border border-black/10">
    <table class="w-full text-sm">
        <thead class="bg-surface text-left text-xs uppercase tracking-wide text-ink-3">
            <tr>
                <th class="px-4 py-3 font-semibold">Article</th>
                <th class="px-4 py-3 text-center font-semibold">Qté</th>
                <th class="px-4 py-3 text-right font-semibold">Total</th>
            </tr>
        </thead>
        <tbody class="divide-y divide-black/[0.06]">
            <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="px-4 py-3">
                        <span class="text-ink"><?php echo e($item->product_name); ?></span>
                        <?php if($item->variant_sku): ?>
                            <span class="block text-xs text-ink-3"><?php echo e($item->variant_sku); ?></span>
                        <?php endif; ?>
                        <?php if($item->reservation_datetime): ?>
                            <span class="block text-xs text-ink-3">RDV : <?php echo e($item->reservation_datetime->translatedFormat('d/m/Y H:i')); ?></span>
                        <?php endif; ?>
                    </td>
                    <td class="px-4 py-3 text-center text-ink-2"><?php echo e($item->quantity); ?></td>
                    <td class="px-4 py-3 text-right text-ink"><?php echo e($m($item->total_price)); ?> <?php echo e($item->currency); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        <tfoot class="border-t border-black/10 text-ink-2">
            <tr><td colspan="2" class="px-4 py-2 text-right">Sous-total</td><td class="px-4 py-2 text-right"><?php echo e($m($order->subtotal)); ?> <?php echo e($order->currency); ?></td></tr>
            <?php if((float) $order->discount_total > 0): ?>
                <tr><td colspan="2" class="px-4 py-2 text-right">Remise <?php if($order->coupon_code): ?>(<?php echo e($order->coupon_code); ?>)<?php endif; ?></td><td class="px-4 py-2 text-right text-rust">−<?php echo e($m($order->discount_total)); ?> <?php echo e($order->currency); ?></td></tr>
            <?php endif; ?>
            <?php if((float) $order->shipping_fee > 0): ?>
                <tr><td colspan="2" class="px-4 py-2 text-right">Livraison</td><td class="px-4 py-2 text-right"><?php echo e($m($order->shipping_fee)); ?> <?php echo e($order->currency); ?></td></tr>
            <?php endif; ?>
            <tr class="text-ink"><td colspan="2" class="px-4 py-3 text-right font-semibold">Total</td><td class="px-4 py-3 text-right font-semibold"><?php echo e($m($order->total_amount)); ?> <?php echo e($order->currency); ?></td></tr>
        </tfoot>
    </table>
</div>


<?php if($order->shipping_address): ?>
    <?php $a = $order->shipping_address; ?>
    <div class="mt-6 rounded-2xl border border-black/10 bg-surface p-5 text-sm text-ink-2">
        <h2 class="mb-2 font-display text-sm font-semibold uppercase tracking-wide text-ink-2">Adresse de livraison</h2>
        <p class="text-ink"><?php echo e($a['name'] ?? ($a['first_name'] ?? '') . ' ' . ($a['last_name'] ?? '')); ?></p>
        <p><?php echo e($a['line1'] ?? $a['address'] ?? ''); ?></p>
        <?php if(!empty($a['line2'])): ?> <p><?php echo e($a['line2']); ?></p> <?php endif; ?>
        <p><?php echo e(trim(($a['postal_code'] ?? '') . ' ' . ($a['city'] ?? ''))); ?></p>
        <p><?php echo e($a['country'] ?? ''); ?></p>
        <?php if(!empty($a['phone'])): ?> <p class="mt-1"><?php echo e($a['phone']); ?></p> <?php endif; ?>
    </div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\USER\Documents\GitHub\malkuthar-app\resources\views/account/orders/show.blade.php ENDPATH**/ ?>