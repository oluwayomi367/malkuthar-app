<?php $__env->startSection('title', 'Administration — Vendeurs'); ?>
<?php $__env->startSection('eyebrow', 'Marketplace'); ?>
<?php $__env->startSection('heading', 'Comptes vendeurs'); ?>

<?php $__env->startSection('content'); ?>
<nav class="mb-5 flex flex-wrap gap-2 text-sm">
    <?php $__currentLoopData = ['' => 'Tous', 'pending' => 'En attente', 'active' => 'Actifs', 'suspended' => 'Suspendus', 'closed' => 'Fermés']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $lbl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(route('admin.marketplace.vendors.index', array_filter(['status' => $k, 'q' => $q ?: null]))); ?>"
           class="<?php echo \Illuminate\Support\Arr::toCssClasses([
               'rounded-full border px-3 py-1.5',
               'border-accent bg-accent/10 font-semibold text-accent' => (string) $status === (string) $k,
               'border-black/10 text-ink-2 hover:text-ink' => (string) $status !== (string) $k,
           ]); ?>">
            <?php echo e($lbl); ?><?php if($k && isset($counts[$k])): ?> <span class="text-ink-3">(<?php echo e($counts[$k]); ?>)</span><?php endif; ?>
        </a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</nav>

<form method="GET" class="mb-5 flex flex-wrap gap-2">
    <?php if($status): ?><input type="hidden" name="status" value="<?php echo e($status); ?>"><?php endif; ?>
    <input name="q" value="<?php echo e($q); ?>" placeholder="Nom, raison sociale, email…"
           class="h-10 w-72 max-w-full rounded-lg border border-black/10 bg-surface px-3 text-sm text-ink placeholder:text-ink-3">
    <input name="region" value="<?php echo e($region); ?>" placeholder="Région"
           class="h-10 w-40 rounded-lg border border-black/10 bg-surface px-3 text-sm text-ink placeholder:text-ink-3">
    <button class="h-10 rounded-lg border border-black/10 bg-ground-alt px-4 text-sm font-semibold text-ink">Filtrer</button>
</form>

<?php if($vendors->isEmpty()): ?>
    <?php if (isset($component)) { $__componentOriginal3607a477fdef7402bc742abad5df9c51 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3607a477fdef7402bc742abad5df9c51 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.empty-state','data' => ['title' => 'Aucun vendeur','text' => 'Aucun compte ne correspond à ce filtre.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.empty-state'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Aucun vendeur','text' => 'Aucun compte ne correspond à ce filtre.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3607a477fdef7402bc742abad5df9c51)): ?>
<?php $attributes = $__attributesOriginal3607a477fdef7402bc742abad5df9c51; ?>
<?php unset($__attributesOriginal3607a477fdef7402bc742abad5df9c51); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3607a477fdef7402bc742abad5df9c51)): ?>
<?php $component = $__componentOriginal3607a477fdef7402bc742abad5df9c51; ?>
<?php unset($__componentOriginal3607a477fdef7402bc742abad5df9c51); ?>
<?php endif; ?>
<?php else: ?>
    <div class="space-y-3">
        <?php $__currentLoopData = $vendors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="rounded-2xl border border-black/10 bg-surface p-4">
                <div class="flex flex-wrap items-start justify-between gap-3">
                    <div>
                        <a href="<?php echo e(route('admin.marketplace.vendors.show', $v)); ?>" class="font-semibold text-ink hover:text-accent"><?php echo e($v->display_name); ?></a>
                        <p class="mt-0.5 text-xs text-ink-3">
                            <?php echo e(trim("{$v->user?->first_name} {$v->user?->last_name}")); ?> · <?php echo e($v->user?->email); ?>

                            <?php if($v->region): ?> · <?php echo e($v->region); ?><?php endif; ?>
                            · demandé le <?php echo e($v->created_at->format('d/m/Y')); ?>

                        </p>
                    </div>
                    <div class="flex items-center gap-3">
                        <?php if($v->commission_rate_override !== null): ?>
                            <span class="text-xs text-ink-3">comm. <?php echo e(rtrim(rtrim(number_format($v->commission_rate_override * 100, 2), '0'), '.')); ?> %</span>
                        <?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginald271113ca69d52f8dbc84ae4f8468e44 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald271113ca69d52f8dbc84ae4f8468e44 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.status-pill','data' => ['status' => $v->status]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.status-pill'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($v->status)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald271113ca69d52f8dbc84ae4f8468e44)): ?>
<?php $attributes = $__attributesOriginald271113ca69d52f8dbc84ae4f8468e44; ?>
<?php unset($__attributesOriginald271113ca69d52f8dbc84ae4f8468e44); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald271113ca69d52f8dbc84ae4f8468e44)): ?>
<?php $component = $__componentOriginald271113ca69d52f8dbc84ae4f8468e44; ?>
<?php unset($__componentOriginald271113ca69d52f8dbc84ae4f8468e44); ?>
<?php endif; ?>
                    </div>
                </div>

                <?php if($v->status === 'pending'): ?>
                    <div class="mt-3 flex flex-wrap gap-2 border-t border-black/[0.06] pt-3">
                        <form method="POST" action="<?php echo e(route('admin.marketplace.vendors.approve', $v)); ?>">
                            <?php echo csrf_field(); ?>
                            <button class="h-9 rounded-lg border border-brand-green/40 bg-brand-green/10 px-3 text-xs font-semibold text-brand-green hover:bg-brand-green/20">Approuver</button>
                        </form>
                        <form method="POST" action="<?php echo e(route('admin.marketplace.vendors.reject', $v)); ?>" class="flex gap-2">
                            <?php echo csrf_field(); ?>
                            <input name="reason" required placeholder="Motif de refus"
                                   class="h-9 w-56 rounded-lg border border-black/10 bg-surface px-3 text-xs text-ink placeholder:text-ink-3">
                            <button class="h-9 rounded-lg border border-rust/40 bg-rust/10 px-3 text-xs font-semibold text-rust hover:bg-rust/20">Refuser</button>
                        </form>
                    </div>
                <?php endif; ?>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <?php if (isset($component)) { $__componentOriginal4d04f29578652eb91560cfbf2ab48c57 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4d04f29578652eb91560cfbf2ab48c57 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.pagination','data' => ['paginator' => $vendors]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.pagination'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['paginator' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($vendors)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4d04f29578652eb91560cfbf2ab48c57)): ?>
<?php $attributes = $__attributesOriginal4d04f29578652eb91560cfbf2ab48c57; ?>
<?php unset($__attributesOriginal4d04f29578652eb91560cfbf2ab48c57); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4d04f29578652eb91560cfbf2ab48c57)): ?>
<?php $component = $__componentOriginal4d04f29578652eb91560cfbf2ab48c57; ?>
<?php unset($__componentOriginal4d04f29578652eb91560cfbf2ab48c57); ?>
<?php endif; ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\USER\Documents\GitHub\malkuthar-app\resources\views/admin/marketplace/vendors/index.blade.php ENDPATH**/ ?>