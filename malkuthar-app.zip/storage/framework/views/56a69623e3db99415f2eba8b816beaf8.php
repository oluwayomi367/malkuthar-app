<?php $__env->startSection('title', 'Administration — Commandes'); ?>
<?php $__env->startSection('eyebrow', 'Ventes'); ?>
<?php $__env->startSection('heading', 'Commandes'); ?>

<?php $__env->startSection('content'); ?>
<?php
    $m = fn ($n) => number_format((float) $n, 0, ',', ' ');
    $providerLabels = ['fedapay' => 'FedaPay', 'cinetpay' => 'CinetPay', 'cod' => 'À la livraison'];
    $statusMeta = [
        'pending' => ['En attente', 'muted'],
        'processing' => ['En cours', 'accent'],
        'completed' => ['Terminée', 'accent'],
        'cancelled' => ['Annulée', 'rust'],
        'refunded' => ['Remboursée', 'rust'],
    ];
?>

<div class="mb-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
    <?php if (isset($component)) { $__componentOriginal81faba2b0dfb90699ac659eea004d68e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal81faba2b0dfb90699ac659eea004d68e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.stat-tile','data' => ['label' => 'COD à encaisser','value' => $kpi['cod_count']]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.stat-tile'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'COD à encaisser','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($kpi['cod_count'])]); ?>
         <?php $__env->slot('foot', null, []); ?> <?php echo e($m($kpi['cod_amount'])); ?> en attente <?php $__env->endSlot(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal81faba2b0dfb90699ac659eea004d68e)): ?>
<?php $attributes = $__attributesOriginal81faba2b0dfb90699ac659eea004d68e; ?>
<?php unset($__attributesOriginal81faba2b0dfb90699ac659eea004d68e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal81faba2b0dfb90699ac659eea004d68e)): ?>
<?php $component = $__componentOriginal81faba2b0dfb90699ac659eea004d68e; ?>
<?php unset($__componentOriginal81faba2b0dfb90699ac659eea004d68e); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal81faba2b0dfb90699ac659eea004d68e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal81faba2b0dfb90699ac659eea004d68e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.stat-tile','data' => ['label' => 'À préparer','value' => $kpi['to_prepare']]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.stat-tile'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'À préparer','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($kpi['to_prepare'])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal81faba2b0dfb90699ac659eea004d68e)): ?>
<?php $attributes = $__attributesOriginal81faba2b0dfb90699ac659eea004d68e; ?>
<?php unset($__attributesOriginal81faba2b0dfb90699ac659eea004d68e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal81faba2b0dfb90699ac659eea004d68e)): ?>
<?php $component = $__componentOriginal81faba2b0dfb90699ac659eea004d68e; ?>
<?php unset($__componentOriginal81faba2b0dfb90699ac659eea004d68e); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal81faba2b0dfb90699ac659eea004d68e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal81faba2b0dfb90699ac659eea004d68e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.stat-tile','data' => ['label' => 'Encaissé aujourd\'hui','value' => $m($kpi['revenue_today'])]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.stat-tile'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Encaissé aujourd\'hui','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($m($kpi['revenue_today']))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal81faba2b0dfb90699ac659eea004d68e)): ?>
<?php $attributes = $__attributesOriginal81faba2b0dfb90699ac659eea004d68e; ?>
<?php unset($__attributesOriginal81faba2b0dfb90699ac659eea004d68e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal81faba2b0dfb90699ac659eea004d68e)): ?>
<?php $component = $__componentOriginal81faba2b0dfb90699ac659eea004d68e; ?>
<?php unset($__componentOriginal81faba2b0dfb90699ac659eea004d68e); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal81faba2b0dfb90699ac659eea004d68e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal81faba2b0dfb90699ac659eea004d68e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.stat-tile','data' => ['label' => 'Commandes','value' => $orders->total()]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.stat-tile'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Commandes','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($orders->total())]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal81faba2b0dfb90699ac659eea004d68e)): ?>
<?php $attributes = $__attributesOriginal81faba2b0dfb90699ac659eea004d68e; ?>
<?php unset($__attributesOriginal81faba2b0dfb90699ac659eea004d68e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal81faba2b0dfb90699ac659eea004d68e)): ?>
<?php $component = $__componentOriginal81faba2b0dfb90699ac659eea004d68e; ?>
<?php unset($__componentOriginal81faba2b0dfb90699ac659eea004d68e); ?>
<?php endif; ?>
</div>

<form method="GET" class="mb-5 flex flex-wrap items-end gap-3">
    <div class="min-w-[200px] flex-1">
        <?php if (isset($component)) { $__componentOriginald816e58425c8bb369623a9433739178c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald816e58425c8bb369623a9433739178c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.field','data' => ['name' => 'q','label' => 'Recherche','value' => $filters['q'],'placeholder' => 'N° commande, client…']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'q','label' => 'Recherche','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($filters['q']),'placeholder' => 'N° commande, client…']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald816e58425c8bb369623a9433739178c)): ?>
<?php $attributes = $__attributesOriginald816e58425c8bb369623a9433739178c; ?>
<?php unset($__attributesOriginald816e58425c8bb369623a9433739178c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald816e58425c8bb369623a9433739178c)): ?>
<?php $component = $__componentOriginald816e58425c8bb369623a9433739178c; ?>
<?php unset($__componentOriginald816e58425c8bb369623a9433739178c); ?>
<?php endif; ?>
    </div>
    <?php if (isset($component)) { $__componentOriginal231e2c645bf8af0c5c05a5dc5a94c862 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal231e2c645bf8af0c5c05a5dc5a94c862 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.select','data' => ['name' => 'provider','label' => 'Paiement','selected' => $filters['provider'],'placeholder' => 'Tous','options' => ['fedapay' => 'FedaPay', 'cinetpay' => 'CinetPay', 'cod' => 'À la livraison']]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'provider','label' => 'Paiement','selected' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($filters['provider']),'placeholder' => 'Tous','options' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(['fedapay' => 'FedaPay', 'cinetpay' => 'CinetPay', 'cod' => 'À la livraison'])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal231e2c645bf8af0c5c05a5dc5a94c862)): ?>
<?php $attributes = $__attributesOriginal231e2c645bf8af0c5c05a5dc5a94c862; ?>
<?php unset($__attributesOriginal231e2c645bf8af0c5c05a5dc5a94c862); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal231e2c645bf8af0c5c05a5dc5a94c862)): ?>
<?php $component = $__componentOriginal231e2c645bf8af0c5c05a5dc5a94c862; ?>
<?php unset($__componentOriginal231e2c645bf8af0c5c05a5dc5a94c862); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal231e2c645bf8af0c5c05a5dc5a94c862 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal231e2c645bf8af0c5c05a5dc5a94c862 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.select','data' => ['name' => 'payment_status','label' => 'Statut paiement','selected' => $filters['paymentStatus'],'placeholder' => 'Tous','options' => ['pending' => 'En attente', 'paid' => 'Payé', 'failed' => 'Échoué', 'refunded' => 'Remboursé']]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'payment_status','label' => 'Statut paiement','selected' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($filters['paymentStatus']),'placeholder' => 'Tous','options' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(['pending' => 'En attente', 'paid' => 'Payé', 'failed' => 'Échoué', 'refunded' => 'Remboursé'])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal231e2c645bf8af0c5c05a5dc5a94c862)): ?>
<?php $attributes = $__attributesOriginal231e2c645bf8af0c5c05a5dc5a94c862; ?>
<?php unset($__attributesOriginal231e2c645bf8af0c5c05a5dc5a94c862); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal231e2c645bf8af0c5c05a5dc5a94c862)): ?>
<?php $component = $__componentOriginal231e2c645bf8af0c5c05a5dc5a94c862; ?>
<?php unset($__componentOriginal231e2c645bf8af0c5c05a5dc5a94c862); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal231e2c645bf8af0c5c05a5dc5a94c862 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal231e2c645bf8af0c5c05a5dc5a94c862 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.select','data' => ['name' => 'status','label' => 'Statut commande','selected' => $filters['status'],'placeholder' => 'Tous','options' => ['pending' => 'En attente', 'processing' => 'En cours', 'completed' => 'Terminée', 'cancelled' => 'Annulée', 'refunded' => 'Remboursée']]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'status','label' => 'Statut commande','selected' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($filters['status']),'placeholder' => 'Tous','options' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(['pending' => 'En attente', 'processing' => 'En cours', 'completed' => 'Terminée', 'cancelled' => 'Annulée', 'refunded' => 'Remboursée'])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal231e2c645bf8af0c5c05a5dc5a94c862)): ?>
<?php $attributes = $__attributesOriginal231e2c645bf8af0c5c05a5dc5a94c862; ?>
<?php unset($__attributesOriginal231e2c645bf8af0c5c05a5dc5a94c862); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal231e2c645bf8af0c5c05a5dc5a94c862)): ?>
<?php $component = $__componentOriginal231e2c645bf8af0c5c05a5dc5a94c862; ?>
<?php unset($__componentOriginal231e2c645bf8af0c5c05a5dc5a94c862); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginala8bb031a483a05f647cb99ed3a469847 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8bb031a483a05f647cb99ed3a469847 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.button','data' => ['type' => 'submit','variant' => 'secondary']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'submit','variant' => 'secondary']); ?>Filtrer <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8bb031a483a05f647cb99ed3a469847)): ?>
<?php $attributes = $__attributesOriginala8bb031a483a05f647cb99ed3a469847; ?>
<?php unset($__attributesOriginala8bb031a483a05f647cb99ed3a469847); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8bb031a483a05f647cb99ed3a469847)): ?>
<?php $component = $__componentOriginala8bb031a483a05f647cb99ed3a469847; ?>
<?php unset($__componentOriginala8bb031a483a05f647cb99ed3a469847); ?>
<?php endif; ?>
    <?php if(array_filter($filters)): ?>
        <a href="<?php echo e(route('admin.orders.index')); ?>" class="pb-2.5 text-sm text-ink-3 hover:text-ink">Réinitialiser</a>
    <?php endif; ?>
</form>

<?php if($orders->isEmpty()): ?>
    <?php if (isset($component)) { $__componentOriginal3607a477fdef7402bc742abad5df9c51 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3607a477fdef7402bc742abad5df9c51 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.empty-state','data' => ['title' => 'Aucune commande','text' => 'Aucune commande ne correspond à ces filtres.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.empty-state'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Aucune commande','text' => 'Aucune commande ne correspond à ces filtres.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3607a477fdef7402bc742abad5df9c51)): ?>
<?php $attributes = $__attributesOriginal3607a477fdef7402bc742abad5df9c51; ?>
<?php unset($__attributesOriginal3607a477fdef7402bc742abad5df9c51); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3607a477fdef7402bc742abad5df9c51)): ?>
<?php $component = $__componentOriginal3607a477fdef7402bc742abad5df9c51; ?>
<?php unset($__componentOriginal3607a477fdef7402bc742abad5df9c51); ?>
<?php endif; ?>
<?php else: ?>
    <div class="overflow-x-auto rounded-2xl border border-black/10">
        <table class="w-full min-w-[820px] text-left text-sm">
            <thead class="bg-surface text-[10.5px] uppercase tracking-[0.09em] text-ink-3">
                <tr>
                    <th class="px-4 py-3 font-semibold">Commande</th>
                    <th class="px-4 py-3 font-semibold">Client</th>
                    <th class="px-4 py-3 font-semibold">Montant</th>
                    <th class="px-4 py-3 font-semibold">Paiement</th>
                    <th class="px-4 py-3 font-semibold">Statut</th>
                    <th class="px-4 py-3"></th>
                </tr>
            </thead>
            <tbody class="divide-y divide-black/[0.06]">
                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="hover:bg-surface">
                        <td class="px-4 py-3">
                            <a href="<?php echo e(route('admin.orders.show', $o)); ?>" class="block font-mono text-[13px] font-medium text-ink hover:text-accent"><?php echo e($o->order_number); ?></a>
                            <span class="block text-xs text-ink-3"><?php echo e($o->created_at?->format('d/m/Y H:i')); ?> · <?php echo e($o->items->count()); ?> article(s)</span>
                        </td>
                        <td class="px-4 py-3 text-ink-2">
                            <?php if($o->user): ?>
                                <?php echo e(trim("{$o->user->first_name} {$o->user->last_name}") ?: $o->user->email); ?>

                                <span class="block text-xs text-ink-3"><?php echo e($o->user->email); ?></span>
                            <?php else: ?>
                                <span class="text-ink-3">Invité</span>
                                <?php if(data_get($o->shipping_address, 'phone')): ?>
                                    <span class="block text-xs text-ink-3"><?php echo e(data_get($o->shipping_address, 'phone')); ?></span>
                                <?php endif; ?>
                            <?php endif; ?>
                        </td>
                        <td class="px-4 py-3 font-semibold text-ink"><?php echo e($m($o->total_amount)); ?> <?php echo e($o->currency); ?></td>
                        <td class="px-4 py-3">
                            <span class="text-ink-2"><?php echo e($providerLabels[$o->payment_provider] ?? ($o->payment_provider ?: '—')); ?></span>
                            <span class="mt-1 block"><?php if (isset($component)) { $__componentOriginald271113ca69d52f8dbc84ae4f8468e44 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald271113ca69d52f8dbc84ae4f8468e44 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.status-pill','data' => ['status' => $o->payment_status]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.status-pill'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($o->payment_status)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald271113ca69d52f8dbc84ae4f8468e44)): ?>
<?php $attributes = $__attributesOriginald271113ca69d52f8dbc84ae4f8468e44; ?>
<?php unset($__attributesOriginald271113ca69d52f8dbc84ae4f8468e44); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald271113ca69d52f8dbc84ae4f8468e44)): ?>
<?php $component = $__componentOriginald271113ca69d52f8dbc84ae4f8468e44; ?>
<?php unset($__componentOriginald271113ca69d52f8dbc84ae4f8468e44); ?>
<?php endif; ?></span>
                        </td>
                        <td class="px-4 py-3">
                            <?php [$sLabel, $sTone] = $statusMeta[$o->status] ?? [$o->status, 'muted']; ?>
                            <?php if (isset($component)) { $__componentOriginalab7baa01105b3dfe1e0cf1dfc58879b4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalab7baa01105b3dfe1e0cf1dfc58879b4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.badge','data' => ['tone' => $sTone]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['tone' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sTone)]); ?><?php echo e($sLabel); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalab7baa01105b3dfe1e0cf1dfc58879b4)): ?>
<?php $attributes = $__attributesOriginalab7baa01105b3dfe1e0cf1dfc58879b4; ?>
<?php unset($__attributesOriginalab7baa01105b3dfe1e0cf1dfc58879b4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalab7baa01105b3dfe1e0cf1dfc58879b4)): ?>
<?php $component = $__componentOriginalab7baa01105b3dfe1e0cf1dfc58879b4; ?>
<?php unset($__componentOriginalab7baa01105b3dfe1e0cf1dfc58879b4); ?>
<?php endif; ?>
                            <?php if($o->isCashOnDelivery() && $o->payment_status === 'pending' && $o->status !== 'cancelled'): ?>
                                <span class="mt-1 block text-[11px] font-semibold text-amber">À encaisser</span>
                            <?php endif; ?>
                        </td>
                        <td class="px-4 py-3 text-right whitespace-nowrap">
                            <a href="<?php echo e(route('admin.orders.show', $o)); ?>" class="text-xs text-accent hover:underline">Ouvrir</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <?php if (isset($component)) { $__componentOriginal4d04f29578652eb91560cfbf2ab48c57 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4d04f29578652eb91560cfbf2ab48c57 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.pagination','data' => ['paginator' => $orders]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.pagination'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['paginator' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($orders)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4d04f29578652eb91560cfbf2ab48c57)): ?>
<?php $attributes = $__attributesOriginal4d04f29578652eb91560cfbf2ab48c57; ?>
<?php unset($__attributesOriginal4d04f29578652eb91560cfbf2ab48c57); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4d04f29578652eb91560cfbf2ab48c57)): ?>
<?php $component = $__componentOriginal4d04f29578652eb91560cfbf2ab48c57; ?>
<?php unset($__componentOriginal4d04f29578652eb91560cfbf2ab48c57); ?>
<?php endif; ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\USER\Documents\GitHub\malkuthar-app\resources\views/admin/orders/index.blade.php ENDPATH**/ ?>